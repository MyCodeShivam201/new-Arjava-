import { useEffect, useLayoutEffect, useState, type ReactNode } from 'react'
import enterpriseScript from './page-script.js?raw'
import { findCapability, findModule } from './arjava/data'
import { HowItWorks } from './arjava/pages'
import { CapabilityPage, ServicesHub } from './arjava/services'
import { ModulePage, ModulesHub } from './arjava/modules'
import { Challenges, ConnectedCapabilities, Delivery, Faq, IndustryCapabilities, Industries, PaperworkReadsItself, Principles, VisibilityDashboard } from './arjava/sections'
import { CtaBand } from './arjava/ui'
import type { ScreenKey } from './arjava/brandArt'
import { OnePartner, PageHero, ProofAndStages } from './arjava/brief'
import { SiteFooter, SiteHeader } from './arjava/chrome'
import { ClientProof, CoreWorkflows, HomeHero, ProductTour, IndustryBand } from './arjava/home'

const pages = import.meta.glob('./pages/*.html', { query: '?raw', import: 'default', eager: true }) as Record<string, string>
const page = (name: string) => pages[`./pages/${name}.html`]

const htmlRoutes: Record<string, { name: string; title: string }> = {
  '/': { name: 'home', title: 'Arjava | Custom Business Software Development Company' },
  '/about/': { name: 'about', title: 'About Us | Arjava' },
  '/blog/': { name: 'blog', title: 'Blog | Arjava' },
  '/blog/how-ss-engineering-found-1-crore-in-hidden-costs/': { name: 'blog_how-ss-engineering-found-1-crore-in-hidden-costs', title: 'How S.S. Engineering Works caught a tender rejection before it happened | Arjava' },
  '/blog/one-purchase-order-3-3-lakh-saved-in-a-day/': { name: 'blog_one-purchase-order-3-3-lakh-saved-in-a-day', title: 'One flag, one purchase order: how ₹3.3 lakh was saved in a day | Arjava' },
  '/blog/real-business-problems-in-growing-businesses/': { name: 'blog_real-business-problems-in-growing-businesses', title: 'The six problems we keep finding inside growing businesses | Arjava' },
  '/blog/why-we-map-your-business-before-writing-code/': { name: 'blog_why-we-map-your-business-before-writing-code', title: 'First we map your business. Then we build it into software. | Arjava' },
  '/contact/': { name: 'contact', title: 'Contact Us | Arjava' },
  '/industries/': { name: 'industries', title: 'Industries | Arjava' },
  '/industries/construction/': { name: 'industries_construction', title: 'Custom Software for Construction & Infrastructure | Arjava' },
  '/industries/engineering-epc/': { name: 'industries_engineering-epc', title: 'Custom Software for Engineering & EPC | Arjava' },
  '/industries/manufacturing/': { name: 'industries_manufacturing', title: 'Custom Software for Manufacturing | Arjava' },
  '/services/consulting-strategy/': { name: 'services_consulting-strategy', title: 'Consulting & Strategy | Arjava' },
  '/services/digital-technology/': { name: 'services_digital-technology', title: 'Digital & Technology | Arjava' },
  '/services/enterprise-solutions/': { name: 'enterprise-interactive', title: 'Enterprise Solutions | Arjava' },
}

/** React-built pages (services narrative, modules, how it works). */
function reactRoute(path: string): { title: string; el: ReactNode } | null {
  if (path === '/services/') return { title: 'Services | Arjava', el: <ServicesHub /> }
  if (path === '/modules/') return { title: 'ERP Modules | Arjava', el: <ModulesHub /> }
  if (path === '/how-it-works/') return { title: 'How Arjava Works | Arjava', el: <HowItWorks /> }
  const cap = path.match(/^\/services\/([^/]+)\/$/)
  const c = cap && findCapability(cap[1])
  if (c) return { title: `${c.name} | Arjava`, el: <CapabilityPage c={c} /> }
  const mod = path.match(/^\/modules\/([^/]+)\/$/)
  const m = mod && findModule(mod[1])
  if (m) return { title: `${m.name} Module | Arjava`, el: <ModulePage m={m} /> }
  return null
}

/* ---------- Snapshot chrome removed; the React header/footer in ./arjava/chrome render on every route ---------- */

const shellSrc = page('404')

function decorate(html: string) {
  const navEnd = html.indexOf('</nav>')
  let out = navEnd >= 0 ? html.slice(navEnd + 6) : html
  out = out.replace(/<footer[\s\S]*?<\/footer>/, '')
  // The snapshots ship framer-motion entrance states (opacity:0) that the original JS animated in.
  return out.replace(/ style="opacity:0[^"]*"/g, '')
}

// Floating WhatsApp link that follows the snapshot footer.
const floating = shellSrc.slice(shellSrc.indexOf('</footer>') + 9)

function Shell({ children }: { children: ReactNode }) {
  return (<>{children}<ProofAndStages /><div style={{ display: 'contents' }} dangerouslySetInnerHTML={{ __html: floating }} /></>)
}

const Raw = ({ html }: { html: string }) => <div className="aj-snap" style={{ display: 'contents' }} dangerouslySetInnerHTML={{ __html: html }} />

/** Home: original sections kept, static ones replaced, new React sections inserted in story order. */
function HomePage({ html }: { html: string }) {
  const cut = (from: string, to: string) => html.slice(html.indexOf(from), html.indexOf(to))
  const testimonials = '<section class="relative overflow-hidden border-b border-border bg-bg-alt py-14">'
  return (
    <>
      <main>
        <HomeHero />
        <OnePartner />
        <ProductTour />
        <Challenges />
        <Raw html={cut('<section id="problems"', testimonials)} />
        <ConnectedCapabilities />
        <CoreWorkflows />
        <Raw html={cut(testimonials, '<section id="ai"')} />
        <PaperworkReadsItself />
        <Principles />
        <VisibilityDashboard />
        <Delivery />
        <Raw html={cut('<section id="why-arjava"', '<section id="faq"')} />
        <Industries />
        <ClientProof />
        <Faq />
        <CtaBand title="Book a free discovery call" body="Tell us what is going on in your business and we will tell you honestly where we can help." />
      </main>
      <Raw html={html.slice(html.indexOf('</main>') + 7)} />
    </>
  )
}

/** Snapshot page with an optional React band inserted before the footer. */
type Hero = { crumb: string; eyebrow: string; screen: ScreenKey; second?: ScreenKey; full?: boolean }

/** Dark hero per kept page. `full` pages had a header-only intro, which is replaced entirely;
    on the rest only the original heading and lead are lifted into the hero. */
const pageHeroes: Record<string, Hero> = {
  about: { crumb: 'About', eyebrow: 'Business transformation partner', screen: 'project', second: 'schedule' },
  contact: { crumb: 'Contact', eyebrow: 'Book a discussion or demo', screen: 'dashboard', second: 'procurement' },
  blog: { crumb: 'Blog', eyebrow: 'Notes from the field', screen: 'costLeaks', second: 'quantity' },
  industries: { crumb: 'Industries', eyebrow: 'Built for site-heavy work', screen: 'routeMap', second: 'equipment' },
  industries_construction: { crumb: 'Industries / Construction', eyebrow: 'Construction & Infrastructure', screen: 'project', second: 'equipment', full: true },
  'industries_engineering-epc': { crumb: 'Industries / Engineering & EPC', eyebrow: 'Engineering & EPC', screen: 'extractDone', second: 'routeMap', full: true },
  industries_manufacturing: { crumb: 'Industries / Manufacturing', eyebrow: 'Manufacturing', screen: 'inventory', second: 'procurement', full: true },
  'services_consulting-strategy': { crumb: 'Services / Consulting & Strategy', eyebrow: 'Understand · Process consulting', screen: 'schedule', second: 'costLeaks', full: true },
  'services_digital-technology': { crumb: 'Services / Digital & Technology', eyebrow: 'Communicate · Connect · Decide', screen: 'extractDone', second: 'assistant', full: true },
  'enterprise-interactive': { crumb: 'Services / Enterprise Solutions', eyebrow: 'Connect · Enterprise systems', screen: 'dashboard', second: 'inventory', full: true },
  'blog_one-purchase-order-3-3-lakh-saved-in-a-day': { crumb: 'Blog / Case study', eyebrow: 'Shanti Infraconstruct', screen: 'procurement', second: 'costLeaks' },
  'blog_how-ss-engineering-found-1-crore-in-hidden-costs': { crumb: 'Blog / Case study', eyebrow: 'S.S. Engineering Works', screen: 'extractDone', second: 'dashboard' },
  'blog_real-business-problems-in-growing-businesses': { crumb: 'Blog', eyebrow: 'Growing businesses', screen: 'costLeaks', second: 'schedule' },
  'blog_why-we-map-your-business-before-writing-code': { crumb: 'Blog', eyebrow: 'Mapped, then built', screen: 'project', second: 'quantity' },
}
const partnerPages = new Set(['about', 'industries', 'services_consulting-strategy', 'services_digital-technology', 'enterprise-interactive'])

/** Lifts heading/lead out of the kept markup, drops the old breadcrumb and scroll-pinned mock illustrations. */
function rebuild(html: string, h: Hero) {
  const m = html.indexOf('<main')
  let head = html.slice(0, m), body = html.slice(m).replace(/<!-- -->/g, '')
  body = body.replace(/<nav aria-label="Breadcrumb"[\s\S]*?<\/nav>/, '')
  body = body.replace(/<section class="relative bg-bg" style="height:\d+svh">[\s\S]*?<\/section>(?=<section|<\/main>)/g, '')
  const hm = /<h1[^>]*>([\s\S]*?)<\/h1>(\s*<p[^>]*>([\s\S]*?)<\/p>)?/.exec(body)
  const title = hm ? hm[1] : ''
  const lead = hm?.[3]
  if (h.full) {
    const s0 = body.indexOf('<section'), s1 = body.indexOf('</section>', s0) + 10
    body = body.slice(0, s0) + body.slice(s1)
  } else if (hm) body = body.replace(hm[0], '')
  return { html: head + body, title, lead }
}

function HtmlPage({ html, extra, name }: { html: string; extra?: ReactNode; name?: string }) {
  const hero = name ? pageHeroes[name] : undefined
  if (!hero) {
    if (!extra) return <Raw html={html} />
    const f = html.indexOf('</main>') + 7
    return (<><Raw html={html.slice(0, f)} />{extra}<Raw html={html.slice(f)} /></>)
  }
  const r = rebuild(html, hero)
  const m = r.html.indexOf('<main'), open = r.html.indexOf('>', m) + 1, end = r.html.indexOf('</main>')
  return (
    <>
      <Raw html={r.html.slice(0, m)} />
      <PageHero crumb={hero.crumb} eyebrow={hero.eyebrow} titleHtml={r.title} leadHtml={r.lead} screen={hero.screen} second={hero.second} />
      <Raw html={`<div class="aj-inner">${r.html.slice(open, end)}</div>`} />
      {extra}
      {name && partnerPages.has(name) && <OnePartner />}
      <ProofAndStages />
      <Raw html={r.html.slice(end + 7)} />
    </>
  )
}

const normalize = (p: string) => (p.endsWith('/') ? p : p + '/')

// Runs the saved Enterprise Solutions interaction script, returning a cleanup that removes its listeners.
function runEnterpriseScript() {
  const added: [string, EventListener][] = []
  const orig = document.addEventListener.bind(document)
  document.addEventListener = ((type: string, fn: EventListener) => {
    added.push([type, fn])
    orig(type, fn)
  }) as typeof document.addEventListener
  try {
    new Function(enterpriseScript)()
  } finally {
    document.addEventListener = orig
  }
  return () => added.forEach(([t, fn]) => document.removeEventListener(t, fn))
}

export default function App() {
  const [path, setPath] = useState(() => normalize(window.location.pathname))
  const html = htmlRoutes[path]
  const react = html ? null : reactRoute(path)

  useEffect(() => {
    document.documentElement.classList.add('h-full', 'inter_cb0c501c-module__AUPRoG__variable')
    document.body.classList.add('min-h-full')
    const onPop = () => setPath(normalize(window.location.pathname))
    const onClick = (e: MouseEvent) => {
      const t = e.target as HTMLElement
      const btn = t.closest('button')
      if (btn && !btn.closest('#mod-explorer, #step-explorer') && /book (a )?(consultation|discovery|call|demo)/i.test(btn.textContent || '')) {
        e.preventDefault()
        window.history.pushState(null, '', '/contact/')
        setPath('/contact/')
        window.scrollTo(0, 0)
        return
      }
      const a = t.closest('a')
      if (!a || e.metaKey || e.ctrlKey || a.target === '_blank') return
      const href = a.getAttribute('href')
      if (!href || !href.startsWith('/')) return
      e.preventDefault()
      const url = new URL(href, window.location.origin)
      window.history.pushState(null, '', url.pathname + url.hash)
      setPath(normalize(url.pathname))
      if (url.hash) requestAnimationFrame(() => document.querySelector(url.hash)?.scrollIntoView())
      else window.scrollTo(0, 0)
    }
    window.addEventListener('popstate', onPop)
    document.addEventListener('click', onClick)
    return () => {
      window.removeEventListener('popstate', onPop)
      document.removeEventListener('click', onClick)
    }
  }, [])

  useLayoutEffect(() => {
    document.title = html?.title ?? react?.title ?? '404: This page could not be found. | Arjava'
    if (html?.name === 'enterprise-interactive') return runEnterpriseScript()
  }, [path])

  return (
    <div key={path} style={{ display: 'contents' }}>
      <a href="#content" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-md focus:bg-forest focus:px-4 focus:py-2 focus:text-white">Skip to content</a>
      <SiteHeader path={path} />
      <div id="content" style={{ display: 'contents' }} />
      {react ? (
        <Shell>{react.el}</Shell>
      ) : (
        html?.name === 'home' ? (
          <HomePage html={decorate(page('home'))} />
        ) : (
          <HtmlPage name={html?.name} html={decorate(page(html ? html.name : '404'))} extra={path.startsWith('/industries/') && path !== '/industries/' ? <><IndustryBand slug={path.split('/')[2]} /><IndustryCapabilities slug={path.split('/')[2]} /></> : undefined} />
        )
      )}
      <SiteFooter />
    </div>
  )
}

