import { useEffect, useRef, useState, type ReactNode } from 'react'
import { capabilities, findModule } from './data'
import { specs } from './moduleSpecs'
import { pillars } from './services'
import { ArjavaRings, ArjavaSweep, Glow } from './brandArt'

/* ------------------------------------------------------------------ */
/* Shared site chrome: header with mega menus, mobile drawer, footer.  */
/* ------------------------------------------------------------------ */

const PHOTO = '/_next/static/media/process-first.19ttyq1eo5l4v.jpg'
const LOGO_SHANTI = '/_next/static/media/shanti-constructions-logo.15r7woa-5hj3f.png'

export function LogoMark({ className = 'h-[30px] w-[30px]' }: { className?: string }) {
  return (
    <svg viewBox="0 0 300 300" fill="none" aria-hidden="true" className={className}>
      <g stroke="#1EB4D4" strokeWidth="4.5" strokeMiterlimit="10" fill="none">
        <line x1="150" y1="70.1" x2="150" y2="224.5" /><line x1="242" y1="179.5" x2="58.4" y2="179.5" /><line x1="225.2" y1="113.8" x2="165.2" y2="230.3" /><line x1="249.3" y1="198.4" x2="178.5" y2="243.3" /><line x1="251.7" y1="114.1" x2="265.1" y2="147.7" /><line x1="46.8" y1="114.1" x2="33.4" y2="147.7" /><line x1="50.5" y1="198.4" x2="121.3" y2="243.3" /><line x1="73.9" y1="113.8" x2="133.9" y2="230.3" />
        <path d="M163.4,66.4c17.4,37.3,44.2,71.6,82,102.9" /><path d="M137,66.4c-17.4,37.3-44.2,71.6-82,102.9" /><path d="M184.5,103c8.1-2.6,16.5-4.5,25.4-5.7" /><path d="M116.4,103c-8.1-2.6-16.5-4.5-25.4-5.7" />
      </g>
      {[[60, 85.9, '#F47B2A', '#FFE3CC'], [238.2, 85.9, '#F47B2A', '#FFE3CC'], [148.6, 260, '#1EB4D4', '#EAF6FB'], [272.9, 179.5, '#1EB4D4', '#EAF6FB'], [27.1, 179.5, '#1EB4D4', '#EAF6FB'], [148.6, 40, '#1EB4D4', '#EAF6FB']].map(([x, y, f, s]) => (
        <circle key={`${x}${y}`} cx={x as number} cy={y as number} r="19.8" fill={f as string} stroke={s as string} strokeWidth="5" />
      ))}
    </svg>
  )
}

type Link = { label: string; href: string; desc?: string }
type Menu = {
  id: string
  label: string
  title: string
  intro: string
  cta?: Link
  groups: { heading: string; links: Link[] }[]
  feature?: ReactNode
  match: (path: string) => boolean
}

const mod = (slug: string): Link => {
  const m = findModule(slug)!
  return { label: m.name, href: `/modules/${slug}/`, desc: m.tagline }
}
const capLink = (slug: string): Link => {
  const c = capabilities.find((x) => x.slug === slug)!
  return { label: c.name, href: `/services/${slug}/`, desc: c.outcome }
}

function FlowFeature() {
  const steps = ['Request', 'Approval', 'Purchase order', 'Goods receipt', 'Stock & ledger']
  return (
    <a href="/modules/" className="group block rounded-xl border border-white/10 bg-white/[0.04] p-5 transition-colors hover:border-white/25">
      <p className="text-[13.5px] font-semibold text-white/55">One record, every team</p>
      <ol className="mt-4 space-y-0">
        {steps.map((s, i) => (
          <li key={s} className="flex items-stretch gap-3">
            <span className="flex w-3 flex-col items-center">
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${i === steps.length - 1 ? 'bg-copper' : 'border border-[#8EE3F2]'}`} />
              {i < steps.length - 1 && <span className="w-px flex-1 bg-white/15" />}
            </span>
            <span className="pb-3 text-[13px] font-medium text-white">{s}</span>
          </li>
        ))}
      </ol>
      <p className="mt-1 text-[12.5px] leading-[1.55] text-white/55">A purchase raised on site reaches finance and inventory without re-entry.</p>
      <span className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-semibold text-[#FFB57A] group-hover:text-white">See all nine modules <Arrow /></span>
    </a>
  )
}

function CaseFeature() {
  return (
    <a href="/blog/one-purchase-order-3-3-lakh-saved-in-a-day/" className="group block rounded-xl border border-white/10 bg-white/[0.04] p-5 transition-colors hover:border-white/25">
      <div className="flex items-center gap-2.5">
        <img src={LOGO_SHANTI} alt="Shanti Infraconstruct logo" width={28} height={28} className="h-7 w-7 object-contain" loading="lazy" />
        <span className="text-[12px] font-semibold text-white/55">Shanti Infraconstruct · Case study</span>
      </div>
      <p className="mt-4 font-display text-[17px] font-bold leading-snug text-white">One flag, one purchase order: how ₹3.3 lakh was saved in a day</p>
      <p className="mt-2 text-[12.5px] leading-[1.55] text-white/55">Vendor rate history flagged a cheaper supplier before the order went out. Client-reported.</p>
      <span className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-semibold text-[#FFB57A] group-hover:text-white">Read the case <Arrow /></span>
    </a>
  )
}

function PhotoFeature() {
  return (
    <a href="/blog/why-we-map-your-business-before-writing-code/" className="group block overflow-hidden rounded-xl border border-white/10 bg-white/[0.04]">
      <img src={PHOTO} alt="Your workflows, mapped before we build" loading="lazy" className="aspect-[4/3] w-full object-cover" />
      <div className="p-4">
        <p className="font-display text-[15px] font-bold leading-snug text-white">First we map your business. Then we build it into software.</p>
        <span className="mt-2 inline-flex items-center gap-1.5 text-[13px] font-semibold text-[#FFB57A] group-hover:text-white">Read our approach <Arrow /></span>
      </div>
    </a>
  )
}

export const menus: Menu[] = [
  {
    id: 'solutions', label: 'Solutions', title: 'Solutions',
    intro: 'Custom ERP, workflow automation and practical AI on one shared database, configured to how your business already runs.',
    cta: { label: 'Explore the ERP platform', href: '/services/enterprise-solutions/' },
    groups: [
      { heading: 'Platform', links: [capLink('erp-automation'), capLink('ai-business-intelligence'), { label: 'Workflow & approval automation', href: '/modules/approvals-audit/', desc: 'Approval chains with a full audit trail' }] },
      { heading: 'ERP modules', links: [mod('purchase-vendors'), mod('inventory-stock'), mod('finance-cash-flow'), mod('projects-tasks'), { label: 'All nine modules', href: '/modules/' }] },
    ],
    feature: <FlowFeature />,
    match: (p) => p.startsWith('/modules/') || p === '/services/erp-automation/' || p === '/services/ai-business-intelligence/' || p === '/services/enterprise-solutions/',
  },
  {
    id: 'industries', label: 'Industries', title: 'Industries',
    intro: 'Built for project-driven, asset-heavy businesses where procurement, stores, site and finance have to agree.',
    cta: { label: 'All industries', href: '/industries/' },
    groups: [
      { heading: 'Sectors', links: [
        { label: 'Construction & Infrastructure', href: '/industries/construction/', desc: 'Project budgets, site stores and contractor billing' },
        { label: 'Engineering & EPC', href: '/industries/engineering-epc/', desc: 'Tenders, BOQ, document control and execution' },
        { label: 'Manufacturing', href: '/industries/manufacturing/', desc: 'Material movements, vendors and operational reporting' },
      ] },
    ],
    feature: <CaseFeature />,
    match: (p) => p.startsWith('/industries/'),
  },
  {
    id: 'services', label: 'Services', title: 'Services',
    intro: 'Three services, from understanding how the business runs to the systems and applications built around it.',
    cta: { label: 'All services', href: '/services/' },
    groups: pillars.map((p) => ({ heading: p.title, links: [{ label: `${p.title} overview`, href: p.href, desc: p.body }, ...p.caps.filter((c) => !['erp-automation', 'ai-business-intelligence'].includes(c) || p.caps.length === 1).map(capLink)] })),
    match: (p) => p.startsWith('/services/') && !['/services/erp-automation/', '/services/ai-business-intelligence/', '/services/enterprise-solutions/'].includes(p),
  },
  {
    id: 'resources', label: 'Resources', title: 'Resources',
    intro: 'Case studies and field notes from inside growing engineering and construction businesses.',
    cta: { label: 'All articles', href: '/blog/' },
    groups: [
      { heading: 'Case studies', links: [
        { label: 'How S.S. Engineering caught a tender rejection before it happened', href: '/blog/how-ss-engineering-found-1-crore-in-hidden-costs/' },
        { label: 'One purchase order, ₹3.3 lakh saved in a day', href: '/blog/one-purchase-order-3-3-lakh-saved-in-a-day/' },
        { label: 'Client stories', href: '/about/#casestudies' },
      ] },
      { heading: 'Insights', links: [
        { label: 'The six problems we keep finding inside growing businesses', href: '/blog/real-business-problems-in-growing-businesses/' },
        { label: 'First we map your business, then we build it', href: '/blog/why-we-map-your-business-before-writing-code/' },
      ] },
    ],
    feature: <CaseFeature />,
    match: (p) => p.startsWith('/blog/'),
  },
  {
    id: 'company', label: 'Company', title: 'Company',
    intro: 'Arjava Innovation LLP builds custom business software for MSMEs, enterprises and government organisations.',
    cta: { label: 'Contact us', href: '/contact/' },
    groups: [
      { heading: 'Arjava', links: [
        { label: 'About Arjava', href: '/about/', desc: 'Who we are and what we stand for' },
        { label: 'How we work', href: '/how-it-works/', desc: 'From discovery to support, stage by stage' },
        { label: 'Our process', href: '/#process', desc: 'The delivery route at a glance' },
        { label: 'Contact', href: '/contact/', desc: 'Discuss a requirement with our team' },
      ] },
    ],
    feature: <PhotoFeature />,
    match: (p) => ['/about/', '/contact/', '/how-it-works/'].includes(p),
  },
]

function Arrow({ className = 'h-3.5 w-3.5' }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6" /></svg>
}
function Chevron({ open }: { open: boolean }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`h-3.5 w-3.5 transition-transform duration-200 ${open ? 'rotate-180' : ''}`} aria-hidden="true"><path d="m6 9 6 6 6-6" /></svg>
}

function MegaPanel({ m, id }: { m: Menu; id: string }) {
  const cols = m.groups.length
  return (
    <div id={id} role="region" aria-label={`${m.label} menu`} className="aj-mega absolute inset-x-0 top-full px-6 pt-2">
      <div className="relative mx-auto max-w-[1280px] overflow-hidden rounded-2xl border border-white/10 text-white shadow-[0_40px_80px_-30px_rgba(0,0,0,0.7)]">
        <Glow tone="panel" />
        <div className={`relative grid ${m.feature ? 'grid-cols-[280px_1fr_290px]' : 'grid-cols-[280px_1fr]'}`}>
          <div className="relative overflow-hidden border-r border-white/10 p-8">
            <div aria-hidden="true" className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(80% 70% at 100% 100%, rgba(255,154,77,0.5) 0%, transparent 70%)' }} />
            <ArjavaSweep variant="panel" className="absolute -bottom-24 -left-16 h-[360px] w-[360px] opacity-80" />
            <div className="relative">
              <p className="font-display text-[15px] font-bold text-[#FFB57A]">{m.title}</p>
              <p className="mt-3 text-[13.5px] leading-[1.6] text-white/75">{m.intro}</p>
              {m.cta && <a href={m.cta.href} className="mt-6 inline-flex items-center gap-1.5 rounded-full border border-white/25 bg-white/10 px-4 py-2 text-[13px] font-semibold text-white backdrop-blur-sm hover:bg-white/15">{m.cta.label} <Arrow /></a>}
            </div>
          </div>
          <div className={`grid py-8 ${cols >= 3 ? 'grid-cols-3' : cols === 2 ? 'grid-cols-2' : 'grid-cols-1'}`}>
            {m.groups.map((g, i) => (
              <div key={g.heading} className={`px-8 ${i ? 'border-l border-white/10' : ''}`}>
                <p className="mb-3 font-display text-[14px] font-bold text-[#FFB57A]">{g.heading}</p>
                <ul className="space-y-0.5">
                  {g.links.map((l) => (
                    <li key={l.href + l.label}>
                      <a href={l.href} className="group -mx-3 block rounded-lg px-3 py-2 transition-colors hover:bg-white/[0.06] focus-visible:bg-white/[0.06]">
                        <span className="block text-[14px] font-medium text-white/90 group-hover:text-[#FFB57A]">{l.label}</span>
                        {l.desc && <span className="mt-0.5 block text-[12px] leading-[1.45] text-white/45">{l.desc}</span>}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          {m.feature && <div className="border-l border-white/10 p-6">{m.feature}</div>}
        </div>
      </div>
    </div>
  )
}

export function SiteHeader({ path }: { path: string }) {
  const [open, setOpen] = useState<string | null>(null)
  const [drawer, setDrawer] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const ref = useRef<HTMLElement>(null)
  const timer = useRef<number | undefined>(undefined)

  const schedule = (id: string | null, ms: number) => {
    window.clearTimeout(timer.current)
    timer.current = window.setTimeout(() => setOpen(id), ms)
  }

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    const onDown = (e: PointerEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(null) }
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return
      setDrawer(false)
      setOpen((cur) => {
        if (cur) (document.getElementById(`mm-btn-${cur}`) as HTMLButtonElement | null)?.focus()
        return null
      })
    }
    document.addEventListener('pointerdown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('scroll', onScroll)
      document.removeEventListener('pointerdown', onDown)
      document.removeEventListener('keydown', onKey)
      window.clearTimeout(timer.current)
    }
  }, [])

  useEffect(() => {
    document.body.style.overflow = drawer ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [drawer])

  const onTriggerKey = (e: React.KeyboardEvent, i: number) => {
    const id = menus[i].id
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setOpen(id)
      requestAnimationFrame(() => (document.querySelector(`#mm-${id} a`) as HTMLElement | null)?.focus())
    } else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
      e.preventDefault()
      const n = menus[(i + (e.key === 'ArrowRight' ? 1 : menus.length - 1)) % menus.length].id
      document.getElementById(`mm-btn-${n}`)?.focus()
      if (open) setOpen(n)
    }
  }

  const active = open ? menus.find((m) => m.id === open) : undefined
  const solid = scrolled || open || drawer

  return (
    <header
      ref={ref}
      onMouseLeave={() => schedule(null, 180)}
      onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setOpen(null) }}
      className={`fixed inset-x-0 top-0 z-[100] transition-[background-color,border-color] duration-200 ${solid ? 'border-b border-white/10 bg-[#08102A]/95' : 'border-b border-white/5 bg-[#08102A]/80'} backdrop-blur-md`}
    >
      <div className="mx-auto flex h-16 max-w-[1280px] items-center gap-6 px-6">
        <a href="/" className="flex shrink-0 items-center gap-2.5" aria-label="Arjava home">
          <LogoMark />
          <span className="font-display text-[18px] font-extrabold tracking-[-0.02em] text-white">Arjava</span>
        </a>
        <nav aria-label="Primary" className="hidden flex-1 items-center justify-center lg:flex">
          <ul className="flex items-center">
            {menus.map((m, i) => {
              const isOpen = open === m.id
              const isActive = m.match(path)
              return (
                <li key={m.id} onMouseEnter={() => schedule(m.id, open ? 0 : 90)}>
                  <button
                    id={`mm-btn-${m.id}`}
                    type="button"
                    aria-expanded={isOpen}
                    aria-controls={`mm-${m.id}`}
                    onClick={() => { window.clearTimeout(timer.current); setOpen(isOpen ? null : m.id) }}
                    onKeyDown={(e) => onTriggerKey(e, i)}
                    className={`relative flex h-16 items-center gap-1.5 px-3.5 text-[14px] font-medium transition-colors ${isOpen ? 'text-[#FFB57A]' : isActive ? 'text-white' : 'text-white/75 hover:text-white'}`}
                  >
                    {m.label}<Chevron open={isOpen} />
                    <span className={`absolute inset-x-3.5 bottom-0 h-[2px] transition-colors ${isOpen || isActive ? 'bg-[#FF9A4D]' : 'bg-transparent'}`} />
                  </button>
                </li>
              )
            })}
          </ul>
        </nav>
        <div className="ml-auto hidden shrink-0 items-center gap-4 lg:flex">
          <a href="tel:+919711238920" className="hidden text-[13.5px] font-medium text-white/70 hover:text-white 2xl:inline">+91 97112 38920</a>
<a href="https://erp.arjavahub.com" target="_blank" rel="noopener noreferrer" className="hidden items-center gap-1.5 rounded-full border border-white/20 px-4 py-2.5 text-[13.5px] font-semibold text-white/85 transition-colors hover:bg-white/10 hover:text-white xl:inline-flex">ERP login</a>
          <a href="/contact/" className="aj-pill-copper rounded-full px-5 py-2.5 text-[13.5px] font-semibold text-white">Book Consultation</a>
        </div>
        <button type="button" aria-label={drawer ? 'Close menu' : 'Open menu'} aria-expanded={drawer} aria-controls="mobile-nav" onClick={() => setDrawer((d) => !d)} className="ml-auto flex h-10 w-10 items-center justify-center rounded-md text-white lg:hidden">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-6 w-6" aria-hidden="true">{drawer ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}</svg>
        </button>
      </div>
      {active && <div className="hidden lg:block" onMouseEnter={() => window.clearTimeout(timer.current)}><MegaPanel m={active} id={`mm-${active.id}`} /></div>}
      {drawer && <MobileNav path={path} onClose={() => setDrawer(false)} />}
    </header>
  )
}

function MobileNav({ path, onClose }: { path: string; onClose: () => void }) {
  const [sec, setSec] = useState<string | null>(() => menus.find((m) => m.match(path))?.id ?? null)
  return (
    <div id="mobile-nav" className="fixed inset-x-0 bottom-0 top-16 overflow-y-auto border-t border-white/10 bg-[#08102A] text-white lg:hidden">
      <nav aria-label="Mobile" className="px-6 pb-10 pt-2">
        <ul>
          {menus.map((m) => {
            const o = sec === m.id
            return (
              <li key={m.id} className="border-b border-white/10">
                <button type="button" aria-expanded={o} aria-controls={`mn-${m.id}`} onClick={() => setSec(o ? null : m.id)} className="flex w-full items-center justify-between py-4 text-left font-display text-[18px] font-bold text-white">
                  {m.label}<Chevron open={o} />
                </button>
                {o && (
                  <div id={`mn-${m.id}`} className="pb-5">
                    {m.groups.map((g) => (
                      <div key={g.heading} className="mb-4">
                        <p className="mb-1 text-[13.5px] font-semibold text-[#FFB57A]">{g.heading}</p>
                        <ul>
                          {g.links.map((l) => (
                            <li key={l.href + l.label}><a href={l.href} onClick={onClose} aria-current={path === l.href ? 'page' : undefined} className={`block py-2.5 text-[15px] ${path === l.href ? 'font-semibold text-[#FFB57A]' : 'text-white'}`}>{l.label}</a></li>
                          ))}
                        </ul>
                      </div>
                    ))}
                    {m.cta && <a href={m.cta.href} onClick={onClose} className="inline-flex items-center gap-1.5 text-[14px] font-semibold text-[#FFB57A]">{m.cta.label} <Arrow /></a>}
                  </div>
                )}
              </li>
            )
          })}
        </ul>
        <div className="mt-6 grid gap-2">
          <a href="https://erp.arjavahub.com" target="_blank" rel="noopener noreferrer" className="rounded-full border border-white/20 px-4 py-3 text-center text-[15px] font-semibold text-white">Client ERP login</a>
          <a href="/contact/" onClick={onClose} className="aj-pill-copper rounded-full px-4 py-3 text-center text-[15px] font-semibold text-white">Book Consultation</a>
          <a href="tel:+919711238920" className="rounded-full border border-white/20 px-4 py-3 text-center text-[15px] font-medium text-white">+91 97112 38920</a>
        </div>
      </nav>
    </div>
  )
}

/* ------------------------------ footer ------------------------------ */

const footCols: { heading: string; links: Link[] }[] = [
  { heading: 'Solutions', links: [{ label: 'Custom ERP & Automation', href: '/services/erp-automation/' }, { label: 'AI & Business Intelligence', href: '/services/ai-business-intelligence/' }, { label: 'ERP modules', href: '/modules/' }, { label: 'Enterprise Solutions', href: '/services/enterprise-solutions/' }] },
  { heading: 'Services', links: [...pillars.map((p) => ({ label: p.title, href: p.href })), { label: 'All services', href: '/services/' }] },
  { heading: 'Industries', links: [{ label: 'Construction & Infrastructure', href: '/industries/construction/' }, { label: 'Engineering & EPC', href: '/industries/engineering-epc/' }, { label: 'Manufacturing', href: '/industries/manufacturing/' }, { label: 'All industries', href: '/industries/' }] },
  { heading: 'Resources', links: [{ label: 'Blog', href: '/blog/' }, { label: 'Case studies', href: '/about/#casestudies' }, { label: 'How we work', href: '/how-it-works/' }] },
  { heading: 'Company', links: [{ label: 'About Arjava', href: '/about/' }, { label: 'Our process', href: '/#process' }, { label: 'Contact', href: '/contact/' }] },
]

export function SiteFooter() {
  return (
    <footer className="relative overflow-hidden text-white">
      <Glow tone="footer" />
      <ArjavaRings className="absolute -right-24 -top-24 h-[420px] w-[420px] opacity-60 max-md:hidden" />
      <div className="relative mx-auto max-w-[1280px] px-6 pt-16">
        <div className="grid gap-12 border-b border-white/10 pb-12 lg:grid-cols-[1.1fr_2fr]">
          <div>
            <a href="/" className="flex items-center gap-2.5" aria-label="Arjava home"><LogoMark className="h-8 w-8" /><span className="font-display text-[20px] font-extrabold">Arjava</span><span className="text-[13px] text-white/50">Innovation LLP</span></a>
            <p className="mt-5 max-w-[360px] text-[14.5px] leading-[1.7] text-white/70">Custom business software for MSMEs, enterprises and government organizations. Inspired by Arjava: transparency and integrity in everything we build.</p>
            <dl className="mt-8 space-y-3 text-[14px]">
              <div><dt className="sr-only">Email</dt><dd><a href="mailto:hello@arjavahub.com" className="text-white hover:text-[#FFB57A]">hello@arjavahub.com</a></dd></div>
              <div><dt className="sr-only">Phone</dt><dd><a href="tel:+919711238920" className="text-white hover:text-[#FFB57A]">+91 97112 38920</a></dd></div>
              <div><dt className="sr-only">Address</dt><dd className="text-white/60">Sector 142, Noida, Uttar Pradesh, India</dd></div>
            </dl>
          </div>
          <div className="grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3 md:grid-cols-5">
            {footCols.map((c) => (
              <div key={c.heading}>
                <p className="mb-4 text-[13.5px] font-semibold text-white/45">{c.heading}</p>
                <ul className="space-y-2.5">{c.links.map((l) => <li key={l.href}><a href={l.href} className="text-[13.5px] leading-snug text-white/80 transition-colors hover:text-white">{l.label}</a></li>)}</ul>
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-3 py-6 text-[12.5px] text-white/50 sm:flex-row sm:items-center sm:justify-between">
          <p>© 2025 Arjava Innovation LLP. All rights reserved.</p>
          <div className="flex gap-5">
            <a href="https://www.linkedin.com/company/arjava-innovation" target="_blank" rel="noopener noreferrer" className="hover:text-white">LinkedIn</a>
            <a href="https://wa.me/918574931022" target="_blank" rel="noopener noreferrer" className="hover:text-white">WhatsApp</a>
            <a href="https://erp.arjavahub.com" target="_blank" rel="noopener noreferrer" className="hover:text-white">ERP login</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
