import { Orb, ScreenFrame, type ScreenKey } from './brandArt'

/* Elements from the Arjava capability brief, shared across pages:
   the four connected capabilities, client results and the six delivery stages. */

const wrap = 'mx-auto max-w-[1280px] px-6'

const caps = [
  { verb: 'Understand', name: 'Business & Process Consulting', body: 'Process discovery, workflow mapping, gap analysis and a transformation roadmap.', out: 'Clear priorities before you invest', href: '/services/consulting-strategy/' },
  { verb: 'Communicate', name: 'Digital Presence & Communication', body: 'Corporate websites, capability statements, pitch decks and project portfolios.', out: 'Win trust with clients and investors', href: '/services/digital-technology/' },
  { verb: 'Connect', name: 'Custom ERP & Workflow Automation', body: 'Purchase, inventory, finance, projects, approvals and audit trails, integrated.', out: 'One source of truth across teams', href: '/modules/' },
  { verb: 'Decide', name: 'AI & Business Intelligence', body: 'Document reading, rate comparison, variance and cash-flow forecasting, MIS.', out: 'Faster, data-backed decisions', href: '/services/ai-business-intelligence/' },
]

const results = [
  { big: 'Minutes', was: 'not days', label: 'Tender document reading', note: 'Dates, fees, eligibility and required documents pulled into structured fields' },
  { big: 'Every PO', was: 'checked on rate', label: 'Vendor rate history', note: 'Quotes compared against past rates before an order is approved' },
  { big: 'Before', was: 'submission', label: 'Validity and compliance checks', note: 'EMD and document validity checked against the latest corrigendum' },
]

const stages = [['Discover', 'Map your workflows'], ['Define', 'Agree scope & goals'], ['Design', 'Plan screens & data'], ['Develop', 'Build & configure'], ['Deploy', 'Go live with training'], ['Support', 'Improve continuously']]

/** Four capabilities arranged around a central orb: one partner, end to end. */
export function OnePartner() {
  const card = (c: (typeof caps)[number], i: number) => (
    <a key={c.verb} href={c.href} className="aj-lift group block rounded-2xl border border-border bg-white p-5">
      <p className={`text-[13.5px] font-bold ${i % 2 ? 'text-copper' : 'text-forest'}`}>{c.verb}</p>
      <p className="mt-1.5 font-display text-[17px] font-bold leading-snug text-navy">{c.name}</p>
      <p className="mt-2 text-[13.5px] leading-[1.6] text-muted">{c.body}</p>
      <p className="mt-3 border-t border-border pt-3 text-[13px] font-semibold text-navy group-hover:text-copper">{c.out} →</p>
    </a>
  )
  return (
    <section className="aj-ambient bg-white py-16">
      <div className={wrap}>
        <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-end">
          <div>
            <p className="text-[13.5px] font-semibold text-forest">Business transformation, not just software</p>
            <h2 className="mt-2 text-[clamp(1.8rem,3.2vw,2.6rem)] font-extrabold leading-[1.1] text-navy">One partner, <span className="aj-accent">four connected capabilities.</span></h2>
          </div>
          <p className="max-w-[440px] text-[15px] leading-[1.65] text-muted">From the first process map to the system your teams run on, delivered by the same people.</p>
        </div>
        <div className="mt-10 grid items-center gap-4 md:grid-cols-2 lg:grid-cols-[1fr_220px_1fr]">
          <div className="grid gap-4">{card(caps[0], 0)}{card(caps[2], 2)}</div>
          <div className="relative mx-auto hidden h-[220px] w-[220px] lg:block">
            <Orb size={220}><span className="font-display text-[15px] font-extrabold uppercase tracking-[0.2em]">Arjava</span><span className="mt-1 text-[12px] text-white/85">One partner,<br />end to end</span></Orb>
          </div>
          <div className="grid gap-4">{card(caps[1], 1)}{card(caps[3], 3)}</div>
        </div>
      </div>
    </section>
  )
}

/** Client results and the six delivery stages, as one compact closing band. */
export function ProofAndStages() {
  return (
    <section className="aj-ambient border-t border-border bg-ivory py-14">
      <div className={`${wrap} grid gap-10 lg:grid-cols-[1.1fr_1fr]`}>
        <div>
          <p className="text-[13.5px] font-semibold text-forest">What the system checks for you</p>
          <ul className="mt-4 grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-3">
            {results.map((r) => (
              <li key={r.label} className="bg-white p-5 transition-colors hover:bg-[#EAF6FB]">
                <p className="font-display text-[28px] font-extrabold leading-none text-navy">{r.big}</p>
                <p className="mt-1 text-[12px] font-semibold text-copper">{r.was}</p>
                <p className="mt-3 text-[13.5px] font-semibold text-navy">{r.label}</p>
                <p className="mt-1 text-[12.5px] leading-[1.5] text-muted">{r.note}</p>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11.5px] text-muted">Checks run inside the ERP; your team reviews every flag before acting.</p>
        </div>
        <div>
          <p className="text-[13.5px] font-semibold text-forest">Next step: a discussion, then six clear stages</p>
          <ol className="aj-stages mt-4 grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-3">
            {stages.map(([t, d], i) => (
              <li key={t} className="border-t-2 border-navy/15 pt-3">
                <span className="text-[11px] font-bold tabular-nums text-muted">{String(i + 1).padStart(2, '0')}</span>
                <p className="font-display text-[16px] font-bold text-navy">{t}</p>
                <p className="text-[12.5px] text-muted">{d}</p>
              </li>
            ))}
          </ol>
          <p className="mt-6 rounded-xl border border-border bg-white px-4 py-3 text-[12.5px] leading-[1.55] text-muted"><b className="text-navy">Human-in-the-loop AI.</b> AI reads documents, compares data and flags risks; your team reviews and decides.</p>
        </div>
      </div>
    </section>
  )
}

/** Compact dark hero for inner pages: original heading and lead, with two real screens. */
export function PageHero({ crumb, eyebrow, titleHtml, leadHtml, screen, second }: { crumb: string; eyebrow: string; titleHtml: string; leadHtml?: string; screen: ScreenKey; second?: ScreenKey }) {
  return (
    <section className="aj-dark relative overflow-hidden pt-16 text-white">
      <div className={`${wrap} relative grid items-center gap-10 py-10 lg:grid-cols-[1fr_1.05fr] lg:py-14`}>
        <div>
          <p className="text-[12.5px] text-white/55"><a href="/" className="hover:text-white">Home</a> <span className="mx-1">/</span> <span className="text-white/85">{crumb}</span></p>
          <p className="mt-6 flex items-center gap-3 text-[13.5px] font-semibold text-[#FFB57A]">{eyebrow}</p>
          <h1 className="aj-hero-h mt-4 text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.08] text-white" dangerouslySetInnerHTML={{ __html: titleHtml }} />
          {leadHtml && <p className="mt-5 max-w-[560px] text-[16.5px] leading-[1.7] text-white/75" dangerouslySetInnerHTML={{ __html: leadHtml }} />}
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="/contact/" className="aj-pill-copper inline-flex items-center rounded-full px-6 py-3 text-[14.5px] font-semibold text-white">Book a discussion or demo</a>
            <a href="/how-it-works/" className="inline-flex items-center rounded-full border border-white/25 bg-white/5 px-6 py-3 text-[14.5px] font-semibold text-white hover:bg-white/10">How it works</a>
          </div>
        </div>
        <div className="relative pb-8 max-lg:hidden">
          <div className="aj-tilt"><ScreenFrame screen={screen} /></div>
          {second && <ScreenFrame screen={second} className="aj-float absolute -bottom-2 -left-10 w-[52%]" />}
        </div>
      </div>
    </section>
  )
}
