import { ArjavaSweep, Glow } from './brandArt'
import { useEffect, useRef, useState, type ReactNode } from 'react'
import type { IconName, IllustrationKind } from './data'

const paths: Record<IconName, ReactNode> = {
  compass: (<><circle cx="12" cy="12" r="9" /><path d="m15.5 8.5-2 5-5 2 2-5z" /></>),
  globe: (<><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c2.5 2.7 3.8 5.7 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-5.7-3.8-9S9.5 5.7 12 3z" /></>),
  code: (<><path d="m8 7-5 5 5 5M16 7l5 5-5 5M14 4l-4 16" /></>),
  cart: (<><circle cx="9" cy="20" r="1.4" /><circle cx="18" cy="20" r="1.4" /><path d="M2.5 3h2.6l2.4 12h11l2-8H6.3" /></>),
  layers: (<><path d="m12 3 9 5-9 5-9-5z" /><path d="m3 13 9 5 9-5" /></>),
  sparkles: (<><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z" /><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z" /></>),
  file: (<><path d="M14 3H6v18h12V7z" /><path d="M14 3v4h4M9 12h6M9 16h6" /></>),
  box: (<><path d="m12 3 8.5 4.5v9L12 21l-8.5-4.5v-9z" /><path d="m3.5 7.5 8.5 4.5 8.5-4.5M12 12v9" /></>),
  wallet: (<><rect x="3" y="6" width="18" height="14" rx="2.5" /><path d="M3 10h18M16 15h2" /><path d="M6 6l10-3 1 3" /></>),
  kanban: (<><rect x="3" y="4" width="18" height="16" rx="2.5" /><path d="M8 8v6M12 8v9M16 8v4" /></>),
  shield: (<><path d="M12 3 4.5 6v5.5c0 4.6 3.2 8.1 7.5 9.5 4.3-1.4 7.5-4.9 7.5-9.5V6z" /><path d="m8.8 12 2.2 2.2 4.4-4.4" /></>),
  chart: (<><path d="M3 20h18" /><path d="M6 16v-4M11 16V8M16 16v-6M20 16V5" /></>),
  users: (<><circle cx="9" cy="8" r="3.5" /><path d="M2.5 20c.6-3.6 3.2-5.5 6.5-5.5s5.9 1.9 6.5 5.5" /><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18.5 14.8c1.6.8 2.7 2.5 3 5.2" /></>),
  refresh: (<><path d="M20 11a8 8 0 0 0-14.3-4.5L3.5 9" /><path d="M3.5 4v5h5" /><path d="M4 13a8 8 0 0 0 14.3 4.5l2.2-2.5" /><path d="M20.5 20v-5h-5" /></>),
  arrow: <path d="M5 12h14m-6-6 6 6-6 6" />,
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  alert: (<><path d="M12 3 2 20h20z" /><path d="M12 10v4.5M12 17.5v.01" /></>),
  plug: (<><path d="M9 2v5M15 2v5M6 7h12v4a6 6 0 0 1-12 0zM12 17v5" /></>),
}

export function Icon({ name, className = 'h-4 w-4' }: { name: IconName; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      {paths[name]}
    </svg>
  )
}

/** Adds `is-in` once the element scrolls into view; drives .aj-reveal and bar animations. */
export function useInView<T extends HTMLElement>() {
  const ref = useRef<T>(null)
  const [inView, setInView] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const io = new IntersectionObserver(([e]) => e.isIntersecting && (setInView(true), io.disconnect()), { threshold: 0.15 })
    io.observe(el)
    return () => io.disconnect()
  }, [])
  return [ref, inView] as const
}

export function Reveal({ children, className = '', delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const [ref, inView] = useInView<HTMLDivElement>()
  return (
    <div ref={ref} className={`aj-reveal ${inView ? 'is-in' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  )
}

export const soft = (hex: string) => `${hex}1F`

export function Pill({ accent, icon, children }: { accent: string; icon?: IconName; children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11.5px] font-bold uppercase tracking-[0.08em]" style={{ backgroundColor: soft(accent), color: accent }}>
      {icon && <Icon name={icon} className="h-3.5 w-3.5" />}
      {children}
    </span>
  )
}

export function SectionHead({ eyebrow, title, body, center = false }: { eyebrow?: string; title: ReactNode; body?: ReactNode; center?: boolean }) {
  return (
    <div className={`mb-10 max-w-[720px] ${center ? 'mx-auto text-center' : ''}`}>
      {eyebrow && <p className="mb-2 text-[13.5px] font-bold text-blue">{eyebrow}</p>}
      <h2 className="text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold leading-[1.15] tracking-[-0.02em] text-navy">{title}</h2>
      {body && <p className="mt-3 text-[15.5px] leading-[1.7] text-muted">{body}</p>}
    </div>
  )
}

export function Breadcrumb({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="mx-auto max-w-[1280px] px-6 pt-6">
      <ol className="flex flex-wrap items-center gap-1.5 text-[13px] text-muted">
        {items.map((it, i) => (
          <li key={it.label} className="flex items-center gap-1.5">
            {i > 0 && <span className="text-border">/</span>}
            {it.href ? <a href={it.href} className="transition-colors hover:text-navy">{it.label}</a> : <span aria-current="page" className="font-medium text-navy">{it.label}</span>}
          </li>
        ))}
      </ol>
    </nav>
  )
}

export function PrimaryButton({ href, children }: { href: string; children: ReactNode }) {
  return (
    <a href={href} className="inline-flex items-center gap-2 rounded-full bg-navy px-6 py-3 text-[14px] font-semibold text-white transition-colors duration-200 hover:bg-[#1E5BD8]">
      {children}
      <Icon name="arrow" className="h-4 w-4" />
    </a>
  )
}

export function GhostButton({ href, children }: { href: string; children: ReactNode }) {
  return (
    <a href={href} className="inline-flex items-center gap-2 rounded-full border border-navy/20 bg-card px-6 py-3 text-[14px] font-semibold text-navy transition-colors hover:border-navy/40">
      {children}
    </a>
  )
}

export const card = 'aj-lift rounded-2xl border border-border bg-card shadow-[0_2px_10px_rgba(23,43,77,0.04)]'

export function CtaBand({ title = 'Book a discussion or demo', body = 'Tell us how your business runs today. We will map it, and show you what one connected system could look like.' }: { title?: string; body?: string }) {
  return (
    <section className="px-6 py-16">
      <Reveal className="relative mx-auto max-w-[1280px] overflow-hidden rounded-3xl px-8 py-14 text-white md:px-14">
        <Glow tone="band" />
        <ArjavaSweep variant="panel" className="absolute -right-24 -top-24 h-[420px] w-[420px] opacity-70 max-md:hidden" />
        <div className="relative max-w-[640px]">
          <h2 className="text-[clamp(1.5rem,3vw,2.1rem)] font-extrabold leading-tight tracking-[-0.02em]">{title}</h2>
          <p className="mt-3 text-[15.5px] leading-[1.7] text-white/70">{body}</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <a href="/contact/" className="aj-pill-copper inline-flex items-center gap-2 rounded-full px-6 py-3 text-[14px] font-semibold text-white">
              Book Consultation <Icon name="arrow" />
            </a>
            <a href="mailto:hello@arjavahub.com" className="inline-flex items-center rounded-full border border-white/25 bg-white/5 px-6 py-3 text-[14px] font-semibold text-white hover:bg-white/10">
              hello@arjavahub.com
            </a>
          </div>
        </div>
      </Reveal>
    </section>
  )
}

/* ---------- Illustrations: small, editable UI scenes per module/capability ---------- */

function Frame({ title, accent, children }: { title: string; accent: string; children: ReactNode }) {
  return (
    <div className={`${card} relative overflow-hidden p-4`}>
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-[#F47B2A]/70" />
          <span className="h-2 w-2 rounded-full bg-[#F4B400]/70" />
          <span className="h-2 w-2 rounded-full bg-[#27AE60]/70" />
          <span className="ml-2 text-[11.5px] font-semibold text-navy">{title}</span>
        </div>
        <span className="flex items-center gap-1 text-[10.5px] font-semibold" style={{ color: accent }}>
          <span className="h-1.5 w-1.5 rounded-full aj-pulse" style={{ backgroundColor: accent }} /> Live
        </span>
      </div>
      {children}
    </div>
  )
}

const Line = ({ w, c = '#E2E7EF' }: { w: string; c?: string }) => <span className="block h-2 rounded-full" style={{ width: w, backgroundColor: c }} />

export function Illustration({ kind, accent }: { kind: IllustrationKind; accent: string }) {
  const [ref, inView] = useInView<HTMLDivElement>()
  return (
    <div ref={ref} className={`aj-float ${inView ? 'is-in' : ''}`}>
      {renderScene(kind, accent)}
    </div>
  )
}

function renderScene(kind: IllustrationKind, a: string) {
  switch (kind) {
    case 'rates':
      return (
        <Frame title="Quote comparison · PO-2041" accent={a}>
          <div className="grid grid-cols-[1fr_auto_auto] gap-x-4 gap-y-2 text-[11.5px]">
            <span className="font-bold text-muted">Vendor</span><span className="font-bold text-muted">Quote</span><span className="font-bold text-muted">vs history</span>
            <span className="text-navy">Vendor A</span><span className="font-semibold text-navy">₹8.7 L</span><span className="font-semibold text-green">In range</span>
            <span className="rounded bg-[#F47B2A]/10 px-1 text-navy">Vendor B</span><span className="rounded bg-[#F47B2A]/10 px-1 font-semibold text-navy">₹12.0 L</span><span className="flex items-center gap-1 rounded bg-[#F47B2A]/10 px-1 font-semibold text-orange"><Icon name="alert" className="h-3 w-3" />Above</span>
          </div>
          <div className="mt-4 space-y-1.5">
            <p className="text-[10.5px] font-semibold text-muted">Vendor rate history</p>
            <div className="flex h-16 items-end gap-1.5">
              {[52, 58, 55, 60, 57, 59, 100].map((h, i) => (
                <span key={i} className="aj-bar flex-1 rounded-t" style={{ height: `${h}%`, backgroundColor: i === 6 ? '#F47B2A' : soft(a).slice(0, 7) + '55', animationDelay: `${i * 80}ms` }} />
              ))}
            </div>
          </div>
          <p className="mt-3 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold" style={{ backgroundColor: soft(a), color: a }}>Flagged by vendor rate history, sent for review</p>
        </Frame>
      )
    case 'stock':
      return (
        <Frame title="Stock across sites" accent={a}>
          {['Main store', 'Site 1', 'Site 2', 'Warehouse'].map((s, i) => (
            <div key={s} className="mb-2.5">
              <div className="mb-1 flex justify-between text-[11px]"><span className="text-navy">{s}</span><span className="text-muted">{['Healthy', 'Low', 'Healthy', 'Re-order'][i]}</span></div>
              <div className="h-2 rounded-full bg-bg-alt"><div className="aj-hbar h-2 rounded-full" style={{ width: `${[78, 34, 64, 18][i]}%`, backgroundColor: i === 3 ? '#F47B2A' : a, animationDelay: `${i * 120}ms` }} /></div>
            </div>
          ))}
          <div className="mt-3 flex items-center gap-2 text-[11px] text-muted"><Icon name="box" className="h-3.5 w-3.5" />Live stock shown before re-ordering</div>
        </Frame>
      )
    case 'finance':
      return (
        <Frame title="Budget vs actual" accent={a}>
          <div className="flex h-28 items-end gap-3">
            {[[70, 62], [80, 84], [60, 48], [90, 76], [65, 70]].map(([b, x], i) => (
              <div key={i} className="flex flex-1 items-end gap-1">
                <span className="aj-bar flex-1 rounded-t bg-bg-alt" style={{ height: `${b}%`, animationDelay: `${i * 90}ms` }} />
                <span className="aj-bar flex-1 rounded-t" style={{ height: `${x}%`, backgroundColor: x > b ? '#F47B2A' : a, animationDelay: `${i * 90 + 60}ms` }} />
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-4 text-[10.5px] text-muted">
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-bg-alt" />Budget</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-sm" style={{ backgroundColor: a }} />Actual</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-orange" />Variance</span>
          </div>
          <svg viewBox="0 0 200 40" className="mt-3 h-10 w-full" aria-hidden="true">
            <path d="M0 30 C30 28 40 18 70 20 S120 30 140 16 180 10 200 8" fill="none" stroke={a} strokeWidth="2" />
            <path d="M140 16 C160 13 180 10 200 8" fill="none" stroke={a} strokeWidth="2" className="aj-flow" />
          </svg>
          <p className="text-[10.5px] text-muted">Cash-flow forecast</p>
        </Frame>
      )
    case 'gantt':
      return (
        <Frame title="Planned vs actual" accent={a}>
          {['Foundation', 'Structure', 'Services', 'Finishing'].map((t, i) => (
            <div key={t} className="mb-2.5 grid grid-cols-[72px_1fr] items-center gap-2 text-[11px]">
              <span className="text-navy">{t}</span>
              <div className="relative h-4">
                <span className="absolute top-0 h-1.5 rounded-full bg-bg-alt" style={{ left: `${i * 18}%`, width: '38%' }} />
                <span className="aj-hbar absolute top-2 h-1.5 rounded-full" style={{ left: `${i * 18}%`, width: `${[38, 46, 30, 12][i]}%`, backgroundColor: i === 1 ? '#F47B2A' : a, animationDelay: `${i * 150}ms` }} />
              </div>
            </div>
          ))}
          <p className="mt-2 flex items-center gap-1.5 rounded-lg bg-[#F47B2A]/10 px-2.5 py-1.5 text-[11px] font-semibold text-orange"><Icon name="alert" className="h-3.5 w-3.5" />Variance alert: Structure behind plan</p>
        </Frame>
      )
    case 'approvals':
      return (
        <Frame title="Approval trail · PR-118" accent={a}>
          <ol className="relative space-y-3 pl-6">
            <span className="absolute bottom-2 left-[9px] top-2 w-px bg-border" />
            {[['Raised on site', 'Site engineer', true], ['Reviewed', 'Project manager', true], ['Compliance check', 'AI · validity matched', true], ['Approved', 'Director', false]].map(([t, w, done], i) => (
              <li key={i} className="relative text-[11.5px]">
                <span className={`absolute -left-6 top-0.5 flex h-[18px] w-[18px] items-center justify-center rounded-full ${done ? 'text-white' : 'border-2 bg-card aj-pulse'}`} style={done ? { backgroundColor: a } : { borderColor: a }}>
                  {done && <Icon name="check" className="h-3 w-3" />}
                </span>
                <p className="font-semibold text-navy">{t as string}</p>
                <p className="text-muted">{w as string}</p>
              </li>
            ))}
          </ol>
        </Frame>
      )
    case 'doc':
      return (
        <div className="grid grid-cols-[0.8fr_auto_1fr] items-center gap-3">
          <div className={`${card} relative overflow-hidden p-3`}>
            <Icon name="file" className="mb-2 h-4 w-4 text-muted" />
            <div className="space-y-1.5"><Line w="90%" /><Line w="70%" /><Line w="80%" c={soft(a)} /><Line w="60%" /><Line w="85%" c={soft(a)} /><Line w="50%" /><Line w="75%" /></div>
            <span className="aj-scan absolute inset-x-0 h-6 bg-gradient-to-b from-transparent to-transparent" style={{ backgroundImage: `linear-gradient(to bottom, transparent, ${a}33, transparent)` }} />
          </div>
          <svg viewBox="0 0 40 20" className="h-5 w-10" aria-hidden="true"><path d="M0 10h34" stroke={a} strokeWidth="2" className="aj-flow" /><path d="m30 5 6 5-6 5" fill="none" stroke={a} strokeWidth="2" /></svg>
          <Frame title="Read by AI" accent={a}>
            {[['Document', 'Vendor quotation'], ['Vendor', 'Matched'], ['Amount', 'Extracted'], ['Terms', 'Compared'], ['Validity', 'Checked']].map(([k, v]) => (
              <div key={k} className="flex justify-between border-b border-border py-1 text-[11px] last:border-0"><span className="text-muted">{k}</span><span className="flex items-center gap-1 font-semibold text-navy"><Icon name="check" className="h-3 w-3 text-green" />{v}</span></div>
            ))}
          </Frame>
        </div>
      )
    case 'dash':
      return (
        <Frame title="Management dashboard" accent={a}>
          <div className="mb-3 grid grid-cols-3 gap-2">
            {['Purchase', 'Stock', 'Cash flow'].map((k, i) => (
              <div key={k} className="rounded-xl bg-bg-alt p-2">
                <p className="text-[10px] text-muted">{k}</p>
                <div className="mt-1.5 h-1.5 rounded-full bg-card"><div className="aj-hbar h-1.5 rounded-full" style={{ width: `${[72, 55, 64][i]}%`, backgroundColor: [a, '#27AE60', '#1E5BD8'][i], animationDelay: `${i * 120}ms` }} /></div>
              </div>
            ))}
          </div>
          <div className="flex h-20 items-end gap-1">
            {[30, 45, 38, 52, 48, 60, 56, 70, 64, 78, 72, 86].map((h, i) => (
              <span key={i} className="aj-bar flex-1 rounded-t" style={{ height: `${h}%`, backgroundColor: i > 9 ? a : `${a}55`, animationDelay: `${i * 50}ms` }} />
            ))}
          </div>
          <div className="mt-3 flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold" style={{ backgroundColor: soft(a), color: a }}><Icon name="alert" className="h-3.5 w-3.5" />Real-time alert routed to owner</div>
        </Frame>
      )
    case 'pipeline':
      return (
        <Frame title="Sales pipeline" accent={a}>
          <div className="grid grid-cols-3 gap-2">
            {[['Leads', 3], ['Deals', 2], ['Won', 1]].map(([s, n], c) => (
              <div key={s as string} className="rounded-xl bg-bg-alt p-2">
                <p className="mb-1.5 text-[10.5px] font-bold text-muted">{s as string}</p>
                {Array.from({ length: n as number }).map((_, i) => (
                  <div key={i} className="mb-1.5 rounded-lg border border-border bg-card p-1.5" style={c === 2 ? { borderColor: a } : undefined}>
                    <Line w="80%" c={c === 2 ? soft(a) : undefined} />
                    <span className="mt-1 block"><Line w="50%" /></span>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <p className="mt-2 flex items-center gap-1.5 text-[11px] text-muted"><Icon name="arrow" className="h-3.5 w-3.5" />Won deals flow into delivery & billing</p>
        </Frame>
      )
    case 'sync':
    case 'store':
      return (
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2">
          <Frame title="Online store" accent={a}>
            <div className="grid grid-cols-2 gap-1.5">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="rounded-lg bg-bg-alt p-1.5"><div className="mb-1 h-8 rounded" style={{ backgroundColor: i % 2 ? `${a}33` : '#E2E7EF' }} /><Line w="70%" /></div>
              ))}
            </div>
            <div className="mt-2 rounded-lg py-1 text-center text-[10.5px] font-bold text-white" style={{ backgroundColor: a }}>Checkout</div>
          </Frame>
          <div className="flex flex-col gap-2">
            {['Orders', 'Stock', 'Invoices'].map((t) => (
              <div key={t} className="flex flex-col items-center">
                <span className="text-[9.5px] font-semibold text-muted">{t}</span>
                <svg viewBox="0 0 40 8" className="h-2 w-10" aria-hidden="true"><path d="M0 4h40" stroke={a} strokeWidth="2" className="aj-flow" /></svg>
              </div>
            ))}
          </div>
          <Frame title="Arjava ERP" accent="#172B4D">
            {['Order received', 'Stock reserved', 'Invoice with GST', 'Shipment tracked'].map((t) => (
              <div key={t} className="flex items-center gap-1.5 py-1 text-[10.5px] text-navy"><Icon name="check" className="h-3 w-3 text-green" />{t}</div>
            ))}
          </Frame>
        </div>
      )
    case 'roadmap':
      return (
        <Frame title="Workflow map" accent={a}>
          <svg viewBox="0 0 280 140" className="w-full" aria-hidden="true">
            {[[30, 30, 'Request'], [140, 30, 'Approve'], [250, 30, 'Purchase'], [250, 105, 'Receive'], [140, 105, 'Pay'], [30, 105, 'Report']].map(([x, y, t], i, arr) => {
              const n = arr[(i + 1) % arr.length]
              return (
                <g key={t as string}>
                  {i < arr.length - 1 && <line x1={x as number} y1={y as number} x2={n[0] as number} y2={n[1] as number} stroke={a} strokeWidth="1.5" className="aj-flow" />}
                  <rect x={(x as number) - 32} y={(y as number) - 13} width="64" height="26" rx="8" fill={i === 1 ? a : '#fff'} stroke={i === 1 ? a : '#E2E7EF'} />
                  <text x={x as number} y={(y as number) + 4} textAnchor="middle" fontSize="10" fontWeight="600" fill={i === 1 ? '#fff' : '#172B4D'}>{t as string}</text>
                </g>
              )
            })}
            <circle cx="195" cy="30" r="6" fill="#F47B2A" className="aj-pulse" />
            <text x="195" y="56" textAnchor="middle" fontSize="9" fill="#F47B2A" fontWeight="700">Gap found</text>
          </svg>
        </Frame>
      )
    case 'website':
      return (
        <Frame title="arjavahub.com" accent={a}>
          <div className="rounded-xl bg-navy p-3">
            <span className="block h-2 w-1/2 rounded-full bg-white/80" />
            <span className="mt-1.5 block h-2 w-1/3 rounded-full bg-white/40" />
            <span className="mt-3 inline-block rounded-md px-2 py-0.5 text-[9.5px] font-bold text-navy" style={{ backgroundColor: a }}>Capability statement</span>
          </div>
          <div className="mt-2 grid grid-cols-3 gap-1.5">
            {['Services', 'Projects', 'Industries'].map((t) => (
              <div key={t} className="rounded-lg bg-bg-alt p-1.5"><p className="mb-1 text-[9.5px] font-semibold text-navy">{t}</p><Line w="80%" /><span className="mt-1 block"><Line w="55%" /></span></div>
            ))}
          </div>
        </Frame>
      )
    case 'portal':
      return (
        <div className="grid grid-cols-[1.2fr_0.7fr] items-end gap-3">
          <Frame title="Vendor portal" accent={a}>
            {['Submit quotation', 'Upload invoice', 'Track payment'].map((t, i) => (
              <div key={t} className="mb-1.5 flex items-center justify-between rounded-lg bg-bg-alt px-2 py-1.5 text-[11px]">
                <span className="text-navy">{t}</span>
                <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: i === 2 ? '#F4B400' : '#27AE60' }} />
              </div>
            ))}
            <div className="mt-2 flex items-center gap-1.5 text-[10.5px] text-muted"><Icon name="plug" className="h-3.5 w-3.5" />Connected via API</div>
          </Frame>
          <div className={`${card} mx-auto w-full max-w-[120px] rounded-[20px] p-2`}>
            <div className="rounded-[14px] bg-bg-alt p-2">
              <p className="text-[9.5px] font-bold text-navy">Site app</p>
              <div className="mt-2 space-y-1.5"><Line w="85%" /><Line w="60%" c={soft(a)} /><Line w="70%" /></div>
              <div className="mt-3 rounded-md py-1 text-center text-[9px] font-bold text-white" style={{ backgroundColor: a }}>Update</div>
            </div>
          </div>
        </div>
      )
  }
}
