import { useEffect, useMemo, useState } from 'react'
import { capabilities, findModule, modules, type Module } from './data'
import { PlanToCash } from './diagrams'
import { journey, specs, type Status, type WorkflowStep } from './moduleSpecs'
import { ScreenBand, type ScreenKey } from './brandArt'
import { Breadcrumb, CtaBand, GhostButton, Icon, PrimaryButton, Reveal, card } from './ui'

const wrap = 'mx-auto max-w-[1280px] px-6'
export const mono = 'font-mono tracking-tight'
export const ink = (hex: string) => (hex === '#172B4D' ? '#F47B2A' : hex)

const statusStyle: Record<Status, { c: string; label: string }> = {
  ok: { c: '#27AE60', label: 'OK' },
  warn: { c: '#F47B2A', label: 'Attention' },
  flag: { c: '#E5484D', label: 'Flag' },
  wait: { c: '#F4B400', label: 'Pending' },
  info: { c: '#F47B2A', label: 'Info' },
}

function Dot({ s }: { s: Status }) {
  return <span className="inline-block h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: statusStyle[s].c }} aria-label={statusStyle[s].label} />
}

export function Eyebrow({ code, children }: { code: string; children: string }) {
  return (
    <p className="mb-3 text-[13.5px] font-bold text-forest">
            {children}
    </p>
  )
}

/* ================================ SYSTEM MAP ================================ */

type Station = { slug: string; x: number; y: number }
const BUS = 236
const stations: Station[] = [
  { slug: 'crm-sales', x: 110, y: 96 },
  { slug: 'projects-tasks', x: 305, y: 96 },
  { slug: 'purchase-vendors', x: 500, y: 96 },
  { slug: 'inventory-stock', x: 695, y: 96 },
  { slug: 'store-erp-sync', x: 890, y: 96 },
  { slug: 'approvals-audit', x: 210, y: 372 },
  { slug: 'finance-cash-flow', x: 500, y: 372 },
  { slug: 'dashboards-mis', x: 790, y: 372 },
  { slug: 'ai-document-intelligence', x: 650, y: 470 },
]
const st = (slug: string) => stations.find((s) => s.slug === slug)!
const route = (a: Station, b: Station) => `M${a.x} ${a.y} L${a.x} ${BUS} L${b.x} ${BUS} L${b.x} ${b.y}`

function SystemMap() {
  const [i, setI] = useState(0)
  const [playing, setPlaying] = useState(true)
  const [focus, setFocus] = useState<string | null>(null)
  useEffect(() => {
    if (!playing) return
    const t = setInterval(() => setI((x) => (x + 1) % journey.length), 2800)
    return () => clearInterval(t)
  }, [playing])
  const cur = journey[i]
  const prev = journey[(i - 1 + journey.length) % journey.length]
  const visited = new Set(journey.slice(0, i + 1).map((j) => j.module))
  const shown = findModule(focus ?? cur.module)!
  const spec = specs[shown.slug]
  const go = (k: number) => (setI(k), setPlaying(false), setFocus(null))

  return (
    <div className={`${card} overflow-hidden`}>
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-card px-5 py-3">
        <div className="flex items-center gap-3">
          <span className={`${mono} text-[11px] font-bold text-muted`}>SYS-MAP</span>
          <span className="text-[14px] font-bold text-navy">Follow one order through the system</span>
        </div>
        <div className="flex items-center gap-1.5">
          <button type="button" onClick={() => go((i - 1 + journey.length) % journey.length)} aria-label="Previous event" className="h-8 w-8 cursor-pointer rounded-lg border border-border text-navy hover:bg-bg-alt">‹</button>
          <button type="button" onClick={() => setPlaying((p) => !p)} className="h-8 cursor-pointer rounded-lg bg-navy px-3 text-[12.5px] font-semibold text-white" aria-pressed={playing}>{playing ? 'Pause' : 'Play'}</button>
          <button type="button" onClick={() => go((i + 1) % journey.length)} aria-label="Next event" className="h-8 w-8 cursor-pointer rounded-lg border border-border text-navy hover:bg-bg-alt">›</button>
          <span className={`${mono} ml-2 text-[12px] text-muted`}>{String(i + 1).padStart(2, '0')}/{String(journey.length).padStart(2, '0')}</span>
        </div>
      </div>

      <div className="flex items-center gap-3 border-b border-border bg-bg px-5 py-2 text-[12.5px]" aria-live="polite">
        <span className="aj-pulse h-2 w-2 rounded-full bg-orange" />
        <span className={`${mono} text-orange`}>{cur.record}</span>
        <span className="font-semibold text-navy">{findModule(cur.module)!.name}</span>
        <span className="hidden text-muted sm:inline">· {cur.event}</span>
      </div>
      <div className="grid lg:grid-cols-[1fr_340px]">
        {/* map (desktop/tablet) */}
        <div className="aj-blueprint relative hidden md:block">
          <svg viewBox="0 0 1000 505" className="h-auto w-full" role="img" aria-label="System map of Arjava modules connected by a shared database">
            {/* shared database bus */}
            <rect x="40" y={BUS - 7} width="920" height="14" rx="7" fill="#172B4D" />
            <text x="48" y={BUS + 30} fontSize="10.5" fontWeight="800" fill="#172B4D" letterSpacing="2.5" paintOrder="stroke" stroke="#F7F9FC" strokeWidth="6">SHARED DATABASE</text>
            <text x="48" y={BUS + 45} fontSize="10" fill="#5B6B82" className="font-mono" paintOrder="stroke" stroke="#F7F9FC" strokeWidth="6">one record per transaction</text>
            {/* AI layer band */}
            <rect x="40" y="446" width="920" height="48" rx="12" fill="#1EB4D4" fillOpacity="0.08" stroke="#1EB4D4" strokeOpacity="0.35" strokeDasharray="4 4" />
            <text x="60" y="466" fontSize="10.5" fontWeight="800" fill="#1EB4D4" letterSpacing="2.5">AI LAYER</text>
            <text x="60" y="482" fontSize="10.5" fill="#1EB4D4">extraction · rate comparison · variance · forecasting · compliance</text>
            {/* stubs */}
            {stations.map((s) => (
              <line key={s.slug} x1={s.x} y1={s.y} x2={s.x} y2={BUS} stroke={visited.has(s.slug) ? '#F47B2A' : '#C7D0DD'} strokeWidth="2" />
            ))}
            {/* active route + packet */}
            <path key={`r${i}`} d={route(st(prev.module), st(cur.module))} fill="none" stroke="#F47B2A" strokeWidth="3" strokeLinejoin="round" className="aj-flow" />
            <circle key={`p${i}`} r="7" fill="#F47B2A" stroke="#fff" strokeWidth="2">
              <animateMotion dur="1.1s" fill="freeze" path={route(st(prev.module), st(cur.module))} />
            </circle>
            {/* stations */}
            {stations.filter((s) => s.slug !== 'ai-document-intelligence').map((s) => {
              const m = findModule(s.slug)!
              const active = cur.module === s.slug
              const f = focus === s.slug
              return (
                <g key={s.slug} transform={`translate(${s.x - 82} ${s.y - 30})`} className="cursor-pointer" onMouseEnter={() => setFocus(s.slug)} onMouseLeave={() => setFocus(null)} onClick={() => setFocus(s.slug)}>
                  <rect width="164" height="60" rx="10" fill={active ? '#172B4D' : '#fff'} stroke={active ? '#172B4D' : f ? m.accent : visited.has(s.slug) ? '#F47B2A' : '#E2E7EF'} strokeWidth={f ? 2 : 1.25} />
                  <rect x="0" y="0" width="5" height="60" rx="2.5" fill={ink(m.accent)} />
                  <text x="16" y="22" fontSize="10" className="font-mono" fill={active ? '#F47B2A' : '#5B6B82'}>{specs[s.slug].code} · {specs[s.slug].short}</text>
                  <text x="16" y="42" fontSize="13" fontWeight="700" fill={active ? '#fff' : '#172B4D'}>{m.name}</text>
                  {active && <circle cx="150" cy="14" r="4" fill="#F47B2A" className="aj-pulse" />}
                </g>
              )
            })}
            {(() => {
              const s = st('ai-document-intelligence')
              const active = cur.module === s.slug
              return (
                <g transform={`translate(${s.x - 92} ${s.y - 22})`} className="cursor-pointer" onMouseEnter={() => setFocus(s.slug)} onMouseLeave={() => setFocus(null)}>
                  <rect width="184" height="44" rx="22" fill={active ? '#1EB4D4' : '#fff'} stroke="#1EB4D4" strokeWidth="1.5" />
                  <text x="92" y="27" textAnchor="middle" fontSize="12" fontWeight="700" fill={active ? '#fff' : '#0E7F7F'}>AI Document Intelligence</text>
                </g>
              )
            })()}
          </svg>
        </div>

        {/* event log + inspector */}
        <div className="border-t border-border bg-card lg:border-l lg:border-t-0">
          <ol className="max-h-[300px] overflow-y-auto p-3 lg:max-h-none" aria-label="Order journey">
            {journey.map((j, k) => {
              const m = findModule(j.module)!
              const on = k === i
              return (
                <li key={k}>
                  <button type="button" onClick={() => go(k)} aria-current={on ? 'step' : undefined} className={`grid w-full cursor-pointer grid-cols-[22px_1fr] gap-2 rounded-lg px-2 py-2 text-left transition-colors ${on ? 'bg-bg-alt' : 'hover:bg-bg'}`}>
                    <span className={`${mono} pt-0.5 text-[11px] ${k <= i ? 'text-blue' : 'text-[#C7D0DD]'}`}>{String(k + 1).padStart(2, '0')}</span>
                    <span>
                      <span className="block text-[12.5px] font-bold text-navy">{m.name}</span>
                      <span className="block text-[12px] leading-snug text-muted">{j.event}</span>
                    </span>
                  </button>
                </li>
              )
            })}
          </ol>
          <div className="border-t border-border p-4">
            <p className={`${mono} text-[11px] text-muted`}>{spec.code} · INSPECT</p>
            <p className="mt-1 text-[15px] font-bold text-navy">{shown.name}</p>
            <p className="mt-1 text-[12.5px] leading-snug text-muted">{shown.tagline}</p>
            <a href={`/modules/${shown.slug}/`} className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-semibold text-blue hover:underline">Open module <Icon name="arrow" className="h-3.5 w-3.5" /></a>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ================================ REGISTER ================================ */

function ModuleRegister() {
  return (
    <div className={`${card} overflow-hidden`}>
      <div className="hidden grid-cols-[90px_1.1fr_1.6fr_150px_40px] gap-4 border-b border-border bg-bg-alt px-5 py-2.5 text-[11px] font-bold uppercase tracking-[0.1em] text-muted md:grid">
        <span>Code</span><span>Module</span><span>Problem it addresses</span><span>Records</span><span />
      </div>
      <ul>
        {modules.map((m) => {
          const s = specs[m.slug]
          return (
            <li key={m.slug} className="border-b border-border last:border-0">
              <a href={`/modules/${m.slug}/`} className="group grid gap-x-4 gap-y-1 px-5 py-4 transition-colors hover:bg-bg md:grid-cols-[90px_1.1fr_1.6fr_150px_40px] md:items-center">
                <span className={`${mono} flex items-center gap-2 text-[12px] font-semibold text-navy`}><span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: ink(m.accent) }} />{s.code}</span>
                <span>
                  <span className="block text-[15px] font-bold text-navy">{m.name}</span>
                  <span className="block text-[12.5px] text-muted">{m.tagline}</span>
                </span>
                <span className="text-[13.5px] leading-snug text-navy/80">{m.problem}</span>
                <span className="flex flex-wrap gap-1">{s.entities.slice(0, 3).map((e) => <span key={e.name} className="rounded bg-bg-alt px-1.5 py-0.5 text-[11px] text-muted">{e.name}</span>)}</span>
                <span className="hidden h-8 w-8 items-center justify-center rounded-full border border-border text-navy transition-all group-hover:border-navy group-hover:bg-navy group-hover:text-white md:flex"><Icon name="arrow" className="h-3.5 w-3.5" /></span>
              </a>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

/* ================================ HUB PAGE ================================ */

export function ModulesHub() {
  return (
    <main className="pt-16">
      <Breadcrumb items={[{ label: 'Home', href: '/' }, { label: 'Modules' }]} />
      <section className={`${wrap} grid gap-10 pb-12 pt-8 lg:grid-cols-[1.2fr_0.8fr] lg:items-end`}>
        <Reveal>
          <Eyebrow code="ERP-CORE">Arjava modules</Eyebrow>
          <h1 className="text-[clamp(2rem,4.6vw,3.3rem)] font-extrabold leading-[1.06] tracking-[-0.03em] text-navy">One system. Every transaction, recorded once.</h1>
          <p className="mt-5 max-w-[620px] text-[16.5px] leading-[1.75] text-muted">Each module handles one part of the business. All of them write to the same database, so an order won in sales is the same record that purchase buys for, stores receive, and finance pays.</p>
        </Reveal>
        <Reveal delay={120}>
          <dl className="grid grid-cols-2 overflow-hidden rounded-2xl border border-border bg-card text-navy">
            {[['Modules', String(modules.length)], ['Database', 'Shared'], ['AI layer', 'Human-reviewed'], ['Built around', 'Your workflows']].map(([k, v], i) => (
              <div key={k} className={`p-4 ${i % 2 ? 'border-l' : ''} ${i > 1 ? 'border-t' : ''} border-border`}>
                <dt className={`${mono} text-[11px] uppercase text-muted`}>{k}</dt>
                <dd className="mt-1 text-[17px] font-extrabold">{v}</dd>
              </div>
            ))}
          </dl>
        </Reveal>
      </section>
      <ScreenBand screen="dashboard" second="costLeaks" title="The command dashboard every module reports into" />

      <section className={`${wrap} pb-20`}>
        <SystemMap />
        <p className="mt-3 text-[12px] text-muted">Illustrative walk-through with sample record numbers. Hover a module on the map to inspect it.</p>
      </section>

      <section className="border-y border-border bg-bg-alt py-20">
        <div className={wrap}>
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <Eyebrow code="REGISTER">Module register</Eyebrow>
              <h2 className="text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold tracking-[-0.02em] text-navy">Nine modules, and what each one fixes</h2>
            </div>
            <p className="max-w-[420px] text-[14px] leading-[1.65] text-muted">Start with the module that addresses your most pressing problem. The rest connect to it when you are ready.</p>
          </div>
          <ModuleRegister />
        </div>
      </section>

      <section className="py-20">
        <div className={wrap}>
          <Eyebrow code="CYCLE">Run every stage in one flow</Eyebrow>
          <h2 className="mb-10 text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold tracking-[-0.02em] text-navy">Plan to cash, in one system</h2>
          <PlanToCash />
        </div>
      </section>
      <CtaBand title="Not sure which module to start with?" body="Tell us where things slip today. We will map the workflow and recommend where to begin." />
    </main>
  )
}

/* ================================ MODULE PAGE PARTS ================================ */

export function Screen({ step, accent }: { step: WorkflowStep; accent: string }) {
  const s = step.screen
  return (
    <div className="overflow-hidden rounded-xl border border-[#E2E7EF] bg-card shadow-[0_18px_50px_rgba(23,43,77,0.12)]">
      <div className="flex items-center justify-between border-b border-border bg-bg-alt px-4 py-2.5">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-[#E2E7EF]" /><span className="h-2.5 w-2.5 rounded-full bg-[#E2E7EF]" /><span className="h-2.5 w-2.5 rounded-full bg-[#E2E7EF]" />
          <span className="ml-2 text-[12px] font-semibold text-navy">Arjava</span>
          <span className="text-[12px] text-muted">/ {s.heading}</span>
        </div>
        <span className={`${mono} rounded bg-card px-1.5 py-0.5 text-[11px] text-navy`}>{s.ref}</span>
      </div>
      <div key={step.title} className="aj-screen-in space-y-0 p-4">
        <p className="mb-3 text-[16px] font-bold text-navy">{s.heading}</p>
        {s.rows.map(([k, v, st]) => (
          <div key={k} className="flex items-center justify-between gap-3 border-t border-border py-2.5 text-[13px]">
            <span className="text-muted">{k}</span>
            <span className="flex items-center gap-2 text-right font-semibold text-navy">{v}{st && <Dot s={st} />}</span>
          </div>
        ))}
        {s.banner && (
          <div className="mt-3 flex items-center gap-2 rounded-lg px-3 py-2 text-[12.5px] font-semibold" style={{ backgroundColor: `${statusStyle[s.banner[0]].c}14`, color: statusStyle[s.banner[0]].c }}>
            <Icon name={s.banner[0] === 'info' ? 'check' : 'alert'} className="h-4 w-4" />{s.banner[1]}
          </div>
        )}
        {s.action && (
          <div className="mt-3 flex justify-end gap-2">
            <span className="rounded-lg border border-border px-3 py-1.5 text-[12px] font-semibold text-navy">Comment</span>
            <span className="rounded-lg px-3 py-1.5 text-[12px] font-semibold text-white" style={{ backgroundColor: accent === '#F4B400' ? '#172B4D' : ink(accent) === '#F47B2A' ? '#172B4D' : accent }}>{s.action}</span>
          </div>
        )}
      </div>
    </div>
  )
}

const STEP_MS = 3600

export function WorkflowSimulator({ m }: { m: Module }) {
  return <Simulator steps={specs[m.slug].workflow} accent={m.accent} label={`${m.name} workflow`} />
}

export function Simulator({ steps, accent, label }: { steps: WorkflowStep[]; accent: string; label: string }) {
  const [i, setI] = useState(0)
  const [playing, setPlaying] = useState(true)
  useEffect(() => {
    if (!playing) return
    const t = setTimeout(() => setI((x) => (x + 1) % steps.length), STEP_MS)
    return () => clearTimeout(t)
  }, [i, playing, steps.length])
  const a = ink(accent)
  return (
    <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
      <ol className="relative" aria-label={label}>
        <span className="absolute bottom-6 left-[19px] top-6 w-px bg-[#E2E7EF]" aria-hidden="true" />
        {steps.map((s, k) => {
          const on = k === i
          return (
            <li key={s.title} className="relative">
              <button type="button" onClick={() => (setI(k), setPlaying(false))} aria-current={on ? 'step' : undefined} className={`grid w-full cursor-pointer grid-cols-[40px_1fr] gap-3 rounded-xl py-3 pr-3 text-left transition-colors ${on ? 'bg-card shadow-[0_8px_24px_rgba(23,43,77,0.08)]' : 'hover:bg-card/60'}`}>
                <span className="relative z-[1] mx-auto mt-0.5 flex h-[26px] w-[26px] items-center justify-center rounded-full border-2 text-[11px] font-bold transition-colors" style={{ borderColor: k <= i ? a : '#E2E7EF', backgroundColor: k < i ? a : on ? '#fff' : '#fff', color: k < i ? '#fff' : on ? a : '#5B6B82' }}>
                  {k < i ? <Icon name="check" className="h-3 w-3" /> : k + 1}
                </span>
                <span className="min-w-0">
                  <span className="flex flex-wrap items-baseline justify-between gap-x-3">
                    <span className="text-[15px] font-bold text-navy">{s.title}</span>
                    <span className={`${mono} text-[11px] text-muted`}>{s.actor}</span>
                  </span>
                  <span className={`block overflow-hidden text-[13px] leading-snug text-muted transition-all duration-300 ${on ? 'mt-1 max-h-20 opacity-100' : 'max-h-0 opacity-0'}`}>{s.note}</span>
                  {on && (
                    <span className="mt-2.5 block h-[3px] overflow-hidden rounded-full bg-bg-alt">
                      <span key={`${i}-${playing}`} className={`block h-full rounded-full ${playing ? 'aj-step-progress' : ''}`} style={{ backgroundColor: a, animationDuration: `${STEP_MS}ms`, width: playing ? '100%' : '100%', transform: playing ? undefined : 'scaleX(1)' }} />
                    </span>
                  )}
                </span>
              </button>
            </li>
          )
        })}
        <li className="mt-3 pl-[52px]">
          <button type="button" onClick={() => setPlaying((p) => !p)} aria-pressed={playing} className="cursor-pointer rounded-lg border border-border bg-card px-3 py-1.5 text-[12.5px] font-semibold text-navy hover:border-navy/30">
            {playing ? 'Pause walkthrough' : 'Play walkthrough'}
          </button>
        </li>
      </ol>
      <div className="aj-blueprint relative rounded-2xl border border-border p-4 sm:p-8 lg:sticky lg:top-24">
        <span className={`${mono} absolute left-4 top-2 text-[10.5px] text-muted`}>STEP {String(i + 1).padStart(2, '0')} / {String(steps.length).padStart(2, '0')} · {steps[i].actor.toUpperCase()}</span>
        <div className="mt-4"><Screen step={steps[i]} accent={accent} /></div>
        <p className="mt-3 text-[11.5px] text-muted">Illustrative screen with sample data.</p>
      </div>
    </div>
  )
}

function RecordMap({ m }: { m: Module }) {
  const s = specs[m.slug]
  const a = ink(m.accent)
  return (
    <div className="aj-blueprint overflow-x-auto rounded-2xl border border-border p-5 sm:p-8">
      <div className="flex min-w-max items-stretch gap-0">
        {s.entities.map((e, k) => (
          <div key={e.name} className="flex items-center">
            {k > 0 && (
              <svg viewBox="0 0 64 24" className="h-6 w-16 shrink-0" aria-hidden="true">
                <path d="M0 12h56" stroke={a} strokeWidth="1.6" className="aj-flow" />
                <path d="m52 7 6 5-6 5" fill="none" stroke={a} strokeWidth="1.6" />
              </svg>
            )}
            <div className="w-[210px] overflow-hidden rounded-xl border border-[#E2E7EF] bg-card">
              <div className="flex items-center justify-between border-b border-border px-3 py-2" style={{ backgroundColor: `${a}12` }}>
                <span className="text-[13px] font-bold text-navy">{e.name}</span>
                <span className={`${mono} text-[10px] text-muted`}>{s.short}.{String(k + 1).padStart(2, '0')}</span>
              </div>
              <ul className="px-3 py-2">
                {e.fields.map((f, j) => (
                  <li key={f} className="flex items-center gap-2 py-1 text-[12px] text-navy/80">
                    <span className={`${mono} w-4 text-[10px] ${j === 0 ? 'text-orange' : 'text-[#C7D0DD]'}`}>{j === 0 ? 'PK' : '·'}</span>{f}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function ConnectionMap({ m }: { m: Module }) {
  const s = specs[m.slug]
  // Alternate related modules left/right of the centre; direction is carried by arrows and packets.
  const sides = [s.flows.filter((_, k) => k % 2 === 0), s.flows.filter((_, k) => k % 2 === 1)]
  const pts = sides.flatMap((list, side) =>
    list.map((f, k) => {
      const x = side === 0 ? -265 : 265
      const y = list.length === 1 ? 0 : k === 0 ? -78 : 78
      return { ...f, x, y, mod: findModule(f.to)! }
    }),
  )
  return (
    <div className="aj-blueprint relative overflow-hidden rounded-2xl border border-border">
      <svg viewBox="-345 -150 690 300" className="h-auto w-full" role="img" aria-label={`${m.name} connections`}>
        {pts.map((p, k) => {
          const cx = p.x < 0 ? -78 : 78
          const nx = p.x < 0 ? p.x + 72 : p.x - 72
          const out = p.dir === 'out'
          const d = out ? `M${cx} ${p.y * 0.25} C${(cx + nx) / 2} ${p.y * 0.25} ${(cx + nx) / 2} ${p.y} ${nx} ${p.y}` : `M${nx} ${p.y} C${(cx + nx) / 2} ${p.y} ${(cx + nx) / 2} ${p.y * 0.25} ${cx} ${p.y * 0.25}`
          const lx = p.x < 0 ? -150 : 150
          const c = ink(p.mod.accent)
          return (
            <g key={p.to}>
              <path d={d} fill="none" stroke="#E2E7EF" strokeWidth="2" />
              <path d={d} fill="none" stroke={c} strokeWidth="2" className="aj-flow" />
              <circle r="4.5" fill={c} stroke="#fff" strokeWidth="1.5">
                <animateMotion dur="2.2s" begin={`${k * 0.45}s`} repeatCount="indefinite" path={d} />
              </circle>
              <text x={lx} y={p.y * 0.62 - 9} textAnchor="middle" fontSize="10.5" fontWeight="700" fill="#172B4D" paintOrder="stroke" stroke="#F7F9FC" strokeWidth="5">
                {out ? `${p.label} →` : `← ${p.label}`}
              </text>
              <text x={lx} y={p.y * 0.62 + 18} textAnchor="middle" fontSize="8.5" className="font-mono" fill={out ? '#F47B2A' : '#F47B2A'} paintOrder="stroke" stroke="#F7F9FC" strokeWidth="4">
                {out ? 'OUT' : 'IN'}
              </text>
            </g>
          )
        })}
        <rect x="-78" y="-32" width="156" height="64" rx="14" fill="#172B4D" />
        <text textAnchor="middle" y="-7" fontSize="10" className="font-mono" fill="#F47B2A">{s.code}</text>
        <text textAnchor="middle" y="13" fontSize={m.name.length > 20 ? 11 : 13} fontWeight="800" fill="#fff">{m.name}</text>
        {pts.map((p) => (
          <a key={p.to} href={`/modules/${p.to}/`} aria-label={p.mod.name}>
            <g transform={`translate(${p.x} ${p.y})`} className="cursor-pointer">
              <rect x="-72" y="-22" width="144" height="44" rx="10" fill="#fff" stroke={ink(p.mod.accent)} strokeWidth="1.5" />
              <text textAnchor="middle" y="-4" fontSize="8.5" className="font-mono" fill="#5B6B82">{specs[p.to].code}</text>
              <text textAnchor="middle" y="11" fontSize={p.mod.name.length > 20 ? 9.5 : 11} fontWeight="700" fill="#172B4D">{p.mod.name}</text>
            </g>
          </a>
        ))}
      </svg>
    </div>
  )
}

/* ================================ MODULE PAGE ================================ */

export function ModulePage({ m }: { m: Module }) {
  const s = specs[m.slug]
  const idx = modules.indexOf(m)
  const a = ink(m.accent)
  const caps = capabilities.filter((c) => c.modules.includes(m.slug))
  const connected = useMemo(() => s.flows.map((f) => findModule(f.to)!), [s])
  return (
    <main className="pt-16">
      <Breadcrumb items={[{ label: 'Home', href: '/' }, { label: 'Modules', href: '/modules/' }, { label: m.name }]} />

      {/* hero + spec sheet */}
      <section className={`${wrap} grid gap-10 pb-14 pt-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-start`}>
        <Reveal>
          <Eyebrow code={`${s.code} · ${s.short}`}>{`Module ${idx + 1} of ${modules.length}`}</Eyebrow>
          <h1 className="text-[clamp(2rem,4.6vw,3.3rem)] font-extrabold leading-[1.06] tracking-[-0.03em] text-navy">{m.name}</h1>
          <p className="mt-3 text-[19px] font-semibold leading-snug" style={{ color: a }}>{m.tagline}</p>
          <p className="mt-4 max-w-[600px] text-[16px] leading-[1.75] text-muted">{m.summary}</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <PrimaryButton href="/contact/">Discuss this module</PrimaryButton>
            <GhostButton href="#workflow">See the workflow</GhostButton>
          </div>
        </Reveal>
        <Reveal delay={120}>
          <div className="aj-blueprint-dark overflow-hidden rounded-2xl text-white shadow-[0_20px_60px_rgba(23,43,77,0.25)]">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
              <span className={`${mono} text-[11px] text-blue`}>SPEC SHEET</span>
              <span className={`${mono} text-[11px] text-white/50`}>{s.code}</span>
            </div>
            <dl className="divide-y divide-white/10 px-5 text-[13px]">
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Plan-to-cash</dt><dd className="font-semibold">{m.stage}</dd></div>
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Records</dt><dd className="flex flex-wrap gap-1">{s.entities.map((e) => <span key={e.name} className="rounded bg-white/[0.08] px-1.5 py-0.5 text-[12px]">{e.name}</span>)}</dd></div>
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Connects to</dt><dd className="flex flex-wrap gap-1">{connected.map((c) => <a key={c.slug} href={`/modules/${c.slug}/`} className="rounded bg-white/[0.08] px-1.5 py-0.5 text-[12px] hover:bg-white/[0.16]">{c.name}</a>)}</dd></div>
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">AI-assisted</dt><dd className="text-white/80">{m.ai}</dd></div>
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Workflow</dt><dd className="font-semibold">{s.workflow.length} steps, configured to your approval rules</dd></div>
            </dl>
          </div>
        </Reveal>
      </section>
      <ScreenBand screen={moduleScreen[m.slug] ?? 'dashboard'} second={moduleSecond[m.slug]} title={`${m.name}, in the product`} />

      {/* problem */}
      <section className={`${wrap} pb-16`}>
        <div className="grid overflow-hidden rounded-2xl border border-border md:grid-cols-2">
          <div className="bg-[#F47B2A]/[0.06] p-6">
            <p className={`${mono} text-[11px] font-bold text-orange`}>BEFORE</p>
            <p className="mt-2 text-[16px] font-semibold leading-snug text-navy">{m.problem}</p>
          </div>
          <div className="border-t border-border bg-card p-6 md:border-l md:border-t-0">
            <p className={`${mono} text-[11px] font-bold`} style={{ color: a }}>WITH {m.name.toUpperCase()}</p>
            <p className="mt-2 text-[16px] font-semibold leading-snug text-navy">{m.tagline} {m.features[0].body}</p>
          </div>
        </div>
      </section>

      {/* workflow simulator */}
      <section id="workflow" className="scroll-mt-20 border-y border-border bg-bg-alt py-20">
        <div className={wrap}>
          <Eyebrow code="WF">How the work flows</Eyebrow>
          <h2 className="mb-10 max-w-[900px] text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold tracking-[-0.02em] text-navy">A {m.name.toLowerCase()} workflow, step by step</h2>
          <WorkflowSimulator m={m} />
        </div>
      </section>

      {/* records */}
      <section className="py-20">
        <div className={wrap}>
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <Eyebrow code="DATA">What it records</Eyebrow>
              <h2 className="text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold tracking-[-0.02em] text-navy">The records this module manages</h2>
            </div>
            <p className="max-w-[420px] text-[14px] leading-[1.65] text-muted">Each record links to the next, so you can trace any figure back to where it started. Fields are shaped around your terminology.</p>
          </div>
          <RecordMap m={m} />
          <ul className="mt-6 grid gap-x-8 gap-y-3 sm:grid-cols-2">
            {m.features.map((f) => (
              <li key={f.title} className="flex gap-3 border-t border-border pt-3">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-sm" style={{ backgroundColor: a }} />
                <span><span className="block text-[14.5px] font-bold text-navy">{f.title}</span><span className="block text-[13.5px] leading-[1.6] text-muted">{f.body}</span></span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* connections + questions */}
      <section className="border-y border-border bg-bg-alt py-20">
        <div className={`${wrap} grid gap-10 lg:grid-cols-[1.25fr_0.75fr] lg:items-center`}>
          <div>
            <Eyebrow code="LINKS">How it connects</Eyebrow>
            <h2 className="mb-6 text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold tracking-[-0.02em] text-navy">What flows in and out</h2>
            <ConnectionMap m={m} />
          </div>
          <div>
            <p className={`${mono} mb-3 text-[11px] font-bold text-muted`}>QUESTIONS IT ANSWERS</p>
            <ol className="space-y-3">
              {s.questions.map((q, k) => (
                <li key={q} className={`${card} flex gap-3 p-4`}>
                  <span className={`${mono} text-[12px] font-bold`} style={{ color: a }}>Q{k + 1}</span>
                  <span className="text-[15px] font-semibold leading-snug text-navy">“{q}”</span>
                </li>
              ))}
            </ol>
            {m.result && (
              <div className="mt-5 rounded-2xl bg-navy p-5 text-white">
                <p className={`${mono} text-[11px] text-blue`}>RESULT A CLIENT HAS SEEN</p>
                <p className="mt-1 text-[2rem] font-black leading-none">{m.result.value}</p>
                <p className="mt-2 text-[13px] leading-[1.6] text-white/75">{m.result.label}: {m.result.note}</p>
                <p className="mt-2 text-[11px] text-white/45">Client-reported, human-reviewed. Results vary and are not guaranteed.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* module rail */}
      <section className="py-14">
        <div className={wrap}>
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <p className={`${mono} text-[11px] font-bold text-muted`}>ALL MODULES</p>
            {caps.length > 0 && (
              <p className="text-[13px] text-muted">Delivered through {caps.map((c, k) => <span key={c.slug}>{k > 0 && ', '}<a href={`/services/${c.slug}/`} className="font-semibold text-navy hover:text-blue">{c.name}</a></span>)}</p>
            )}
          </div>
          <nav aria-label="Modules" className="-mx-6 overflow-x-auto px-6">
            <ol className="flex min-w-max gap-2">
              {modules.map((x) => {
                const on = x.slug === m.slug
                return (
                  <li key={x.slug}>
                    <a href={`/modules/${x.slug}/`} aria-current={on ? 'page' : undefined} className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-[13px] font-semibold transition-colors ${on ? 'border-navy bg-navy text-white' : 'border-border bg-card text-navy hover:border-navy/30'}`}>
                      <span className={`${mono} text-[11px] ${on ? 'text-blue' : 'text-muted'}`}>{specs[x.slug].code}</span>{x.name}
                    </a>
                  </li>
                )
              })}
            </ol>
          </nav>
        </div>
      </section>
      <CtaBand title={`Want to talk about ${m.name}?`} body="Tell us how this part of the business runs today. We will map it and show you what the module would look like around your workflow." />
    </main>
  )
}


export const moduleScreen: Record<string, ScreenKey> = {
  'purchase-vendors': 'procurement', 'inventory-stock': 'inventory', 'finance-cash-flow': 'costLeaks', 'projects-tasks': 'schedule',
  'approvals-audit': 'procurement', 'crm-sales': 'dashboard', 'ai-document-intelligence': 'extractDone', 'dashboards-mis': 'quantity', 'store-erp-sync': 'equipment',
}
export const moduleSecond: Record<string, ScreenKey> = {
  'purchase-vendors': 'costLeaks', 'inventory-stock': 'equipment', 'finance-cash-flow': 'dashboard', 'projects-tasks': 'routeMap',
  'ai-document-intelligence': 'assistant', 'dashboards-mis': 'project', 'crm-sales': 'extractStart',
}

