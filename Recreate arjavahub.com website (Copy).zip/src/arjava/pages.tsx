import { capabilities, modules } from './data'
import { HumanInTheLoop, PlanToCash, PlatformDiagram, Results, Stages } from './diagrams'
import { ScreenBand } from './brandArt'
import { Principles, VisibilityDashboard } from './sections'
import { Breadcrumb, CtaBand, Icon, Pill, Reveal, SectionHead, card } from './ui'

const wrap = 'mx-auto max-w-[1280px] px-6'

/* ------------------------------ /how-it-works/ ------------------------------ */

export function HowItWorks() {
  return (
    <main className="pt-16">
      <Breadcrumb items={[{ label: 'Home', href: '/' }, { label: 'How it works' }]} />
      <section className={`${wrap} pb-14 pt-8`}>
        <Reveal className="max-w-[800px]">
          <Pill accent="#F47B2A" icon="refresh">How it works · proof · next step</Pill>
          <h1 className="mt-4 text-[clamp(2rem,4.6vw,3.3rem)] font-extrabold leading-[1.08] tracking-[-0.03em] text-navy">How Arjava connects your business</h1>
          <p className="mt-5 text-[16.5px] leading-[1.75] text-muted">Website, store and business data flow into one ERP; AI reads, compares and flags; management sees one live picture.</p>
        </Reveal>
      </section>

      <section className={`${wrap} pb-20`}>
        <p className="mb-4 text-[13.5px] font-bold text-muted">The connected platform at a glance</p>
        <PlatformDiagram />
        <div className="mt-6"><HumanInTheLoop /></div>
      </section>

      <section className="border-y border-border bg-bg-alt py-20">
        <div className={wrap}>
          <SectionHead eyebrow="Run every stage in one flow" title="Plan to cash, in one system" body="Plan, review, buy, stock, deliver and collect, each stage handled by a module on the same database." />
          <PlanToCash />
        </div>
      </section>

      <section className="py-20">
        <div className={wrap}>
          <SectionHead eyebrow="Proof" title="Results clients have seen" />
          <Results />
        </div>
      </section>

      <section className="border-y border-border bg-bg-alt py-20">
        <div className={wrap}>
          <SectionHead eyebrow="Delivery approach" title="A discussion or demo, then six clear stages" body="Discover, plan, build and configure, test and validate, deploy, then support and improve. Every stage is a milestone you can see and track." />
          <Stages />
        </div>
      </section>

      <VisibilityDashboard id="hiw-visibility" />
      <Principles id="hiw-principles" />

      <section className="py-20">
        <div className={wrap}>
          <SectionHead title="Where to go next" />
          <div className="grid gap-4 md:grid-cols-2">
            <a href="/services/" className={`${card} group p-6 hover:border-navy/20`}><p className="text-[16px] font-bold text-navy">Six connected capabilities</p><p className="mt-1 text-[14px] text-muted">Consulting, digital presence, custom software, e-commerce, ERP and AI.</p><span className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-semibold text-blue">Explore services <Icon name="arrow" className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" /></span></a>
            <a href="/modules/" className={`${card} group p-6 hover:border-navy/20`}><p className="text-[16px] font-bold text-navy">Nine ERP modules</p><p className="mt-1 text-[14px] text-muted">Purchase, inventory, finance, projects, approvals, CRM, AI, dashboards and store sync.</p><span className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-semibold text-blue">Explore modules <Icon name="arrow" className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" /></span></a>
          </div>
        </div>
      </section>
      <ScreenBand screen="extractDone" second="procurement" eyebrow="From tender to order" title="A tender PDF in the morning, a procurement plan by the afternoon" body="The tender is read and its eligibility mapped; once awarded, the project's procurement plan is built against the same record." />
      <CtaBand />
    </main>
  )
}
