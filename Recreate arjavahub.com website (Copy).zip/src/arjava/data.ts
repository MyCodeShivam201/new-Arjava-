// Content sourced from Arjava's capability briefs ("About Arjava" and "Arjava Innovation Info").

export type IconName =
  | 'compass' | 'globe' | 'code' | 'cart' | 'layers' | 'sparkles' | 'file' | 'box' | 'wallet'
  | 'kanban' | 'shield' | 'chart' | 'users' | 'refresh' | 'arrow' | 'check' | 'alert' | 'plug'

export type IllustrationKind =
  | 'rates' | 'stock' | 'finance' | 'gantt' | 'approvals' | 'doc' | 'dash' | 'pipeline' | 'sync'
  | 'roadmap' | 'website' | 'portal' | 'store'

export interface Capability {
  slug: string
  verb: string
  name: string
  short: string
  outcome: string
  accent: string
  icon: IconName
  intro: string
  deliverables: { title: string; body: string }[]
  problems: { problem: string; solution: string; detail: string }[]
  illustration: IllustrationKind
  modules: string[]
}

export const capabilities: Capability[] = [
  {
    slug: 'business-process-consulting',
    verb: 'Understand',
    name: 'Business & Process Consulting',
    short: 'Process discovery, workflow mapping, gap analysis & quick wins, transformation roadmap.',
    outcome: 'Clear priorities before you invest',
    accent: '#1E5BD8',
    icon: 'compass',
    intro:
      'Before a single screen is designed, we map how your business actually runs: who raises a request, who approves it, where the data lives and where it gets lost. You get a clear, prioritised picture of what to fix first and what to build.',
    deliverables: [
      { title: 'Process discovery', body: 'Sessions with the people doing the work, across purchase, stores, site, finance and management.' },
      { title: 'Workflow mapping', body: 'Every request, approval and handoff drawn end to end, in your own terminology.' },
      { title: 'Gap analysis & quick wins', body: 'Where spreadsheets, email and WhatsApp are hiding cost, delay or risk, and what can be fixed immediately.' },
      { title: 'Transformation roadmap', body: 'A phased plan: which modules first, which integrations, and how each phase pays back.' },
    ],
    problems: [
      { problem: 'Business data scattered across spreadsheets, email and WhatsApp', solution: 'Workflow map & roadmap', detail: 'One documented picture of how data moves today, and where it should live tomorrow.' },
      { problem: 'Delays and cost overruns discovered too late', solution: 'Gap analysis', detail: 'We find the handoffs where problems hide before deciding what software to build.' },
    ],
    illustration: 'roadmap',
    modules: ['approvals-audit', 'dashboards-mis'],
  },
  {
    slug: 'digital-presence',
    verb: 'Communicate',
    name: 'Digital Presence & Brand',
    short: 'Corporate websites, capability statements & pitch decks, project portfolios, brand collateral, SEO.',
    outcome: 'Win trust with clients and investors',
    accent: '#1EB4D4',
    icon: 'globe',
    intro:
      'Your capabilities deserve to be communicated as clearly as you deliver them. We build the corporate website, capability statement, pitch deck and project portfolio that help clients, partners and investors understand what you do.',
    deliverables: [
      { title: 'Corporate websites', body: 'Fast, search-friendly websites that explain your services, industries and track record.' },
      { title: 'Capability statements & pitch decks', body: 'Decision-maker documents for tenders, clients and investors.' },
      { title: 'Project portfolios', body: 'Completed work presented with scope, scale and outcome.' },
      { title: 'Brand collateral & SEO', body: 'Consistent brand assets, and the search foundations to be found.' },
    ],
    problems: [
      { problem: 'Your capabilities are not communicated clearly to clients', solution: 'Digital Presence', detail: 'Corporate website, capability statement, pitch deck and portfolio.' },
    ],
    illustration: 'website',
    modules: ['crm-sales'],
  },
  {
    slug: 'custom-software-apps',
    verb: 'Build',
    name: 'Custom Software & Apps',
    short: 'Web applications, customer & vendor portals, mobile apps & PWAs, APIs & third-party integrations.',
    outcome: 'Software shaped around how you work',
    accent: '#6A5BD8',
    icon: 'code',
    intro:
      "When no off-the-shelf product fits a workflow, we build one that does. Web applications, portals for customers and vendors, mobile apps and the integrations that connect them to the systems you already use.",
    deliverables: [
      { title: 'Web applications', body: 'Purpose-built tools for the workflows that make your business different.' },
      { title: 'Customer & vendor portals', body: 'Let customers track orders and vendors submit quotes and bills directly.' },
      { title: 'Mobile apps & PWAs', body: 'Site updates, approvals and stock entries from the field, on any device.' },
      { title: 'APIs & integrations', body: 'Connect banks, GST, stores and third-party tools so data is entered once.' },
    ],
    problems: [
      { problem: 'Teams lose hours on manual paperwork and document checks', solution: 'Purpose-built apps', detail: 'Field and office teams capture data once, at the source.' },
    ],
    illustration: 'portal',
    modules: ['projects-tasks', 'approvals-audit'],
  },
  {
    slug: 'ecommerce-development',
    verb: 'Sell',
    name: 'E-Commerce Development',
    short: 'Custom stores, Shopify & Shopify Plus, WooCommerce, custom themes, payments & GST, marketplace sync.',
    outcome: 'Storefronts built to convert and scale',
    accent: '#F47B2A',
    icon: 'cart',
    intro:
      'From a custom-built store to Shopify, Shopify Plus or WooCommerce, we build storefronts on bespoke themes with payments, shipping and tracking, and connect them to your ERP so orders, inventory and invoices flow without double entry.',
    deliverables: [
      { title: 'Custom-built e-commerce stores', body: 'Bespoke storefronts for catalogues and checkouts that templates cannot handle.' },
      { title: 'Shopify, Shopify Plus & WooCommerce', body: 'Stores on the platform that fits, with custom theme development.' },
      { title: 'Headless & PWA storefronts', body: 'Fast, app-like shopping experiences on any device.' },
      { title: 'B2B & dealer ordering portals', body: 'Repeat orders, dealer pricing and credit, online.' },
      { title: 'Payments, shipping & marketplaces', body: 'Payment gateways, GST, shipping, tracking and marketplace sync.' },
      { title: 'Store-to-ERP sync', body: 'Orders, inventory and invoices flow automatically into the ERP.' },
    ],
    problems: [
      { problem: 'Sales limited to walk-ins, calls and offline orders', solution: 'Conversion-Ready Store', detail: 'Custom, Shopify or WooCommerce store on a bespoke theme, with payments, shipping and tracking.' },
      { problem: 'Online orders, stock and accounts managed separately', solution: 'Store-to-ERP Sync', detail: 'Orders, inventory and invoices flow automatically, with no double entry.' },
    ],
    illustration: 'store',
    modules: ['store-erp-sync', 'inventory-stock', 'finance-cash-flow'],
  },
  {
    slug: 'erp-automation',
    verb: 'Connect',
    name: 'Custom ERP & Automation',
    short: 'Purchase, inventory & finance modules, project & task tracking, approvals, roles & audit trails, integrations.',
    outcome: 'One source of truth across teams',
    accent: '#F47B2A',
    icon: 'layers',
    intro:
      'One ERP, built around your workflows. Purchase, inventory, finance, projects and approvals run on a single shared database, so a purchase order raised on-site reflects immediately in the finance queue and the inventory count.',
    deliverables: [
      { title: 'Purchase, inventory & finance', body: 'Vendor rates, POs, goods receipt, stock and payments in one flow.' },
      { title: 'Project & task tracking', body: 'Planned vs actual, task ownership and variance alerts.' },
      { title: 'Approvals, roles & audit trails', body: 'Every approval recorded: who, when and against which budget.' },
      { title: 'Integrations', body: 'Store, bank and GST links so data flows in without re-keying.' },
    ],
    problems: [
      { problem: 'Business data scattered across spreadsheets, email and WhatsApp', solution: 'Connected ERP', detail: 'One source of truth for operations, purchases, stock and finance.' },
      { problem: 'No clear view of purchase prices, vendors or stock levels', solution: 'Purchase & Inventory Control', detail: 'Vendor rate history, price comparison, approvals and live stock before re-ordering.' },
      { problem: 'Cash flow, payables and receivables hard to track', solution: 'Financial Control', detail: 'Budget vs actual, payment status and cash-flow forecasting.' },
    ],
    illustration: 'dash',
    modules: ['purchase-vendors', 'inventory-stock', 'finance-cash-flow', 'projects-tasks', 'approvals-audit'],
  },
  {
    slug: 'ai-business-intelligence',
    verb: 'Decide',
    name: 'AI & Business Intelligence',
    short: 'AI document reading, rate comparison & anomaly flags, variance & cash-flow forecasting, dashboards & MIS.',
    outcome: 'Faster, data-backed decisions',
    accent: '#1EB4D4',
    icon: 'sparkles',
    intro:
      'An AI layer sits on top of your ERP. It reads invoices, quotes, tenders and contracts, compares rates against history, flags mismatches and forecasts variance and cash flow. Your team reviews and decides.',
    deliverables: [
      { title: 'AI document reading', body: 'Invoices, quotes, tenders and contracts read on arrival, in whatever format the sender used.' },
      { title: 'Rate comparison & anomaly flags', body: 'Every quote checked against vendor rate history before it is approved.' },
      { title: 'Variance & cash-flow forecasting', body: 'See where budgets and cash are heading, not just where they have been.' },
      { title: 'Dashboards & MIS', body: 'Live dashboards, real-time alerts and board-ready MIS reports.' },
    ],
    problems: [
      { problem: 'Teams lose hours on manual paperwork and document checks', solution: 'AI Document Intelligence', detail: 'AI reads invoices, quotes and contracts, extracts key data and flags mismatches.' },
      { problem: 'Delays and cost overruns discovered too late', solution: 'Live Dashboards & Alerts', detail: 'Planned vs actual, task ownership and variance alerts.' },
    ],
    illustration: 'doc',
    modules: ['ai-document-intelligence', 'dashboards-mis', 'purchase-vendors'],
  },
]

export interface Module {
  slug: string
  name: string
  tagline: string
  accent: string
  icon: IconName
  summary: string
  problem: string
  related: string[]
  features: { title: string; body: string }[]
  inputs: string[]
  outputs: string[]
  ai: string
  illustration: IllustrationKind
  stage: string
  result?: { value: string; label: string; note: string }
}

export const modules: Module[] = [
  {
    slug: 'purchase-vendors',
    name: 'Purchase & Vendors',
    tagline: 'Know the right price before you approve it.',
    accent: '#F47B2A',
    icon: 'cart',
    summary:
      'Purchase requests, vendor quotes, comparisons, POs and goods receipt tracked end to end, with vendor rate history and price comparison in front of the approver.',
    problem: 'No clear view of purchase prices, vendors or stock levels.',
    related: ['inventory-stock', 'approvals-audit', 'finance-cash-flow'],
    features: [
      { title: 'Purchase requests', body: 'Raised from site or office, routed to the right approver.' },
      { title: 'Vendor quotes & comparison', body: 'Quotes from different formats compared side by side.' },
      { title: 'Vendor rate history', body: 'Every new rate checked against what you have paid before.' },
      { title: 'POs & goods receipt', body: 'Purchase order to delivery, matched against the bill.' },
    ],
    inputs: ['Vendor quotes & POs', 'Purchase requests'],
    outputs: ['Approvals & audit', 'Inventory & delivery'],
    ai: 'AI reads vendor quotations and flags rates that sit outside the vendor rate history.',
    illustration: 'rates',
    stage: 'Buy',
    result: { value: '₹3.3 L', label: 'Price gap on one purchase order', note: '₹12.0 L quote vs ₹8.7 L, flagged by vendor rate history (≈27.5% saved).' },
  },
  {
    slug: 'inventory-stock',
    name: 'Inventory & Stock',
    tagline: 'Live stock, across every site and store.',
    accent: '#27AE60',
    icon: 'box',
    summary:
      'Stock and site updates recorded where they happen, so purchase sees live stock before re-ordering and management has multi-site visibility.',
    problem: 'Stock is counted in registers and spreadsheets, so nobody is sure what is on hand before re-ordering.',
    related: ['purchase-vendors', 'store-erp-sync', 'projects-tasks'],
    features: [
      { title: 'Live stock levels', body: 'Receipts, issues and transfers update stock immediately.' },
      { title: 'Multi-site visibility', body: 'See stock at every site, store and warehouse in one view.' },
      { title: 'Re-order checks', body: 'Live stock shown before any new purchase is raised.' },
      { title: 'Store & online sync', body: 'Online orders reserve and deduct the same stock.' },
    ],
    inputs: ['Stock & site updates', 'Online store orders'],
    outputs: ['Inventory & delivery', 'Multi-site visibility'],
    ai: 'Sales and stock insights highlight slow-moving items and unusual consumption.',
    illustration: 'stock',
    stage: 'Stock',
  },
  {
    slug: 'finance-cash-flow',
    name: 'Finance & Cash Flow',
    tagline: 'Finance connected to operations in real time.',
    accent: '#1E5BD8',
    icon: 'wallet',
    summary:
      'Invoices, bills, expenses, payments and receivables in one place, with budget vs actual, payment status and cash-flow forecasting.',
    problem: 'Cash flow, payables and receivables are hard to track.',
    related: ['purchase-vendors', 'approvals-audit', 'dashboards-mis'],
    features: [
      { title: 'Budget vs actual', body: 'Every commitment measured against its budget as it is raised.' },
      { title: 'Accounts payable & receivable', body: 'Payment status for every bill and every invoice, with follow-ups on what is due.' },
      { title: 'Bank reconciliation', body: 'Bank transactions matched against recorded payments and receipts.' },
      { title: 'Cash-flow forecasting', body: 'Upcoming payments and collections projected forward.' },
      { title: 'Bank & GST links', body: 'Bank and payment data, and GST, connected to the ledger.' },
    ],
    inputs: ['Invoices & bills', 'Expenses & receipts', 'Bank & payments'],
    outputs: ['Finance & cash flow', 'MIS & board reports'],
    ai: 'Variance detection and cash-flow forecasting surface problems before month-end.',
    illustration: 'finance',
    stage: 'Collect',
  },
  {
    slug: 'projects-tasks',
    name: 'Projects & Tasks',
    tagline: 'Planned vs actual, before it becomes an overrun.',
    accent: '#F47B2A',
    icon: 'kanban',
    summary:
      'Projects, tasks and site progress tracked with clear ownership, so delays and cost overruns are visible while there is still time to act.',
    problem: 'Delays and cost overruns are discovered too late.',
    related: ['inventory-stock', 'dashboards-mis', 'approvals-audit'],
    features: [
      { title: 'Planned vs actual', body: 'Schedule and cost progress against plan, per project.' },
      { title: 'Task ownership', body: 'Every task has an owner and a due date.' },
      { title: 'Variance alerts', body: 'Alerts when time or cost drifts beyond tolerance.' },
      { title: 'Site updates', body: 'Progress captured from site on mobile.' },
    ],
    inputs: ['Stock & site updates', 'Purchase & vendors'],
    outputs: ['Projects & tasks', 'Real-time alerts'],
    ai: 'Variance detection compares progress against plan and flags drift early.',
    illustration: 'gantt',
    stage: 'Deliver',
  },
  {
    slug: 'approvals-audit',
    name: 'Approvals & Audit',
    tagline: 'Every approval recorded, end to end.',
    accent: '#172B4D',
    icon: 'shield',
    summary:
      'Roles, approval chains and audit trails across every module, so every purchase and payment can be traced from request to payment.',
    problem: 'Approvals happen over calls, email and WhatsApp, with no record of who approved what.',
    related: ['purchase-vendors', 'finance-cash-flow', 'ai-document-intelligence'],
    features: [
      { title: 'Approval workflows', body: 'Multi-level approvals that match your authority matrix.' },
      { title: 'Roles & permissions', body: 'Each person sees and does what their role allows.' },
      { title: 'Audit trail', body: 'Who did what, when, and against which document.' },
      { title: 'Compliance checks', body: 'Documents checked against rules before submission.' },
    ],
    inputs: ['Approvals & audit', 'Purchase & vendors'],
    outputs: ['Approvals & audit', 'MIS & board reports'],
    ai: 'Compliance checks validate documents, such as EMD validity against the latest corrigendum.',
    illustration: 'approvals',
    stage: 'Review',
    result: { value: 'Caught', label: 'Validity mismatch flagged', note: 'EMD validity checked against the latest corrigendum; rejection avoided before submission.' },
  },
  {
    slug: 'crm-sales',
    name: 'CRM & Sales',
    tagline: 'Sales and operations, aligned.',
    accent: '#6A5BD8',
    icon: 'users',
    summary:
      'Leads, deals, customers and follow-ups linked to delivery and billing so sales and operations stay aligned.',
    problem: 'Sales, delivery and billing work from different lists, so follow-ups slip.',
    related: ['projects-tasks', 'finance-cash-flow', 'store-erp-sync'],
    features: [
      { title: 'Leads & deals', body: 'A pipeline that shows where every opportunity stands.' },
      { title: 'Follow-ups', body: 'Reminders and ownership so no customer is forgotten.' },
      { title: 'Linked to delivery', body: 'Won deals become projects and orders automatically.' },
      { title: 'Linked to billing', body: 'Invoices raised from the same customer record.' },
    ],
    inputs: ['Online store orders', 'Leads & enquiries'],
    outputs: ['Projects & tasks', 'Sales & stock insights'],
    ai: 'Sales insights highlight which customers and products drive revenue.',
    illustration: 'pipeline',
    stage: 'Plan',
  },
  {
    slug: 'ai-document-intelligence',
    name: 'AI Document Intelligence',
    tagline: 'The paperwork reads itself.',
    accent: '#1EB4D4',
    icon: 'sparkles',
    summary:
      'Tender notices, vendor quotations, invoices and purchase orders read on arrival. AI extracts the key fields into the ERP and flags mismatches for your team to review.',
    problem: 'Teams lose hours on manual paperwork and document checks.',
    related: ['purchase-vendors', 'approvals-audit', 'dashboards-mis'],
    features: [
      { title: 'Document extraction', body: 'Key fields pulled from PDFs and scans into structured data.' },
      { title: 'Comparison sheets', body: 'Quotes and tender terms laid out side by side automatically.' },
      { title: 'Mismatch flags', body: 'Differences between documents highlighted for review.' },
      { title: 'Eligibility checks', body: "Tender criteria validated against your company profile." },
    ],
    inputs: ['Invoices & bills', 'Vendor quotes & POs', 'Tender notices'],
    outputs: ['Approvals & audit', 'Real-time alerts'],
    ai: 'Human-in-the-loop: AI reads, compares and flags; your team reviews and decides.',
    illustration: 'doc',
    stage: 'Review',
    result: { value: '3–5 min', label: 'Document evaluation time', note: 'AI-assisted extraction into a structured comparison sheet; was 1–2 days.' },
  },
  {
    slug: 'dashboards-mis',
    name: 'Dashboards & MIS',
    tagline: 'One live picture for management.',
    accent: '#F4B400',
    icon: 'chart',
    summary:
      'Live dashboards, real-time alerts, MIS and board reports drawn from the same database every team works in, with multi-site visibility.',
    problem: 'Management reports are assembled by hand, after the fact.',
    related: ['projects-tasks', 'finance-cash-flow', 'inventory-stock'],
    features: [
      { title: 'Live dashboards', body: 'Purchase, stock, projects and finance on one screen.' },
      { title: 'Real-time alerts', body: 'Exceptions pushed to the right person as they happen.' },
      { title: 'MIS & board reports', body: 'Reports generated from live data, not assembled by hand.' },
      { title: 'Multi-site visibility', body: 'Compare sites, projects and stores side by side.' },
    ],
    inputs: ['All ERP modules'],
    outputs: ['Live dashboards', 'MIS & board reports', 'Real-time alerts'],
    ai: 'Forecasts and anomaly flags appear alongside the numbers they relate to.',
    illustration: 'dash',
    stage: 'Plan',
  },
  {
    slug: 'store-erp-sync',
    name: 'Store-to-ERP Sync',
    tagline: 'Orders, stock and invoices, with no double entry.',
    accent: '#1EB4D4',
    icon: 'refresh',
    summary:
      'Your custom, Shopify or WooCommerce store connected to the ERP. Orders, inventory and invoices flow automatically, including marketplace sync, payments and GST.',
    problem: 'Online orders, stock and accounts are managed separately.',
    related: ['inventory-stock', 'finance-cash-flow', 'crm-sales'],
    features: [
      { title: 'Order sync', body: 'Online orders arrive in the ERP the moment they are placed.' },
      { title: 'Inventory sync', body: 'One stock count across store, marketplaces and warehouse.' },
      { title: 'Invoices & GST', body: 'Invoices generated with GST from the order itself.' },
      { title: 'Payments & shipping', body: 'Payment status and shipment tracking on the same record.' },
    ],
    inputs: ['Online store orders', 'Bank & payments'],
    outputs: ['Inventory & delivery', 'Store, bank & GST links'],
    ai: 'Sales and stock insights connect what sells online to what needs re-ordering.',
    illustration: 'sync',
    stage: 'Deliver',
  },
]

export const dataIn = ['Documents & invoices', 'Purchase requests', 'Financial records', 'Inventory movements', 'Operational & site updates', 'Online store orders']
export const coreModules = ['Business workflows', 'Procurement & inventory', 'Finance & accounts', 'Projects & reporting', 'Validation & approvals', 'Integrations']
export const decisionsOut = ['Organized information', 'Operational reports & MIS', 'Status visibility', 'Management decisions', 'Actionable notifications']
export const aiLayer = ['Document extraction', 'Rate comparison', 'Variance detection', 'Cash-flow forecasting', 'Compliance checks']

export const cycle = ['Plan', 'Review', 'Buy', 'Stock', 'Deliver', 'Collect']
export const cycleDetail: Record<string, string> = {
  Plan: 'Budgets, projects and sales targets set in the same system that will track them.',
  Review: 'Requests, quotes and documents reviewed, with AI flags in front of the approver.',
  Buy: 'POs raised against compared quotes and vendor rate history.',
  Stock: 'Goods received, matched to the PO and reflected in live stock.',
  Deliver: 'Material issued to site, project or customer order, with progress tracked.',
  Collect: 'Invoices raised, payments tracked and cash flow forecast.',
}

export const stages = [
  { name: 'Discover', body: 'Understand the business', detail: 'We learn how the business runs today: the people, processes, requirements, constraints and users. No assumptions.' },
  { name: 'Plan', body: 'Agree scope & priorities', detail: 'Scope, priorities, workflows and the implementation approach are defined and agreed before anything is built.' },
  { name: 'Build & Configure', body: 'Shape it around you', detail: 'The solution is developed or configured around the agreed requirements, module by module, with regular reviews.' },
  { name: 'Test & Validate', body: 'Prove it on real work', detail: 'Important workflows and data are tested before the system becomes part of day-to-day operations.' },
  { name: 'Deploy', body: 'Go live with training', detail: 'The solution is introduced through an implementation approach that suits your teams, with data migration and training.' },
  { name: 'Support & Improve', body: 'Grow with the business', detail: 'We stay on after launch: monitoring, fixes and new capabilities as your requirements evolve.' },
]

export const results = [
  { value: '3–5 min', label: 'Document evaluation time', note: 'AI-assisted extraction into a structured comparison sheet', was: 'was 1–2 days' },
  { value: '₹3.3 L', label: 'Price gap on one purchase order', note: '₹12.0 L quote vs ₹8.7 L, flagged by vendor rate history', was: '≈27.5% saved' },
  { value: 'Caught', label: 'Validity mismatch flagged', note: 'EMD validity checked against the latest corrigendum; rejection avoided', was: 'before submission' },
]

export const builtFor = ['Growing SMEs', 'Services & projects', 'Manufacturing & trading', 'Construction & infrastructure', 'Retail & D2C']

export const findModule = (slug: string) => modules.find((m) => m.slug === slug)
export const findCapability = (slug: string) => capabilities.find((c) => c.slug === slug)
