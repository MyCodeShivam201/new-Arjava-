import { Fragment, useState } from 'react'
import { builtFor, capabilities, findModule, type Capability, type Module } from './data'
import { HumanInTheLoop, Results, Stages } from './diagrams'
import { specs } from './moduleSpecs'
import { Eyebrow, Simulator, ink, moduleScreen, moduleSecond, mono } from './modules'
import { ScreenBand } from './brandArt'
import { serviceSpecs } from './serviceSpecs'
import { Breadcrumb, CtaBand, GhostButton, Icon, PrimaryButton, Reveal, card } from './ui'

const wrap = 'mx-auto max-w-[1280px] px-6'
const h2 = 'text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold tracking-[-0.02em] text-navy'
const cap = (slug: string) => capabilities.find((c) => c.slug === slug)!

type Pillar = { n: string; title: string; body: string; items: string[]; href: string; accent: string; icon: 'compass' | 'layers' | 'code'; caps: string[] }
// Wording of the three pillars matches arjavahub.com/services/.
export const pillars: Pillar[] = [
  { n: '01', title: 'Consulting & Strategy', href: '/services/consulting-strategy/', accent: '#1E5BD8', icon: 'compass', body: 'Understand how the business runs before deciding what to build.', items: ['Business Process Transformation', 'Digital Strategy & Roadmap', 'Technology Advisory', 'Enterprise Architecture'], caps: ['business-process-consulting'] },
  { n: '02', title: 'Enterprise Solutions', href: '/services/enterprise-solutions/', accent: '#F47B2A', icon: 'layers', body: 'Systems built and implemented around how your business already works.', items: ['ERP Implementation & Modernization', 'Custom Business Solutions', 'Digital Platforms', 'Migration & Upgradation'], caps: ['erp-automation', 'custom-software-apps'] },
  { n: '03', title: 'Digital & Technology', href: '/services/digital-technology/', accent: '#1EB4D4', icon: 'code', body: 'Cloud, AI, and applications that extend your systems to every device.', items: ['Cloud & Applications', 'AI Tools & Integration', 'Web & Mobile Services'], caps: ['digital-presence', 'ecommerce-development', 'ai-business-intelligence'] },
]
const pillarOf = (slug: string) => pillars.find((p) => p.caps.includes(slug))!
const ordered = () => pillars.flatMap((p) => p.caps.map(cap))

function Pillars() {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {pillars.map((p, k) => (
        <Reveal key={p.title} delay={k * 80}>
          <div className={`${card} group flex h-full flex-col overflow-hidden`} style={{ borderTop: `3px solid ${p.accent}` }}>
            <a href={p.href} className="block flex-1 p-6 transition-colors hover:bg-bg">
              <div className="flex items-start justify-between">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl" style={{ backgroundColor: `${p.accent}14`, color: p.accent }}><Icon name={p.icon} className="h-5 w-5" /></span>
                <span className={`${mono} text-[13px] font-bold`} style={{ color: p.accent }}>{p.n}</span>
              </div>
              <h3 className="mt-5 text-[21px] font-extrabold tracking-[-0.01em] text-navy">{p.title}</h3>
              <p className="mt-2 text-[14.5px] leading-[1.6] text-muted">{p.body}</p>
              <ul className="mt-5 space-y-2.5 border-t border-border pt-5">
                {p.items.map((it) => <li key={it} className="flex items-center gap-2.5 text-[14px] font-medium text-navy"><span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: p.accent }} />{it}</li>)}
              </ul>
              <span className="mt-6 inline-flex items-center gap-1.5 text-[14px] font-semibold" style={{ color: p.accent }}>Explore the service <Icon name="arrow" className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" /></span>
            </a>
            <div className="aj-blueprint border-t border-border px-6 py-4">
              <p className={`${mono} mb-2 text-[10.5px] font-bold text-muted`}>INCLUDES</p>
              <ul className="space-y-1">
                {p.caps.map((sl) => {
                  const c = cap(sl)
                  return <li key={sl}><a href={`/services/${sl}/`} className="flex items-center gap-2 rounded-md py-1 text-[13px] font-semibold text-navy hover:text-blue"><span className={`${mono} w-12 text-[11px] text-muted`}>{serviceSpecs[sl].code}</span><span className="flex-1">{c.name}</span><Icon name="arrow" className="h-3 w-3 text-muted" /></a></li>
                })}
              </ul>
            </div>
          </div>
        </Reveal>
      ))}
    </div>
  )
}

/* ---------------- business blueprint: where each capability sits ---------------- */

type Zone = { slug: string; x: number; y: number; w: number; h: number; sub: string }
const zones: Zone[] = [
  { slug: 'business-process-consulting', x: 40, y: 24, w: 920, h: 56, sub: 'Strategy & roadmap across the whole business' },
  { slug: 'digital-presence', x: 250, y: 140, w: 160, h: 74, sub: 'Website, decks, portfolio' },
  { slug: 'ecommerce-development', x: 250, y: 330, w: 160, h: 74, sub: 'Storefront & dealer portal' },
  { slug: 'custom-software-apps', x: 466, y: 112, w: 284, h: 352, sub: 'Custom apps & portals' },
  { slug: 'erp-automation', x: 495, y: 200, w: 210, h: 170, sub: 'ERP core · one database' },
  { slug: 'ai-business-intelligence', x: 800, y: 200, w: 160, h: 90, sub: 'Read · compare · forecast' },
]
const flows: { d: string; label: string; by: string[]; lx: number; ly: number }[] = [
  { d: 'M180 177 H250', label: '', by: ['digital-presence'], lx: 0, ly: 0 },
  { d: 'M410 177 C460 177 450 240 495 240', label: 'enquiries', by: ['digital-presence', 'erp-automation'], lx: 436, ly: 166 },
  { d: 'M180 367 H250', label: '', by: ['ecommerce-development'], lx: 0, ly: 0 },
  { d: 'M410 367 C460 367 450 330 495 330', label: 'orders', by: ['ecommerce-development', 'erp-automation'], lx: 436, ly: 396 },
  { d: 'M705 245 H800', label: 'live data', by: ['erp-automation', 'ai-business-intelligence'], lx: 752, ly: 237 },
  { d: 'M880 290 V410', label: 'decisions', by: ['ai-business-intelligence'], lx: 890, ly: 355 },
  { d: 'M600 80 V200', label: 'priorities', by: ['business-process-consulting', 'erp-automation'], lx: 608, ly: 150 },
]

function BusinessBlueprint() {
  const [sel, setSel] = useState('erp-automation')
  const c = cap(sel)
  const s = serviceSpecs[sel]
  const mods = c.modules.map(findModule).filter(Boolean) as Module[]
  return (
    <div className={`${card} overflow-hidden`}>
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-5 py-3">
        <p className={`${mono} text-[11px] font-bold text-muted`}>BUSINESS BLUEPRINT · SELECT A CAPABILITY</p>
        <p className="text-[12.5px] text-muted">Where each capability sits between the outside world, your operations and management.</p>
      </div>
      <div className="grid lg:grid-cols-[1.45fr_0.55fr]">
        <div className="aj-blueprint relative hidden p-4 md:block">
          <svg viewBox="0 0 1000 490" className="h-auto w-full" role="group" aria-label="Business blueprint">
            <defs><marker id="sv-arr" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 L8 4 L0 8 z" fill="#8D989C" /></marker></defs>
            {/* outside world + management */}
            {[['Clients & investors', 140], ['Customers & dealers', 330]].map(([t, y]) => (
              <g key={t as string}><rect x="40" y={y as number} width="140" height="74" rx="10" fill="#fff" stroke="#C7D0DD" strokeDasharray="4 4" /><text x="110" y={(y as number) + 34} textAnchor="middle" className="fill-navy text-[13px] font-semibold">{t}</text><text x="110" y={(y as number) + 52} textAnchor="middle" className="fill-[#8D989C] font-mono text-[10px]">OUTSIDE</text></g>
            ))}
            <g><rect x="800" y="410" width="160" height="56" rx="10" fill="#172B4D" /><text x="880" y="436" textAnchor="middle" className="fill-white text-[13px] font-semibold">Management</text><text x="880" y="453" textAnchor="middle" className="fill-[#F47B2A] font-mono text-[10px]">ONE LIVE PICTURE</text></g>
            {flows.map((f, i) => {
              const on = f.by.includes(sel)
              return (
                <g key={i}>
                  <path id={`sv-f${i}`} d={f.d} fill="none" stroke={on ? ink(c.accent) : '#B8C3D4'} strokeWidth={on ? 2 : 1.25} markerEnd="url(#sv-arr)" className="transition-all" />
                  {f.label && <text x={f.lx} y={f.ly} textAnchor="middle" className="font-mono text-[10px]" fill={on ? '#172B4D' : '#8D989C'} stroke="#F7F9FC" strokeWidth="4" paintOrder="stroke">{f.label}</text>}
                  {on && <circle r="4" fill={ink(c.accent)}><animateMotion dur="2.2s" repeatCount="indefinite"><mpath href={`#sv-f${i}`} /></animateMotion></circle>}
                </g>
              )
            })}
            {zones.map((z) => {
              const zc = cap(z.slug)
              const on = z.slug === sel
              const col = ink(zc.accent)
              const frame = z.slug === 'custom-software-apps'
              const ty = frame ? z.y + z.h - 34 : z.y + z.h / 2 - 4
              return (
                <g key={z.slug} role="button" tabIndex={0} aria-pressed={on} aria-label={zc.name} onClick={() => setSel(z.slug)} onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), setSel(z.slug))} className="cursor-pointer outline-none [&:focus-visible>rect]:stroke-[3]">
                  <rect x={z.x} y={z.y} width={z.w} height={z.h} rx="12" fill={frame ? (on ? `${col}10` : 'transparent') : on ? col : '#fff'} stroke={col} strokeWidth={on ? 2 : 1.25} strokeDasharray={frame ? '6 5' : undefined} className="transition-all" />
                  <text x={z.x + 14} y={ty} className="font-mono text-[10.5px] font-bold" fill={on && !frame ? '#fff' : col}>{serviceSpecs[z.slug].code} · {zc.verb.toUpperCase()}</text>
                  <text x={z.x + 14} y={ty + 18} className="text-[13px] font-semibold" fill={on && !frame ? '#fff' : '#172B4D'}>{z.sub}</text>
                </g>
              )
            })}
          </svg>
        </div>
        <div className="flex gap-2 overflow-x-auto border-b border-border p-4 md:hidden">
          {ordered().map((x) => (
            <button key={x.slug} onClick={() => setSel(x.slug)} aria-pressed={x.slug === sel} className={`shrink-0 rounded-lg border px-3 py-2 text-[12.5px] font-semibold ${x.slug === sel ? 'border-navy bg-navy text-white' : 'border-border bg-card text-navy'}`}>
              <span className={`${mono} mr-1.5 text-[11px] ${x.slug === sel ? 'text-blue' : 'text-muted'}`}>{serviceSpecs[x.slug].code}</span>{x.verb}
            </button>
          ))}
        </div>
        <aside key={sel} className="aj-screen-in border-border p-6 lg:border-l" aria-live="polite">
          <p className={`${mono} text-[11px] font-bold`} style={{ color: ink(c.accent) }}>{s.code} · {c.verb.toUpperCase()}</p>
          <h3 className="mt-1 text-[20px] font-extrabold leading-tight text-navy">{c.name}</h3>
          <p className="mt-2 text-[13.5px] leading-[1.6] text-muted">{c.short}</p>
          <p className={`${mono} mt-5 text-[10.5px] font-bold text-muted`}>YOU RECEIVE</p>
          <ul className="mt-2 space-y-1.5">{s.artefacts.map((x) => <li key={x.name} className="flex items-center justify-between gap-2 text-[13px] text-navy"><span>{x.name}</span><span className={`${mono} text-[10px] text-muted`}>{x.kind}</span></li>)}</ul>
          {mods.length > 0 && <><p className={`${mono} mt-5 text-[10.5px] font-bold text-muted`}>MODULES</p><div className="mt-2 flex flex-wrap gap-1">{mods.map((m) => <a key={m.slug} href={`/modules/${m.slug}/`} className="rounded bg-bg-alt px-2 py-1 text-[12px] font-medium text-navy hover:bg-border"><span className={`${mono} mr-1 text-muted`}>{specs[m.slug].code}</span>{m.name}</a>)}</div></>}
          <a href={`/services/${c.slug}/`} className="mt-6 inline-flex items-center gap-1.5 text-[13.5px] font-semibold text-navy hover:text-blue">Open {c.name} <Icon name="arrow" className="h-3.5 w-3.5" /></a>
        </aside>
      </div>
    </div>
  )
}

function CapabilityRegister() {
  return (
    <div className={`${card} overflow-hidden`}>
      <div className="hidden grid-cols-[90px_1.2fr_1.3fr_1fr_40px] gap-4 border-b border-border bg-bg-alt px-5 py-2.5 text-[11px] font-bold uppercase tracking-[0.1em] text-muted md:grid">
        <span>Code</span><span>Capability</span><span>What it covers</span><span>Outcome</span><span />
      </div>
      <ul>
        {pillars.map((p) => [
          <li key={p.n} className="flex items-center gap-3 border-b border-border bg-bg-alt/60 px-5 py-2"><span className={`${mono} text-[11px] font-bold`} style={{ color: p.accent }}>{p.n}</span><a href={p.href} className="text-[12.5px] font-bold uppercase tracking-[0.08em] text-navy hover:text-blue">{p.title}</a></li>,
          ...p.caps.map(cap).map((c) => (
          <li key={c.slug} className="border-b border-border last:border-0">
            <a href={`/services/${c.slug}/`} className="group grid gap-x-4 gap-y-1 px-5 py-4 transition-colors hover:bg-bg md:grid-cols-[90px_1.2fr_1.3fr_1fr_40px] md:items-center">
              <span className={`${mono} flex items-center gap-2 text-[12px] font-semibold text-navy`}><span className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: ink(c.accent) }} />{serviceSpecs[c.slug].code}</span>
              <span><span className={`${mono} block text-[10.5px] font-bold`} style={{ color: ink(c.accent) }}>{c.verb.toUpperCase()}</span><span className="block text-[15px] font-bold text-navy">{c.name}</span></span>
              <span className="text-[13px] leading-snug text-muted">{c.short}</span>
              <span className="flex items-start gap-1.5 text-[13.5px] font-semibold text-navy"><Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-green" />{c.outcome}</span>
              <span className="hidden h-8 w-8 items-center justify-center rounded-full border border-border text-navy transition-all group-hover:border-navy group-hover:bg-navy group-hover:text-white md:flex"><Icon name="arrow" className="h-3.5 w-3.5" /></span>
            </a>
          </li>
        ))])}
      </ul>
    </div>
  )
}

function ProblemMatcher() {
  const all = capabilities.flatMap((c) => c.problems.map((p) => ({ ...p, c }))).filter((p, k, arr) => arr.findIndex((x) => x.problem === p.problem) === k)
  const [i, setI] = useState(0)
  const p = all[i]
  const a = ink(p.c.accent)
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1fr] lg:items-start">
      <ol className={`${card} divide-y divide-border overflow-hidden`} aria-label="Problems">
        {all.map((x, k) => (
          <li key={k}>
            <button onClick={() => setI(k)} aria-pressed={k === i} className={`flex w-full items-center gap-3 px-5 py-3.5 text-left transition-colors ${k === i ? 'bg-navy text-white' : 'hover:bg-bg'}`}>
              <span className={`${mono} w-7 shrink-0 text-[11px] ${k === i ? 'text-blue' : 'text-muted'}`}>P{String(k + 1).padStart(2, '0')}</span>
              <span className={`flex-1 text-[14px] font-semibold leading-snug ${k === i ? 'text-white' : 'text-navy'}`}>{x.problem}</span>
              <Icon name="arrow" className={`h-3.5 w-3.5 shrink-0 ${k === i ? 'text-blue' : 'text-muted'}`} />
            </button>
          </li>
        ))}
      </ol>
      <div key={i} className="aj-screen-in aj-blueprint-dark overflow-hidden rounded-2xl text-white lg:sticky lg:top-24">
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-3">
          <span className={`${mono} text-[11px] text-blue`}>DIAGNOSIS · P{String(i + 1).padStart(2, '0')}</span>
          <span className={`${mono} text-[11px] text-white/50`}>{serviceSpecs[p.c.slug].code}</span>
        </div>
        <div className="p-6">
          <p className={`${mono} text-[10.5px] font-bold text-orange`}>SYMPTOM</p>
          <p className="mt-1 text-[17px] font-semibold leading-snug">{p.problem}</p>
          <div className="my-5 flex items-center gap-2"><span className="h-px flex-1 bg-white/15" /><span className={`${mono} text-[10px] text-white/40`}>RESOLVED BY</span><span className="h-px flex-1 bg-white/15" /></div>
          <p className={`${mono} text-[10.5px] font-bold`} style={{ color: a }}>{p.solution.toUpperCase()}</p>
          <p className="mt-1 text-[15px] leading-[1.65] text-white/80">{p.detail}</p>
          <a href={`/services/${p.c.slug}/`} className="mt-6 flex items-center justify-between rounded-xl bg-white/[0.07] px-4 py-3 transition-colors hover:bg-white/[0.12]">
            <span><span className={`${mono} block text-[10.5px]`} style={{ color: a }}>{p.c.verb.toUpperCase()}</span><span className="text-[14px] font-semibold">{p.c.name}</span></span>
            <Icon name="arrow" className="h-4 w-4 text-blue" />
          </a>
        </div>
      </div>
    </div>
  )
}

/* ================================ HUB ================================ */

export function ServicesHub() {
  return (
    <main className="pt-16">
      <Breadcrumb items={[{ label: 'Home', href: '/' }, { label: 'Services' }]} />
      <section className={`${wrap} pb-20 pt-8`}>
        <Reveal>
          <Eyebrow code="S-00">Services</Eyebrow>
          <h1 className="max-w-[900px] text-[clamp(2rem,4.8vw,3.5rem)] font-extrabold leading-[1.05] tracking-[-0.03em] text-navy">A strategy-led <span className="text-blue">digital transformation</span> partner</h1>
          <p className="mt-5 max-w-[680px] text-[17px] leading-[1.7] text-muted">We combine business understanding, technology expertise and industry knowledge to simplify operations, digitize processes and build scalable, future-ready enterprises.</p>
          <div className="mt-6 flex flex-wrap items-center gap-2">
            <span className={`${mono} text-[11px] font-bold text-muted`}>BUILT FOR</span>
            {builtFor.map((b) => <span key={b} className="rounded border border-border bg-card px-2.5 py-1 text-[12.5px] font-medium text-navy">{b}</span>)}
          </div>
        </Reveal>
        <div className="mt-12"><Pillars /></div>
      </section>

      <section className="border-y border-border bg-bg-alt py-20">
        <div className={wrap}>
          <Eyebrow code="MAP">How it fits together</Eyebrow>
          <h2 className={`${h2} mb-8 max-w-[860px]`}>How the three services work together in your business</h2>
          <BusinessBlueprint />
        </div>
      </section>

      <section className="py-20">
        <div className={wrap}>
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div><Eyebrow code="REG">Service register</Eyebrow><h2 className={h2}>Three services, six specialisms</h2></div>
            <p className="max-w-[420px] text-[14px] leading-[1.65] text-muted">Each specialism belongs to one of the three services and shares the same ERP core. Most clients start with one and add the rest as they grow.</p>
          </div>
          <CapabilityRegister />
        </div>
      </section>

      <section className="border-y border-border bg-bg-alt py-20">
        <div className={wrap}>
          <Eyebrow code="DX">Problems we solve</Eyebrow>
          <h2 className={`${h2} mb-8 max-w-[860px]`}>What’s slipping in your business? Pick one.</h2>
          <ProblemMatcher />
          <div className="mt-6"><HumanInTheLoop /></div>
        </div>
      </section>

      <section className="border-t border-border bg-bg-alt py-20">
        <div className={wrap}><Eyebrow code="PRF">Proof</Eyebrow><h2 className={`${h2} mb-8`}>Results clients have seen</h2><Results /></div>
      </section>
      <ScreenBand screen="project" second="routeMap" title="What the work looks like once it is running" body="Every service ends in screens like these: a project overview your managers open each morning, and site progress plotted on the actual route." />
      <CtaBand />
    </main>
  )
}

/* ============================ CAPABILITY PAGE ============================ */

export function CapabilityPage({ c }: { c: Capability }) {
  const s = serviceSpecs[c.slug]
  const a = ink(c.accent)
  const related = c.modules.map(findModule).filter(Boolean) as Module[]
  const p = pillarOf(c.slug)
  return (
    <main className="pt-16">
      <Breadcrumb items={[{ label: 'Home', href: '/' }, { label: 'Services', href: '/services/' }, { label: p.title, href: p.href }, { label: c.name }]} />

      <section className={`${wrap} grid gap-10 pb-14 pt-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-start`}>
        <Reveal>
          <Eyebrow code={`${s.code} · ${s.short}`}>{`Part of ${p.n} · ${p.title}`}</Eyebrow>
          <h1 className="text-[clamp(2rem,4.6vw,3.3rem)] font-extrabold leading-[1.06] tracking-[-0.03em] text-navy">{c.name}</h1>
          <p className="mt-3 text-[19px] font-semibold leading-snug" style={{ color: a }}>{c.outcome}</p>
          <p className="mt-4 max-w-[600px] text-[16px] leading-[1.75] text-muted">{c.intro}</p>
          <div className="mt-7 flex flex-wrap gap-3"><PrimaryButton href="/contact/">Book Consultation</PrimaryButton><GhostButton href="#engagement">See the engagement</GhostButton></div>
        </Reveal>
        <Reveal delay={120}>
          <div className="aj-blueprint-dark overflow-hidden rounded-2xl text-white shadow-[0_20px_60px_rgba(23,43,77,0.25)]">
            <div className="flex items-center justify-between border-b border-white/10 px-5 py-3"><span className={`${mono} text-[11px] text-blue`}>ENGAGEMENT SHEET</span><span className={`${mono} text-[11px] text-white/50`}>{s.code}</span></div>
            <dl className="divide-y divide-white/10 px-5 text-[13px]">
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Service</dt><dd><a href={p.href} className="font-semibold hover:text-blue">{p.n} · {p.title}</a></dd></div>
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Outcome</dt><dd className="font-semibold">{c.outcome}</dd></div>
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">You receive</dt><dd className="flex flex-wrap gap-1">{s.artefacts.map((x) => <span key={x.name} className="rounded bg-white/[0.08] px-1.5 py-0.5 text-[12px]">{x.name}</span>)}</dd></div>
              {related.length > 0 && <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Modules</dt><dd className="flex flex-wrap gap-1">{related.map((m) => <a key={m.slug} href={`/modules/${m.slug}/`} className="rounded bg-white/[0.08] px-1.5 py-0.5 text-[12px] hover:bg-white/[0.16]">{m.name}</a>)}</dd></div>}
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Starts with</dt><dd className="text-white/80">{s.startsWith}</dd></div>
              <div className="grid grid-cols-[120px_1fr] gap-3 py-3"><dt className="text-white/50">Engagement</dt><dd className="font-semibold">{s.engagement.length} steps, reviewed with your team</dd></div>
            </dl>
          </div>
        </Reveal>
      </section>

      <section className={`${wrap} pb-16`}>
        <div className="grid overflow-hidden rounded-2xl border border-border md:grid-cols-2">
          <div className="bg-[#F47B2A]/[0.06] p-6"><p className={`${mono} text-[11px] font-bold text-orange`}>BEFORE</p><p className="mt-2 text-[16px] font-semibold leading-snug text-navy">{c.problems[0].problem}</p></div>
          <div className="border-t border-border bg-card p-6 md:border-l md:border-t-0"><p className={`${mono} text-[11px] font-bold`} style={{ color: a }}>AFTER · {c.problems[0].solution.toUpperCase()}</p><p className="mt-2 text-[16px] font-semibold leading-snug text-navy">{c.problems[0].detail}</p></div>
        </div>
      </section>

      <section id="engagement" className="scroll-mt-20 border-y border-border bg-bg-alt py-20">
        <div className={wrap}>
          <Eyebrow code="ENG">How an engagement runs</Eyebrow>
          <h2 className={`${h2} mb-10 max-w-[900px]`}>{c.name}, step by step</h2>
          <Simulator steps={s.engagement} accent={c.accent} label={`${c.name} engagement`} />
        </div>
      </section>

      <section className="py-20">
        <div className={wrap}>
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div><Eyebrow code="OUT">What you receive</Eyebrow><h2 className={h2}>Deliverables, not just advice</h2></div>
            <p className="max-w-[420px] text-[14px] leading-[1.65] text-muted">{c.short}</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {s.artefacts.map((x, k) => (
              <Reveal key={x.name} delay={k * 70}>
                <div className="relative h-full pt-3">
                  <span className={`${mono} absolute left-4 top-0 rounded-t-md border border-b-0 border-border bg-card px-2 py-0.5 text-[10px] font-bold text-muted`}>{s.code}/A{k + 1}</span>
                  <div className={`${card} flex h-full flex-col p-5`} style={{ borderTop: `2px solid ${a}` }}>
                    <span className={`${mono} self-start rounded px-1.5 py-0.5 text-[10px] font-bold`} style={{ backgroundColor: `${a}18`, color: a }}>{x.kind.toUpperCase()}</span>
                    <h3 className="mt-3 text-[15.5px] font-bold text-navy">{x.name}</h3>
                    <p className="mt-1.5 flex-1 text-[13.5px] leading-[1.6] text-muted">{x.body}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-bg-alt py-20">
        <div className={`${wrap} grid gap-10 lg:grid-cols-[1.25fr_0.75fr] lg:items-start`}>
          <div>
            <Eyebrow code="DX">Problems we solve</Eyebrow>
            <h2 className={`${h2} mb-6`}>Symptom, fix, and what changes</h2>
            <div className={`${card} overflow-hidden`}>
              {c.problems.map((p, k) => (
                <div key={p.solution} className="grid gap-x-5 gap-y-2 border-b border-border p-5 last:border-0 md:grid-cols-[40px_1fr_1fr]">
                  <span className={`${mono} text-[11px] font-bold text-muted`}>P{String(k + 1).padStart(2, '0')}</span>
                  <p className="text-[14.5px] font-semibold leading-snug text-navy">{p.problem}</p>
                  <p className="text-[13.5px] leading-[1.6] text-muted"><span className={`${mono} mb-0.5 block text-[10.5px] font-bold`} style={{ color: a }}>→ {p.solution.toUpperCase()}</span>{p.detail}</p>
                </div>
              ))}
            </div>
            {(c.slug === 'ai-business-intelligence' || c.slug === 'erp-automation') && <div className="mt-6"><HumanInTheLoop /></div>}
          </div>
          <div>
            <p className={`${mono} mb-3 text-[11px] font-bold text-muted`}>QUESTIONS IT ANSWERS</p>
            <ol className="space-y-3">
              {s.questions.map((q, k) => <li key={q} className={`${card} flex gap-3 p-4`}><span className={`${mono} text-[12px] font-bold`} style={{ color: a }}>Q{k + 1}</span><span className="text-[15px] font-semibold leading-snug text-navy">“{q}”</span></li>)}
            </ol>
            {related.length > 0 && (
              <>
                <p className={`${mono} mb-3 mt-8 text-[11px] font-bold text-muted`}>MODULES THAT POWER IT</p>
                <ul className={`${card} divide-y divide-border overflow-hidden`}>
                  {related.map((m) => (
                    <li key={m.slug}><a href={`/modules/${m.slug}/`} className="group flex items-center gap-3 px-4 py-3 hover:bg-bg"><span className={`${mono} text-[11.5px] font-semibold text-muted`}>{specs[m.slug].code}</span><span className="flex-1"><span className="block text-[14px] font-bold text-navy">{m.name}</span><span className="block text-[12px] text-muted">{m.tagline}</span></span><Icon name="arrow" className="h-3.5 w-3.5 text-muted group-hover:text-navy" /></a></li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className={wrap}><Eyebrow code="STG">Delivery</Eyebrow><h2 className={`${h2} mb-8`}>Six clear stages</h2><Stages /></div>
      </section>

      <section className="border-t border-border py-14">
        <div className={wrap}>
          <p className={`${mono} mb-4 text-[11px] font-bold text-muted`}>ALL SERVICES</p>
          <nav aria-label="Services" className="-mx-6 overflow-x-auto px-6">
            <ol className="flex min-w-max items-center gap-2">
              {pillars.map((g) => <Fragment key={g.n}><li className="ml-2 first:ml-0"><a href={g.href} className={`${mono} text-[11px] font-bold`} style={{ color: g.accent }}>{g.n} {g.title.toUpperCase()}</a></li>{g.caps.map(cap).map((x) => {
                const on = x.slug === c.slug
                return <li key={x.slug}><a href={`/services/${x.slug}/`} aria-current={on ? 'page' : undefined} className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-[13px] font-semibold transition-colors ${on ? 'border-navy bg-navy text-white' : 'border-border bg-card text-navy hover:border-navy/30'}`}><span className={`${mono} text-[11px] ${on ? 'text-blue' : 'text-muted'}`}>{serviceSpecs[x.slug].code}</span>{x.name}</a></li>
              })}</Fragment>)}
            </ol>
          </nav>
        </div>
      </section>
      <ScreenBand screen={moduleScreen[c.modules[0]] ?? 'dashboard'} second={moduleSecond[c.modules[0]]} title={`${c.name}, delivered as working software`} />
      <CtaBand title={`Want to talk about ${c.name.toLowerCase()}?`} />
    </main>
  )
}
