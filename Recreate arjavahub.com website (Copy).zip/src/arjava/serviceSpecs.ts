// Engagement-level detail for each capability. Screen values are illustrative samples.
import type { WorkflowStep } from './moduleSpecs'

export interface Artefact {
  name: string
  kind: 'Document' | 'Workshop' | 'Design' | 'Live system' | 'Report' | 'Integration'
  body: string
}

export interface ServiceSpec {
  code: string
  short: string
  engagement: WorkflowStep[]
  artefacts: Artefact[]
  startsWith: string
  questions: string[]
}

export const serviceSpecs: Record<string, ServiceSpec> = {
  'business-process-consulting': {
    code: 'S-1.1', short: 'CON',
    startsWith: 'A discovery call and a walk through how work moves today.',
    engagement: [
      { title: 'Discovery sessions', actor: 'Your teams', note: 'Purchase, stores, site, finance and management walk us through a normal week.', screen: { heading: 'Discovery log', ref: 'Week 1', rows: [['Purchase team', 'Session done', 'ok'], ['Stores & site', 'Session done', 'ok'], ['Finance', 'Scheduled', 'wait'], ['Management', 'Scheduled', 'wait']] } },
      { title: 'Workflows mapped', actor: 'Arjava analysts', note: 'Every request, approval and handoff drawn end to end, in your terminology.', screen: { heading: 'Process map', ref: 'Purchase to pay', rows: [['Steps mapped', '14'], ['Handoffs', '6'], ['Tools used today', 'Excel, email, WhatsApp', 'warn']] } },
      { title: 'Gaps found', actor: 'Arjava analysts', note: 'Where data is re-typed, approvals stall or nobody can see the status.', screen: { heading: 'Gap analysis', ref: 'Findings', rows: [['Rates not compared to history', 'High', 'flag'], ['Approvals over phone', 'Medium', 'warn'], ['Stock counted manually', 'Medium', 'warn']], banner: ['info', '2 quick wins identified'] } },
      { title: 'Roadmap agreed', actor: 'Management', note: 'Which modules first, which integrations, and what each phase changes.', screen: { heading: 'Transformation roadmap', ref: 'v1.0', rows: [['Phase 1', 'Purchase & approvals'], ['Phase 2', 'Inventory & finance'], ['Phase 3', 'Dashboards & AI']], action: 'Approve roadmap' } },
      { title: 'Handed to build', actor: 'Arjava & your team', note: 'Priorities become scope for the first module, or a plan you own.', screen: { heading: 'Next step', ref: 'Phase 1', rows: [['Scope', 'Agreed', 'ok'], ['Owners', 'Named', 'ok'], ['Start', 'Build & configure', 'info']] } },
    ],
    artefacts: [
      { name: 'Process maps', kind: 'Document', body: 'End-to-end maps of each core workflow as it runs today.' },
      { name: 'Gap analysis & quick wins', kind: 'Report', body: 'Where cost, delay or risk hides, ranked by impact.' },
      { name: 'Transformation roadmap', kind: 'Document', body: 'Phased plan: modules, integrations and order of work.' },
      { name: 'Discovery workshops', kind: 'Workshop', body: 'Working sessions with the people who do the work.' },
    ],
    questions: ['Where exactly are we losing time and money?', 'What should we fix first?', 'Do we need a full ERP, or one tool?'],
  },
  'digital-presence': {
    code: 'S-3.1', short: 'DIG',
    startsWith: 'A review of how clients and investors see you today.',
    engagement: [
      { title: 'Positioning reviewed', actor: 'Arjava & leadership', note: 'What you do, for whom, and what proof you can show.', screen: { heading: 'Positioning brief', ref: 'Draft', rows: [['Core services', 'Listed', 'ok'], ['Industries', 'Listed', 'ok'], ['Proof points', 'Gathering', 'wait']] } },
      { title: 'Content structured', actor: 'Arjava writers', note: 'Services, projects and capabilities organised for decision-makers.', screen: { heading: 'Site map', ref: 'v2', rows: [['Home', 'Positioning'], ['Services', '6 pages'], ['Projects', 'Portfolio'], ['Contact', 'Enquiry form', 'ok']] } },
      { title: 'Designed & written', actor: 'Arjava designers', note: 'Website, capability statement and pitch deck in one visual language.', screen: { heading: 'Design review', ref: 'Round 1', rows: [['Website', 'In review', 'wait'], ['Capability statement', 'Approved', 'ok'], ['Pitch deck', 'In review', 'wait']] } },
      { title: 'Built & optimised', actor: 'Arjava developers', note: 'Fast, search-friendly pages with enquiries routed to the right person.', screen: { heading: 'Launch checklist', ref: 'Pre-launch', rows: [['Mobile layout', 'Checked', 'ok'], ['SEO basics', 'Done', 'ok'], ['Enquiry routing', 'Tested', 'ok']] } },
      { title: 'Launched', actor: 'Your team', note: 'Live on your domain, with collateral ready for tenders and meetings.', screen: { heading: 'Live', ref: 'yourdomain.com', rows: [['Website', 'Live', 'ok'], ['Collateral', 'Delivered', 'ok'], ['Enquiries', 'Into CRM', 'info']] } },
    ],
    artefacts: [
      { name: 'Corporate website', kind: 'Live system', body: 'On your own domain, explaining services, industries and work.' },
      { name: 'Capability statement', kind: 'Document', body: 'For tenders, clients and partners.' },
      { name: 'Pitch deck', kind: 'Design', body: 'For investors and key meetings.' },
      { name: 'Project portfolio', kind: 'Design', body: 'Completed work with scope, scale and outcome.' },
    ],
    questions: ['Do clients understand what we actually do?', 'Can we show our work credibly in a tender?', 'Do enquiries reach the right person?'],
  },
  'custom-software-apps': {
    code: 'S-2.2', short: 'APP',
    startsWith: 'One workflow that no off-the-shelf product handles.',
    engagement: [
      { title: 'Workflow defined', actor: 'Arjava & users', note: 'Who uses it, what they enter, and what happens next.', screen: { heading: 'Requirement', ref: 'REQ-01', rows: [['Users', 'Vendors, site team'], ['Devices', 'Web & mobile'], ['Connects to', 'ERP, bank']] } },
      { title: 'Screens designed', actor: 'Arjava designers', note: 'Screens and data planned around your terminology.', screen: { heading: 'Screen plan', ref: 'v1', rows: [['Vendor portal', '6 screens', 'ok'], ['Site app', '4 screens', 'ok'], ['Admin', '3 screens', 'wait']] } },
      { title: 'Built in increments', actor: 'Arjava developers', note: 'Working software reviewed regularly, not in one big reveal.', screen: { heading: 'Sprint review', ref: 'Sprint 3', rows: [['Quote submission', 'Done', 'ok'], ['Invoice upload', 'Done', 'ok'], ['Payment status', 'In progress', 'wait']] } },
      { title: 'Integrated', actor: 'Arjava developers', note: 'APIs connect the app to the systems you already use.', screen: { heading: 'Integrations', ref: 'APIs', rows: [['ERP', 'Connected', 'ok'], ['Bank', 'Connected', 'ok'], ['GST', 'Testing', 'wait']] } },
      { title: 'Shipped to your repository', actor: 'Arjava', note: 'Deployed to your servers, with the code in your own repository.', screen: { heading: 'Release', ref: 'v1.0', rows: [['Deployed', 'Your server', 'ok'], ['Code', 'Your repository', 'ok'], ['Support', 'Ongoing', 'info']] } },
    ],
    artefacts: [
      { name: 'Web application', kind: 'Live system', body: 'Built for the workflow that makes your business different.' },
      { name: 'Customer & vendor portals', kind: 'Live system', body: 'Self-service quotes, bills, orders and status.' },
      { name: 'Mobile app / PWA', kind: 'Live system', body: 'Field updates and approvals on any device.' },
      { name: 'APIs & integrations', kind: 'Integration', body: 'Data entered once, shared with your other systems.' },
    ],
    questions: ['Can our vendors submit quotes and bills themselves?', 'Can site update progress from a phone?', 'Will it talk to our existing systems?'],
  },
  'ecommerce-development': {
    code: 'S-3.2', short: 'COM',
    startsWith: 'Your catalogue, channels and how orders are fulfilled today.',
    engagement: [
      { title: 'Platform chosen', actor: 'Arjava & your team', note: 'Custom, Shopify, Shopify Plus or WooCommerce, based on catalogue and scale.', screen: { heading: 'Platform fit', ref: 'Assessment', rows: [['Catalogue', 'Complex variants', 'info'], ['B2B pricing', 'Required', 'warn'], ['Recommendation', 'Custom storefront', 'ok']] } },
      { title: 'Theme designed', actor: 'Arjava designers', note: 'A bespoke theme built to convert, not a stock template.', screen: { heading: 'Design', ref: 'Theme v1', rows: [['Home & category', 'Approved', 'ok'], ['Product page', 'Approved', 'ok'], ['Checkout', 'In review', 'wait']] } },
      { title: 'Payments & shipping', actor: 'Arjava developers', note: 'Gateways, GST, shipping and tracking configured.', screen: { heading: 'Checkout setup', ref: 'Config', rows: [['Payment gateway', 'Live', 'ok'], ['GST invoices', 'Configured', 'ok'], ['Courier', 'Connected', 'ok']] } },
      { title: 'Connected to ERP', actor: 'Arjava developers', note: 'Orders, stock and invoices flow into the ERP automatically.', screen: { heading: 'Store-to-ERP sync', ref: 'Live', rows: [['Orders', 'Syncing', 'ok'], ['Stock', 'One count', 'ok'], ['Invoices', 'Auto-generated', 'ok']] } },
      { title: 'Launched', actor: 'Your team', note: 'Store live, with marketplaces synced where needed.', screen: { heading: 'Launch', ref: 'Go-live', rows: [['Storefront', 'Live', 'ok'], ['Marketplaces', 'Synced', 'ok'], ['Support', 'Ongoing', 'info']] } },
    ],
    artefacts: [
      { name: 'Storefront', kind: 'Live system', body: 'Custom, Shopify or WooCommerce on a bespoke theme.' },
      { name: 'B2B / dealer portal', kind: 'Live system', body: 'Repeat orders and dealer pricing online.' },
      { name: 'Payments, shipping & GST', kind: 'Integration', body: 'Configured end to end.' },
      { name: 'Store-to-ERP sync', kind: 'Integration', body: 'Orders, stock and invoices with no double entry.' },
    ],
    questions: ['Can customers order without calling us?', 'Is online stock the same as warehouse stock?', 'Do online orders reach accounts automatically?'],
  },
  'erp-automation': {
    code: 'S-2.1', short: 'ERP',
    startsWith: 'The module that addresses your most pressing problem.',
    engagement: [
      { title: 'Scope set', actor: 'Arjava & management', note: 'Modules, workflows and integrations the platform needs to cover.', screen: { heading: 'ERP scope', ref: 'Phase 1', rows: [['Purchase & vendors', 'In scope', 'ok'], ['Inventory', 'In scope', 'ok'], ['Finance', 'Phase 2', 'wait']] } },
      { title: 'Configured & built', actor: 'Arjava developers', note: 'Standard components configured; custom modules built where needed.', screen: { heading: 'Build status', ref: 'Sprint 4', rows: [['Approval rules', 'Configured', 'ok'], ['Rate history', 'Built', 'ok'], ['Site app', 'In progress', 'wait']] } },
      { title: 'Data migrated', actor: 'Arjava & your team', note: 'Masters and open transactions moved from spreadsheets and old systems.', screen: { heading: 'Migration', ref: 'Dry run 2', rows: [['Vendors', 'Imported', 'ok'], ['Items', 'Imported', 'ok'], ['Open POs', '3 to fix', 'warn']] } },
      { title: 'Tested on real work', actor: 'Your users', note: 'Key workflows tested before daily work depends on them.', screen: { heading: 'User acceptance', ref: 'UAT', rows: [['Purchase to pay', 'Passed', 'ok'], ['Stock transfer', 'Passed', 'ok'], ['Approvals', 'Passed', 'ok']] } },
      { title: 'Rolled out', actor: 'Arjava', note: 'Module by module, with training and support in place.', screen: { heading: 'Go-live', ref: 'Phase 1', rows: [['Users trained', 'Done', 'ok'], ['Live modules', 'Purchase, Inventory', 'ok'], ['Next', 'Finance', 'info']] } },
    ],
    artefacts: [
      { name: 'ERP modules', kind: 'Live system', body: 'Purchase, inventory, finance, projects and approvals on one database.' },
      { name: 'Approval rules & roles', kind: 'Design', body: 'Your authority matrix, built into the system.' },
      { name: 'Migrated data', kind: 'Integration', body: 'Masters and open transactions moved across.' },
      { name: 'Training', kind: 'Workshop', body: 'Role-based sessions before go-live.' },
    ],
    questions: ['Is there one version of every number?', 'Who approved this, and against which budget?', 'Can we add modules later without starting again?'],
  },
  'ai-business-intelligence': {
    code: 'S-3.3', short: 'AI',
    startsWith: 'The documents and reports your team spends the most time on.',
    engagement: [
      { title: 'Documents identified', actor: 'Arjava & your team', note: 'Which documents arrive, in what formats, and what is checked by hand.', screen: { heading: 'Document audit', ref: 'Inbox', rows: [['Tender notices', 'High volume', 'warn'], ['Vendor quotes', 'Mixed formats', 'warn'], ['Invoices', 'PDF & scans', 'info']] } },
      { title: 'Fields & checks defined', actor: 'Arjava analysts', note: 'What to extract, and what to compare it against.', screen: { heading: 'Extraction spec', ref: 'Tenders', rows: [['Fields', 'Value, EMD, dates'], ['Compare with', 'Company profile'], ['Flags', 'Validity, eligibility']] } },
      { title: 'AI layer configured', actor: 'Arjava developers', note: 'Reading, comparison and flags connected to the ERP.', screen: { heading: 'AI pipeline', ref: 'Config', rows: [['Reading', 'Enabled', 'ok'], ['Rate comparison', 'Enabled', 'ok'], ['Forecasting', 'Enabled', 'ok']] } },
      { title: 'Reviewed by people', actor: 'Your team', note: 'Every output is reviewed; corrections improve the setup.', screen: { heading: 'Review queue', ref: 'Today', rows: [['Confirmed', '11', 'ok'], ['Corrected', '2', 'info'], ['Flagged', '1', 'flag']], banner: ['info', 'Human-in-the-loop: your team decides'] } },
      { title: 'Dashboards live', actor: 'Management', note: 'Variance, forecasts and MIS from live data.', screen: { heading: 'MIS', ref: 'Monthly', rows: [['Variance', 'Tracked', 'ok'], ['Cash-flow forecast', 'Updated', 'ok'], ['Board report', 'Generated', 'ok']] } },
    ],
    artefacts: [
      { name: 'AI document reading', kind: 'Live system', body: 'Invoices, quotes, tenders and contracts into structured fields.' },
      { name: 'Rate & anomaly flags', kind: 'Live system', body: 'Quotes checked against vendor rate history.' },
      { name: 'Forecasts', kind: 'Report', body: 'Variance and cash-flow, looking forward.' },
      { name: 'Dashboards & MIS', kind: 'Report', body: 'Live dashboards and board-ready reports.' },
    ],
    questions: ['Are we eligible for this tender?', 'Is this quote out of line with history?', 'Where is cash heading next month?'],
  },
}
