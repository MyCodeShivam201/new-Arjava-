// Detailed, module-specific content for the modules hub and module pages.
// Screen values are illustrative samples, not client data.

export type Status = 'ok' | 'warn' | 'flag' | 'wait' | 'info'

export interface WorkflowStep {
  title: string
  actor: string
  note: string
  screen: {
    heading: string
    ref: string
    rows: [string, string, Status?][]
    banner?: [Status, string]
    action?: string
  }
}

export interface Entity {
  name: string
  fields: string[]
}

export interface ModuleSpec {
  code: string
  short: string
  workflow: WorkflowStep[]
  entities: Entity[]
  links: [string, string][] // [entity from → to]
  flows: { to: string; label: string; dir: 'in' | 'out' }[]
  questions: string[]
}

export const specs: Record<string, ModuleSpec> = {
  'purchase-vendors': {
    code: 'M-01', short: 'PUR',
    workflow: [
      { title: 'Request raised', actor: 'Site engineer', note: 'Material requested against the project budget, from site.', screen: { heading: 'Purchase request', ref: 'PR-2041', rows: [['Item', 'TMT bars, 12 mm'], ['Quantity', '18 t'], ['Project', 'Campus Block'], ['Budget head', 'Structure · Steel', 'ok']], banner: ['info', 'Live stock checked: 2.4 t at main store'] } },
      { title: 'Quotes collected', actor: 'Purchase team', note: 'Vendors quote in their own formats; quotes are captured against the request.', screen: { heading: 'Quotations', ref: 'PR-2041', rows: [['Vendor A', '₹8.7 L', 'ok'], ['Vendor B', '₹12.0 L', 'warn'], ['Vendor C', 'Awaited', 'wait']] } },
      { title: 'Rate checked', actor: 'Rate history', note: 'Each quote is compared with what has been paid before.', screen: { heading: 'Rate comparison', ref: 'PR-2041', rows: [['Vendor A vs history', 'In range', 'ok'], ['Vendor B vs history', 'Above range', 'flag'], ['Last paid rate', 'Vendor A, 2 POs ago']], banner: ['flag', 'Vendor B flagged by vendor rate history'] } },
      { title: 'Approved', actor: 'Director', note: 'Approver sees the comparison and the flag before deciding.', screen: { heading: 'Approval', ref: 'PR-2041', rows: [['Recommended', 'Vendor A · ₹8.7 L'], ['Within budget', 'Yes', 'ok'], ['Approver', 'Director', 'ok']], action: 'Approve' } },
      { title: 'PO issued & received', actor: 'Stores', note: 'PO sent; goods receipt matched to the PO and the bill.', screen: { heading: 'Purchase order', ref: 'PO-1187', rows: [['Vendor', 'Vendor A'], ['PO value', '₹8.7 L'], ['Goods receipt', 'GRN-552 · 18 t', 'ok'], ['Bill match', 'Matched', 'ok']] } },
    ],
    entities: [
      { name: 'Purchase request', fields: ['Item & quantity', 'Project', 'Budget head', 'Requested by'] },
      { name: 'Quotation', fields: ['Vendor', 'Rate & terms', 'Validity', 'Source document'] },
      { name: 'Purchase order', fields: ['Vendor', 'Value', 'Delivery terms', 'Approval trail'] },
      { name: 'Goods receipt', fields: ['PO reference', 'Received qty', 'Site / store', 'Inspection'] },
    ],
    links: [['Purchase request', 'Quotation'], ['Quotation', 'Purchase order'], ['Purchase order', 'Goods receipt']],
    flows: [
      { to: 'inventory-stock', label: 'Goods receipt', dir: 'out' },
      { to: 'approvals-audit', label: 'PO for approval', dir: 'out' },
      { to: 'finance-cash-flow', label: 'Bill to pay', dir: 'out' },
      { to: 'ai-document-intelligence', label: 'Quotes read', dir: 'in' },
    ],
    questions: ['Are we paying more than last time for this item?', 'Which requests are waiting on approval, and with whom?', 'Was everything on this PO actually received?'],
  },
  'inventory-stock': {
    code: 'M-02', short: 'INV',
    workflow: [
      { title: 'Goods received', actor: 'Stores', note: 'Receipt recorded against the PO; stock increases at that store.', screen: { heading: 'Goods receipt', ref: 'GRN-552', rows: [['PO', 'PO-1187'], ['Item', 'TMT bars, 12 mm'], ['Received', '18 t', 'ok'], ['Store', 'Main store']] } },
      { title: 'Transferred to site', actor: 'Store keeper', note: 'Material moved between store and site, both counts updated.', screen: { heading: 'Stock transfer', ref: 'ST-310', rows: [['From', 'Main store'], ['To', 'Site 2'], ['Quantity', '6 t'], ['Status', 'In transit', 'wait']] } },
      { title: 'Issued to work', actor: 'Site engineer', note: 'Consumption recorded against the activity it was used for.', screen: { heading: 'Material issue', ref: 'MI-778', rows: [['Activity', 'Slab casting, L2'], ['Issued', '4.2 t'], ['Against plan', 'Within estimate', 'ok']] } },
      { title: 'Low stock flagged', actor: 'System', note: 'Stock below re-order level raises a flag for purchase.', screen: { heading: 'Stock position', ref: 'All sites', rows: [['Main store', '12.2 t', 'ok'], ['Site 1', '0.8 t', 'warn'], ['Site 2', '1.8 t', 'ok']], banner: ['warn', 'Site 1 below re-order level'] } },
      { title: 'Re-order with live stock', actor: 'Purchase team', note: 'The new request shows live stock across sites before it is raised.', screen: { heading: 'New purchase request', ref: 'PR-2066', rows: [['Item', 'TMT bars, 12 mm'], ['Stock across sites', '14.8 t', 'info'], ['Suggested', 'Transfer before buying', 'ok']] } },
    ],
    entities: [
      { name: 'Item', fields: ['Code & unit', 'Re-order level', 'Category'] },
      { name: 'Store / site', fields: ['Location', 'In-charge', 'Stock on hand'] },
      { name: 'Stock movement', fields: ['Receipt / issue / transfer', 'Quantity', 'Reference'] },
    ],
    links: [['Item', 'Stock movement'], ['Store / site', 'Stock movement']],
    flows: [
      { to: 'purchase-vendors', label: 'Goods receipt', dir: 'in' },
      { to: 'store-erp-sync', label: 'Online orders reserve stock', dir: 'in' },
      { to: 'projects-tasks', label: 'Material issued', dir: 'out' },
      { to: 'dashboards-mis', label: 'Stock position', dir: 'out' },
    ],
    questions: ['How much of this item do we have, and where?', 'What was consumed on this activity against the estimate?', 'Should we transfer between sites before buying?'],
  },
  'finance-cash-flow': {
    code: 'M-03', short: 'FIN',
    workflow: [
      { title: 'Bill received', actor: 'Accounts', note: 'Vendor bill matched to PO and goods receipt before it is booked.', screen: { heading: 'Vendor bill', ref: 'BL-4410', rows: [['Vendor', 'Vendor A'], ['Amount', '₹8.7 L'], ['PO / GRN match', 'Matched', 'ok'], ['GST', 'Captured', 'ok']] } },
      { title: 'Checked against budget', actor: 'System', note: 'The commitment is measured against its budget head.', screen: { heading: 'Budget vs actual', ref: 'Structure · Steel', rows: [['Budget', '₹42 L'], ['Committed', '₹36.1 L'], ['Remaining', '₹5.9 L', 'ok']] } },
      { title: 'Payment scheduled', actor: 'Finance head', note: 'Payment planned by due date and cash position.', screen: { heading: 'Payables', ref: 'This week', rows: [['Vendor A', 'Due Fri', 'wait'], ['Vendor D', 'Overdue 3 days', 'warn'], ['Vendor F', 'Paid', 'ok']] } },
      { title: 'Receivables followed up', actor: 'Accounts', note: 'Customer invoices tracked to collection.', screen: { heading: 'Receivables', ref: 'Ageing', rows: [['0–30 days', '4 invoices', 'ok'], ['31–60 days', '2 invoices', 'warn'], ['60+ days', '1 invoice', 'flag']] } },
      { title: 'Bank reconciled', actor: 'Accounts', note: 'Bank transactions matched against recorded payments and receipts.', screen: { heading: 'Bank reconciliation', ref: 'Current account', rows: [['Matched', '38 entries', 'ok'], ['Unmatched', '2 entries', 'warn'], ['Forecast', 'Cash-flow view updated', 'info']] } },
    ],
    entities: [
      { name: 'Budget head', fields: ['Project / department', 'Budget', 'Committed', 'Actual'] },
      { name: 'Bill / invoice', fields: ['Party', 'Amount & GST', 'Due date', 'Linked PO / order'] },
      { name: 'Payment / receipt', fields: ['Mode', 'Bank reference', 'Reconciled'] },
    ],
    links: [['Budget head', 'Bill / invoice'], ['Bill / invoice', 'Payment / receipt']],
    flows: [
      { to: 'purchase-vendors', label: 'Bills & POs', dir: 'in' },
      { to: 'crm-sales', label: 'Customer invoices', dir: 'in' },
      { to: 'approvals-audit', label: 'Payment approvals', dir: 'out' },
      { to: 'dashboards-mis', label: 'Cash-flow & budget', dir: 'out' },
    ],
    questions: ['How much of this budget is already committed?', 'What do we owe this week, and what is overdue to us?', 'Which bank entries are still unmatched?'],
  },
  'projects-tasks': {
    code: 'M-04', short: 'PRJ',
    workflow: [
      { title: 'Plan set', actor: 'Project manager', note: 'Activities, owners, quantities and dates agreed.', screen: { heading: 'Project plan', ref: 'Campus Block', rows: [['Activities', '42'], ['Milestones', '6'], ['Owner per task', 'Assigned', 'ok']] } },
      { title: 'Daily progress logged', actor: 'Site engineer', note: 'Work done recorded from site on mobile.', screen: { heading: 'Daily progress report', ref: 'DPR · Today', rows: [['Slab shuttering, L2', '70%'], ['Brickwork, Block B', '610 / 900'], ['Manpower', '46 on site']] } },
      { title: 'Planned vs actual', actor: 'System', note: 'Progress compared with plan for time and cost.', screen: { heading: 'Planned vs actual', ref: 'This week', rows: [['Excavation', '112 / 120', 'ok'], ['Slab casting', '4 / 6', 'warn'], ['Brickwork', '610 / 900', 'warn']] } },
      { title: 'Variance alert', actor: 'System', note: 'Drift beyond tolerance is raised to the owner.', screen: { heading: 'Alert', ref: 'Slab casting', rows: [['Behind plan', '2 pours'], ['Owner', 'Project manager'], ['Reason', 'Awaiting shuttering material', 'wait']], banner: ['warn', 'Variance beyond tolerance'] } },
      { title: 'Reviewed by management', actor: 'Director', note: 'Weekly review with comments and decisions recorded.', screen: { heading: 'Weekly review', ref: 'Week 37', rows: [['Overall progress', 'On track', 'ok'], ['Actions', '2 assigned'], ['Next review', 'Monday']], action: 'Sign off' } },
    ],
    entities: [
      { name: 'Project', fields: ['Client & site', 'Budget', 'Milestones'] },
      { name: 'Activity / task', fields: ['Owner', 'Planned qty & dates', 'Actual'] },
      { name: 'Daily report', fields: ['Work done', 'Manpower', 'Issues', 'Photos'] },
    ],
    links: [['Project', 'Activity / task'], ['Activity / task', 'Daily report']],
    flows: [
      { to: 'inventory-stock', label: 'Material issued', dir: 'in' },
      { to: 'purchase-vendors', label: 'Material requests', dir: 'out' },
      { to: 'dashboards-mis', label: 'Progress & variance', dir: 'out' },
      { to: 'approvals-audit', label: 'Reports for review', dir: 'out' },
    ],
    questions: ['Which activities are behind plan this week?', 'Who owns the delay, and what is blocking it?', 'What did site actually report yesterday?'],
  },
  'approvals-audit': {
    code: 'M-05', short: 'APR',
    workflow: [
      { title: 'Submitted', actor: 'Requester', note: 'A request enters the approval chain that matches its type and value.', screen: { heading: 'Approval request', ref: 'PO-1187', rows: [['Type', 'Purchase order'], ['Value', '₹8.7 L'], ['Route', 'PM → Director']] } },
      { title: 'Checked', actor: 'System', note: 'Rules and documents checked before a person sees it.', screen: { heading: 'Pre-checks', ref: 'PO-1187', rows: [['Within budget', 'Yes', 'ok'], ['Quotes attached', '3', 'ok'], ['Rate flag', 'Reviewed', 'info']] } },
      { title: 'Level 1 approved', actor: 'Project manager', note: 'First approver signs off with a comment.', screen: { heading: 'Approval chain', ref: 'PO-1187', rows: [['Project manager', 'Approved', 'ok'], ['Director', 'Pending', 'wait']] } },
      { title: 'Final approval', actor: 'Director', note: 'Final approver decides with the full history visible.', screen: { heading: 'Approval chain', ref: 'PO-1187', rows: [['Project manager', 'Approved', 'ok'], ['Director', 'Approved', 'ok']], action: 'Approved' } },
      { title: 'Audit trail kept', actor: 'Audit log', note: 'Who did what, when, against which document.', screen: { heading: 'Audit trail', ref: 'PO-1187', rows: [['Created', 'Purchase team'], ['Edited rate', 'Purchase team'], ['Approved', 'PM, Director', 'ok']] } },
    ],
    entities: [
      { name: 'Approval rule', fields: ['Document type', 'Value limits', 'Approver roles'] },
      { name: 'Approval', fields: ['Document', 'Approver', 'Decision & comment', 'Time'] },
      { name: 'Audit entry', fields: ['User', 'Action', 'Before / after', 'Time'] },
    ],
    links: [['Approval rule', 'Approval'], ['Approval', 'Audit entry']],
    flows: [
      { to: 'purchase-vendors', label: 'POs to approve', dir: 'in' },
      { to: 'finance-cash-flow', label: 'Payments to approve', dir: 'in' },
      { to: 'ai-document-intelligence', label: 'Compliance checks', dir: 'in' },
      { to: 'dashboards-mis', label: 'Pending approvals', dir: 'out' },
    ],
    questions: ['Who approved this, and when?', 'What is waiting on me right now?', 'What changed on this document after it was submitted?'],
  },
  'crm-sales': {
    code: 'M-06', short: 'CRM',
    workflow: [
      { title: 'Lead captured', actor: 'Sales', note: 'Enquiry recorded with source and owner.', screen: { heading: 'Lead', ref: 'LD-219', rows: [['Company', 'Sample Industries'], ['Source', 'Website enquiry'], ['Owner', 'Sales manager']] } },
      { title: 'Follow-up scheduled', actor: 'Sales', note: 'Next action and date set so nothing is forgotten.', screen: { heading: 'Follow-ups', ref: 'This week', rows: [['LD-219', 'Call Tue', 'wait'], ['LD-204', 'Overdue', 'warn'], ['LD-198', 'Done', 'ok']] } },
      { title: 'Quotation sent', actor: 'Sales', note: 'Quote issued from the same customer record.', screen: { heading: 'Deal', ref: 'DL-88', rows: [['Stage', 'Quotation sent'], ['Value', 'As quoted'], ['Next step', 'Negotiation', 'info']] } },
      { title: 'Deal won', actor: 'Sales head', note: 'Won deal becomes an order or project automatically.', screen: { heading: 'Deal', ref: 'DL-88', rows: [['Stage', 'Won', 'ok'], ['Created', 'Order SO-140', 'ok'], ['Handed to', 'Delivery team']] } },
      { title: 'Invoiced', actor: 'Accounts', note: 'Invoice raised against the same order and customer.', screen: { heading: 'Invoice', ref: 'INV-640', rows: [['Order', 'SO-140'], ['Status', 'Sent', 'info'], ['Collection', 'Tracked in Finance']] } },
    ],
    entities: [
      { name: 'Lead / customer', fields: ['Company & contacts', 'Source', 'Owner'] },
      { name: 'Deal', fields: ['Stage', 'Value', 'Next action'] },
      { name: 'Sales order', fields: ['Items / scope', 'Delivery', 'Invoice'] },
    ],
    links: [['Lead / customer', 'Deal'], ['Deal', 'Sales order']],
    flows: [
      { to: 'store-erp-sync', label: 'Online orders', dir: 'in' },
      { to: 'projects-tasks', label: 'Won deals → delivery', dir: 'out' },
      { to: 'finance-cash-flow', label: 'Invoices', dir: 'out' },
      { to: 'dashboards-mis', label: 'Pipeline', dir: 'out' },
    ],
    questions: ['Which follow-ups are overdue?', 'What is in the pipeline, and at what stage?', 'Has this won order been delivered and billed?'],
  },
  'ai-document-intelligence': {
    code: 'M-07', short: 'AI',
    workflow: [
      { title: 'Document arrives', actor: 'Email / upload', note: 'Tender notice, quotation, invoice or PO, as PDF or scan.', screen: { heading: 'Inbox', ref: 'Today', rows: [['Tender notice A-114', '42 pages'], ['Vendor quotation', 'Scanned PDF'], ['Vendor invoice', 'PDF']] } },
      { title: 'Read by AI', actor: 'AI layer', note: 'The document is read and relevant clauses identified.', screen: { heading: 'Reading', ref: 'A-114', rows: [['Eligibility clause', 'Found, p. 17', 'info'], ['EMD clause', 'Found, p. 9', 'info'], ['Closing date', 'Found, p. 2', 'info']] } },
      { title: 'Fields extracted', actor: 'AI layer', note: 'Values placed into structured fields.', screen: { heading: 'Extracted fields', ref: 'A-114', rows: [['Estimated value', '₹1.4 Cr'], ['Turnover required', '₹8 Cr'], ['EMD', '₹2,80,000'], ['Closes', '30 Sep']] } },
      { title: 'Compared & flagged', actor: 'AI layer', note: 'Checked against your profile, history or other documents.', screen: { heading: 'Checks', ref: 'A-114', rows: [['Turnover criterion', 'Matched', 'ok'], ['Experience criterion', 'Matched', 'ok'], ['EMD validity', 'Check corrigendum', 'flag']], banner: ['flag', '1 item needs human review'] } },
      { title: 'Reviewed by your team', actor: 'Tender team', note: 'A person confirms, corrects and moves it forward.', screen: { heading: 'Review', ref: 'A-114', rows: [['Reviewer', 'Tender manager'], ['Corrections', '1 field', 'info'], ['Next', 'Filed to tender pipeline', 'ok']], action: 'Confirm' } },
    ],
    entities: [
      { name: 'Source document', fields: ['Type', 'File', 'Received from'] },
      { name: 'Extracted fields', fields: ['Field', 'Value', 'Page reference'] },
      { name: 'Review', fields: ['Flags', 'Corrections', 'Reviewer'] },
    ],
    links: [['Source document', 'Extracted fields'], ['Extracted fields', 'Review']],
    flows: [
      { to: 'purchase-vendors', label: 'Quotes read', dir: 'out' },
      { to: 'approvals-audit', label: 'Compliance checks', dir: 'out' },
      { to: 'finance-cash-flow', label: 'Invoices read', dir: 'out' },
      { to: 'dashboards-mis', label: 'Flags raised', dir: 'out' },
    ],
    questions: ['Are we eligible for this tender?', 'Which terms differ between these quotes?', 'Does this invoice match the PO?'],
  },
  'dashboards-mis': {
    code: 'M-08', short: 'MIS',
    workflow: [
      { title: 'Data recorded once', actor: 'Every module', note: 'Purchase, stock, projects and finance write to one database.', screen: { heading: 'Sources', ref: 'Live', rows: [['Purchase', 'Connected', 'ok'], ['Inventory', 'Connected', 'ok'], ['Projects', 'Connected', 'ok'], ['Finance', 'Connected', 'ok']] } },
      { title: 'Organised into views', actor: 'System', note: 'Each role sees the view that matters to them.', screen: { heading: 'Views', ref: 'By role', rows: [['Director', 'Company overview'], ['Project manager', 'Project progress'], ['Finance head', 'Cash & budget']] } },
      { title: 'Exceptions surfaced', actor: 'System', note: 'What needs attention is pushed to the owner.', screen: { heading: 'Alerts', ref: 'Today', rows: [['Slab casting', 'Behind plan', 'warn'], ['Vendor B quote', 'Rate flag', 'flag'], ['Site 1 stock', 'Low', 'warn']] } },
      { title: 'MIS generated', actor: 'System', note: 'Weekly and monthly reports from live data, not assembled by hand.', screen: { heading: 'Monthly MIS', ref: 'September', rows: [['Projects', '3 sites'], ['Purchase', 'By vendor & head'], ['Cash flow', 'Actual & forecast']], action: 'Export' } },
      { title: 'Management review', actor: 'Director', note: 'Decisions and comments recorded against the numbers.', screen: { heading: 'Review', ref: 'Week 37', rows: [['Actions assigned', '3'], ['Approvals cleared', '5', 'ok'], ['Next review', 'Monday']] } },
    ],
    entities: [
      { name: 'Dashboard view', fields: ['Role', 'Metrics', 'Filters'] },
      { name: 'Alert', fields: ['Rule', 'Owner', 'Status'] },
      { name: 'Report', fields: ['Period', 'Sections', 'Recipients'] },
    ],
    links: [['Dashboard view', 'Alert'], ['Dashboard view', 'Report']],
    flows: [
      { to: 'projects-tasks', label: 'Progress & variance', dir: 'in' },
      { to: 'finance-cash-flow', label: 'Cash-flow & budget', dir: 'in' },
      { to: 'inventory-stock', label: 'Stock position', dir: 'in' },
      { to: 'approvals-audit', label: 'Pending approvals', dir: 'in' },
    ],
    questions: ['Where do we stand across all sites today?', 'What needs my attention this week?', 'Can I have this month’s MIS without waiting for it?'],
  },
  'store-erp-sync': {
    code: 'M-09', short: 'SYN',
    workflow: [
      { title: 'Order placed online', actor: 'Customer', note: 'Order on your custom, Shopify or WooCommerce store.', screen: { heading: 'Store order', ref: '#10482', rows: [['Items', '3'], ['Payment', 'Paid online', 'ok'], ['Channel', 'Website']] } },
      { title: 'Arrives in ERP', actor: 'Sync', note: 'The order is created in the ERP without re-typing.', screen: { heading: 'Sales order', ref: 'SO-10482', rows: [['Source', 'Online store'], ['Customer', 'Created / matched', 'ok'], ['Status', 'To pick', 'wait']] } },
      { title: 'Stock reserved', actor: 'Inventory', note: 'The same stock count serves store, marketplaces and warehouse.', screen: { heading: 'Stock', ref: 'SO-10482', rows: [['Item 1', 'Reserved', 'ok'], ['Item 2', 'Reserved', 'ok'], ['Item 3', 'Low after order', 'warn']] } },
      { title: 'Invoiced with GST', actor: 'Finance', note: 'Invoice generated from the order itself.', screen: { heading: 'Invoice', ref: 'INV-10482', rows: [['GST', 'Applied', 'ok'], ['Payment', 'Reconciled', 'ok']] } },
      { title: 'Shipped & tracked', actor: 'Dispatch', note: 'Shipment status flows back to the store.', screen: { heading: 'Shipment', ref: 'SO-10482', rows: [['Courier', 'Booked', 'ok'], ['Tracking', 'Sent to customer', 'info'], ['Store status', 'Updated', 'ok']] } },
    ],
    entities: [
      { name: 'Store order', fields: ['Channel', 'Items', 'Payment'] },
      { name: 'Sales order', fields: ['Customer', 'Fulfilment', 'Invoice'] },
      { name: 'Shipment', fields: ['Courier', 'Tracking', 'Status'] },
    ],
    links: [['Store order', 'Sales order'], ['Sales order', 'Shipment']],
    flows: [
      { to: 'inventory-stock', label: 'Reserve & deduct stock', dir: 'out' },
      { to: 'finance-cash-flow', label: 'Invoices & payments', dir: 'out' },
      { to: 'crm-sales', label: 'Customers & orders', dir: 'out' },
    ],
    questions: ['Is online stock the same as warehouse stock?', 'Which online orders are not yet shipped?', 'Did this payment reach the bank?'],
  },
}

/** "Follow one order" journey across the system map on the modules hub. */
export const journey: { module: string; event: string; record: string }[] = [
  { module: 'crm-sales', event: 'Deal won; order handed to delivery', record: 'SO-140' },
  { module: 'projects-tasks', event: 'Activities planned; material needed', record: 'Campus Block' },
  { module: 'purchase-vendors', event: 'Request raised; three quotes compared', record: 'PR-2041' },
  { module: 'ai-document-intelligence', event: 'Quotes read; one rate flagged', record: 'PR-2041' },
  { module: 'approvals-audit', event: 'Director approves with the flag visible', record: 'PO-1187' },
  { module: 'inventory-stock', event: 'Goods received at site', record: 'GRN-552' },
  { module: 'finance-cash-flow', event: 'Bill matched; payment scheduled', record: 'BL-4410' },
  { module: 'dashboards-mis', event: 'Management sees progress and spend', record: 'Week 37' },
]
