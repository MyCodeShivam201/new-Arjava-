import { useEffect, useState } from 'react'
import { aiLayer, capabilities, coreModules, cycle, cycleDetail, dataIn, decisionsOut, results, stages } from './data'
import { Icon, Reveal, card, soft, useInView } from './ui'

/** "The connected platform at a glance": data in → ERP core + AI layer → decisions out. */
export function PlatformDiagram() {
  const [ref, inView] = useInView<HTMLDivElement>()
  return (
    <div ref={ref} className={`${card} relative overflow-hidden p-5 md:p-8 ${inView ? 'is-in' : ''}`}>
      <div className="pointer-events-none absolute inset-0 opacity-60 [background-image:radial-gradient(#E2E7EF_1px,transparent_1px)] [background-size:18px_18px]" />
      <div className="relative grid gap-6 lg:grid-cols-[1fr_1.35fr_1fr] lg:items-center">
        <Column title="Your data in" items={dataIn} accent="#5B6B82" side="left" />
        <div className="relative">
          <div className="rounded-2xl bg-navy p-5 text-white shadow-[0_12px_40px_rgba(23,43,77,0.25)]">
            <div className="mb-4 flex items-center justify-between">
              <p className="text-[11px] font-bold uppercase tracking-[0.3em] text-blue">Arjava ERP core</p>
              <span className="flex items-center gap-1.5 text-[10.5px] font-semibold text-[#27AE60]"><span className="aj-pulse h-1.5 w-1.5 rounded-full bg-[#27AE60]" />One database</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {coreModules.map((m, i) => (
                <div key={m} className="rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2.5 text-[12px] font-semibold transition-colors hover:bg-white/10" style={{ transitionDelay: `${i * 40}ms` }}>
                  {m}
                </div>
              ))}
            </div>
            <div className="relative mt-4 overflow-hidden rounded-xl border border-[#1EB4D4]/40 bg-[#1EB4D4]/15 p-3">
              <span className="aj-scan absolute inset-x-0 h-4" style={{ backgroundImage: 'linear-gradient(to bottom, transparent, rgba(36,196,232,0.25), transparent)' }} />
              <p className="relative flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.3em] text-cyan"><Icon name="sparkles" className="h-3.5 w-3.5" />AI layer</p>
              <p className="relative mt-1.5 text-[12px] leading-relaxed text-white/75">{aiLayer.join(' · ')}</p>
            </div>
          </div>
        </div>
        <Column title="Decisions out" items={decisionsOut} accent="#F47B2A" side="right" />
      </div>
    </div>
  )
}

function Column({ title, items, accent, side }: { title: string; items: string[]; accent: string; side: 'left' | 'right' }) {
  return (
    <div>
      <p className="mb-3 text-[13.5px] font-bold text-muted">{title}</p>
      <ul className="space-y-2">
        {items.map((it, i) => (
          <li key={it} className="aj-hbar flex items-center gap-2" style={{ animationDelay: `${i * 90}ms` }}>
            {side === 'right' && <Flow accent={accent} />}
            <span className="flex-1 rounded-xl border border-border bg-card px-3 py-2 text-[12.5px] font-medium text-navy">{it}</span>
            {side === 'left' && <Flow accent={accent} />}
          </li>
        ))}
      </ul>
    </div>
  )
}

const Flow = ({ accent }: { accent: string }) => (
  <svg viewBox="0 0 32 8" className="hidden h-2 w-8 shrink-0 lg:block" aria-hidden="true">
    <path d="M0 4h32" stroke={accent} strokeWidth="2" className="aj-flow" />
  </svg>
)

/** Six capabilities orbiting "Arjava · one partner, end to end". */
export function CapabilityHub() {
  const [active, setActive] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setActive((a) => (a + 1) % capabilities.length), 2800)
    return () => clearInterval(t)
  }, [])
  const R = 132
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[420px]">
      <svg viewBox="-200 -200 400 400" className="absolute inset-0 h-full w-full" aria-hidden="true">
        <circle r={R} fill="none" stroke="#E2E7EF" strokeWidth="1.5" />
        <circle r={R} fill="none" stroke="#F47B2A" strokeWidth="1.5" className="aj-flow" opacity="0.5" />
        <circle r="62" fill="none" stroke="#E2E7EF" strokeDasharray="2 5" />
        {capabilities.map((c, i) => {
          const ang = (i / capabilities.length) * Math.PI * 2 - Math.PI / 2
          return <line key={c.slug} x1="0" y1="0" x2={Math.cos(ang) * R} y2={Math.sin(ang) * R} stroke={i === active ? c.accent : '#E2E7EF'} strokeWidth={i === active ? 2 : 1} className={i === active ? 'aj-flow' : ''} />
        })}
      </svg>
      <div className="absolute left-1/2 top-1/2 flex h-[30%] w-[30%] -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full bg-navy text-center text-white shadow-[0_12px_40px_rgba(23,43,77,0.3)]">
        <span className="text-[15px] font-extrabold tracking-[0.08em]">ARJAVA</span>
        <span className="mt-0.5 text-[9.5px] leading-tight text-white/60">One partner,<br />end to end</span>
      </div>
      {capabilities.map((c, i) => {
        const ang = (i / capabilities.length) * Math.PI * 2 - Math.PI / 2
        const on = i === active
        return (
          <a
            key={c.slug}
            href={`/services/${c.slug}/`}
            onMouseEnter={() => setActive(i)}
            className="absolute flex w-[26%] -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-1 text-center"
            style={{ left: `${50 + (Math.cos(ang) * R) / 4}%`, top: `${50 + (Math.sin(ang) * R) / 4}%` }}
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl border bg-card transition-all duration-300" style={{ borderColor: on ? c.accent : '#E2E7EF', color: c.accent, boxShadow: on ? `0 8px 24px ${c.accent}40` : undefined, transform: on ? 'scale(1.12)' : undefined }}>
              <Icon name={c.icon} className="h-5 w-5" />
            </span>
            <span className="text-[10px] font-bold uppercase tracking-[0.1em]" style={{ color: c.accent }}>{c.verb}</span>
          </a>
        )
      })}
    </div>
  )
}

/** Plan → Review → Buy → Stock → Deliver → Collect, auto-advancing and clickable. */
export function PlanToCash() {
  const [i, setI] = useState(0)
  const [paused, setPaused] = useState(false)
  useEffect(() => {
    if (paused) return
    const t = setInterval(() => setI((x) => (x + 1) % cycle.length), 2400)
    return () => clearInterval(t)
  }, [paused])
  const R = 120
  return (
    <div className="grid items-center gap-10 lg:grid-cols-[420px_1fr]" onMouseLeave={() => setPaused(false)}>
      <div className="relative mx-auto aspect-square w-full max-w-[380px]">
        <svg viewBox="-170 -170 340 340" className="absolute inset-0 h-full w-full" aria-hidden="true">
          <circle r={R} fill="none" stroke="#E2E7EF" strokeWidth="10" />
          <circle r={R} fill="none" stroke="#F47B2A" strokeWidth="10" strokeLinecap="round" strokeDasharray={`${((i + 1) / cycle.length) * 2 * Math.PI * R} 9999`} transform="rotate(-90)" style={{ transition: 'stroke-dasharray 0.6s ease' }} />
        </svg>
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
          <p className="text-[13.5px] font-bold text-muted">Plan to cash,</p>
          <p className="text-[18px] font-extrabold text-navy">in one system</p>
        </div>
        {cycle.map((s, k) => {
          const ang = (k / cycle.length) * Math.PI * 2 - Math.PI / 2
          const on = k === i
          return (
            <button
              key={s}
              type="button"
              onClick={() => (setI(k), setPaused(true))}
              className="absolute flex -translate-x-1/2 -translate-y-1/2 cursor-pointer items-center justify-center rounded-full border-2 px-3 py-1.5 text-[12.5px] font-bold transition-all duration-300"
              style={{ left: `${50 + (Math.cos(ang) * R) / 3.4}%`, top: `${50 + (Math.sin(ang) * R) / 3.4}%`, backgroundColor: on ? '#172B4D' : '#fff', color: on ? '#fff' : '#172B4D', borderColor: on ? '#172B4D' : k < i ? '#F47B2A' : '#E2E7EF', transform: `translate(-50%,-50%) scale(${on ? 1.1 : 1})` }}
            >
              {s}
            </button>
          )
        })}
      </div>
      <div className={`${card} p-6`} style={{ borderLeft: '3px solid #F47B2A' }}>
        <p className="text-[11px] font-bold uppercase tracking-[0.08em] text-muted">Stage {i + 1} of {cycle.length}</p>
        <h3 key={cycle[i]} className="aj-reveal is-in mt-1 text-[1.4rem] font-extrabold text-navy">{cycle[i]}</h3>
        <p className="mt-2 max-w-[520px] text-[15px] leading-[1.7] text-muted">{cycleDetail[cycle[i]]}</p>
        <div className="mt-5 flex gap-1.5">
          {cycle.map((s, k) => (
            <button key={s} type="button" aria-label={s} onClick={() => (setI(k), setPaused(true))} className="h-1.5 flex-1 cursor-pointer rounded-full transition-colors" style={{ backgroundColor: k <= i ? '#F47B2A' : '#E2E7EF' }} />
          ))}
        </div>
      </div>
    </div>
  )
}

/** Discover → Support & Improve. Clickable metro line with a detail panel; vertical on mobile. */
export function Stages() {
  const [i, setI] = useState(0)
  return (
    <div>
      <div className="relative hidden sm:block">
        <div className="absolute left-[8.33%] right-[8.33%] top-[18px] h-1 rounded bg-border">
          <div className="h-full rounded bg-blue transition-[width] duration-500" style={{ width: `${(i / (stages.length - 1)) * 100}%` }} />
        </div>
        <ol className="relative grid grid-cols-6">
          {stages.map((s, k) => (
            <li key={s.name}>
              <button type="button" aria-current={k === i ? 'step' : undefined} onClick={() => setI(k)} className="group flex w-full cursor-pointer flex-col items-center gap-2 px-1 text-center">
                <span className={`flex h-9 w-9 items-center justify-center rounded-full border-2 text-[13px] font-extrabold transition-all duration-300 ${k <= i ? 'border-navy bg-navy text-white' : 'border-border bg-card text-muted group-hover:border-navy/30'}`}>{k + 1}</span>
                <span className={`text-[13px] font-bold leading-tight ${k === i ? 'text-navy' : 'text-muted'}`}>{s.name}</span>
                <span className="hidden text-[12px] text-muted lg:block">{s.body}</span>
              </button>
            </li>
          ))}
        </ol>
      </div>
      <div className={`${card} mt-6 hidden px-6 py-5 sm:block`} style={{ borderLeft: '3px solid #F47B2A' }}>
        <p className="text-[11px] font-bold uppercase tracking-[0.06em] text-muted">Stage {i + 1} of {stages.length}</p>
        <h3 className="mt-0.5 text-[1.1rem] font-bold text-navy">{stages[i].name}</h3>
        <p className="mt-1 max-w-[720px] text-[14.5px] leading-[1.65] text-muted">{stages[i].detail}</p>
      </div>
      <ol className="relative space-y-4 border-l-2 border-border pl-6 sm:hidden">
        {stages.map((s, k) => (
          <li key={s.name} className="relative">
            <span className="absolute -left-[37px] flex h-7 w-7 items-center justify-center rounded-full bg-navy text-[12px] font-extrabold text-white">{k + 1}</span>
            <h3 className="text-[15px] font-bold text-navy">{s.name}</h3>
            <p className="mt-0.5 text-[13.5px] leading-[1.6] text-muted">{s.detail}</p>
          </li>
        ))}
      </ol>
      <p className="mt-4 text-[12px] text-muted">How we typically run an engagement; the exact plan is agreed with each client.</p>
    </div>
  )
}

export function Results() {
  return (
    <div>
      <div className="grid gap-4 md:grid-cols-3">
        {results.map((r, k) => (
          <Reveal key={r.label} delay={k * 100} className={`${card} p-6`}>
            <p className="text-[12px] font-bold uppercase tracking-[0.08em] text-muted">{r.label}</p>
            <p className="mt-2 text-[2.2rem] font-black leading-none tracking-[-0.02em] text-navy">{r.value}</p>
            <p className="mt-1 text-[13px] font-semibold text-blue">{r.was}</p>
            <p className="mt-3 text-[13.5px] leading-[1.6] text-muted">{r.note}</p>
          </Reveal>
        ))}
      </div>
      <p className="mt-4 text-[12px] text-muted">Client-reported, human-reviewed examples. Results vary by business and are not guaranteed.</p>
    </div>
  )
}

export function ProblemCard({ problem, solution, detail, accent, delay = 0 }: { problem: string; solution: string; detail: string; accent: string; delay?: number }) {
  return (
    <Reveal delay={delay} className={`${card} group flex flex-col p-5 transition-transform duration-200 hover:-translate-y-0.5`}>
      <p className="flex items-start gap-2 text-[13.5px] font-medium leading-snug text-muted">
        <Icon name="alert" className="mt-0.5 h-4 w-4 shrink-0 text-orange" />
        {problem}
      </p>
      <div className="my-3 h-px bg-border" />
      <p className="flex items-center gap-1.5 text-[15px] font-bold" style={{ color: accent }}>
        <Icon name="arrow" className="h-4 w-4" />
        {solution}
      </p>
      <p className="mt-1.5 text-[13.5px] leading-[1.6] text-navy/80">{detail}</p>
    </Reveal>
  )
}

export function HumanInTheLoop() {
  return (
    <div className="flex flex-col gap-3 rounded-2xl border border-[#1EB4D4]/30 px-5 py-4 sm:flex-row sm:items-center" style={{ backgroundColor: soft('#1EB4D4') }}>
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-card text-teal"><Icon name="users" className="h-5 w-5" /></span>
      <p className="text-[14px] leading-[1.6] text-navy">
        <strong>Human-in-the-loop AI.</strong> AI reads documents, compares data and flags risks; your team reviews and decides. AI output supports human review and does not replace contractual verification.
      </p>
    </div>
  )
}
