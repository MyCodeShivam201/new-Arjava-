import type React from 'react'
/* Arjava brand art: dark ink/forest surfaces with copper light, and large-scale
   graphics built from the logo's own geometry (the two sweeping wings and its nodes). */

/** Layered background for dark surfaces. Place inside a `relative overflow-hidden` parent. */
export function Glow({ tone = 'hero' }: { tone?: 'hero' | 'panel' | 'band' | 'footer' }) {
  const layers: Record<string, string> = {
    hero: 'radial-gradient(60% 75% at 92% 30%, rgba(255,154,77,0.55) 0%, rgba(244,123,42,0.18) 38%, transparent 70%), radial-gradient(45% 60% at 4% 85%, rgba(30,91,216,0.45) 0%, transparent 70%), linear-gradient(115deg, #050A1C 0%, #0E1C42 45%, #12307A 100%)',
    panel: 'radial-gradient(70% 90% at 0% 0%, rgba(30,91,216,0.35) 0%, transparent 65%), radial-gradient(60% 80% at 100% 100%, rgba(244,123,42,0.16) 0%, transparent 70%), linear-gradient(160deg, #08102A 0%, #0E1C42 100%)',
    band: 'radial-gradient(55% 120% at 100% 0%, rgba(255,154,77,0.45) 0%, transparent 65%), radial-gradient(50% 100% at 0% 100%, rgba(30,91,216,0.5) 0%, transparent 70%), linear-gradient(120deg, #08102A 0%, #12307A 100%)',
    footer: 'radial-gradient(40% 60% at 100% 0%, rgba(244,123,42,0.22) 0%, transparent 70%), radial-gradient(40% 70% at 0% 100%, rgba(30,91,216,0.3) 0%, transparent 70%), linear-gradient(180deg, #08102A 0%, #050A1C 100%)',
  }
  return <><div aria-hidden="true" className="aj-drift pointer-events-none absolute inset-0" style={{ backgroundImage: layers[tone] }} />{(tone === 'hero' || tone === 'band') && <Beads set={tone} />}</>
}

/** The logo's wing curve, scaled up into a glowing sweep with nodes. */
export function ArjavaSweep({ className = '', variant = 'hero' }: { className?: string; variant?: 'hero' | 'panel' }) {
  const id = `sw-${variant}`
  return (
    <svg viewBox="0 0 600 600" fill="none" aria-hidden="true" className={`pointer-events-none ${className}`}>
      <defs>
        <linearGradient id={`${id}-a`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#FFB57A" stopOpacity="0.95" />
          <stop offset="0.45" stopColor="#F47B2A" stopOpacity="0.85" />
          <stop offset="1" stopColor="#F47B2A" stopOpacity="0" />
        </linearGradient>
        <linearGradient id={`${id}-b`} x1="1" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#8EE3F2" stopOpacity="0.7" />
          <stop offset="1" stopColor="#1EB4D4" stopOpacity="0" />
        </linearGradient>
        <filter id={`${id}-blur`} x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="14" /></filter>
      </defs>
      {/* soft light behind the main wing */}
      <path d="M120 40 C 210 230, 360 380, 590 470" stroke="#FF9A4D" strokeOpacity="0.55" strokeWidth="70" filter={`url(#${id}-blur)`} />
      {/* main wing: the logo's right arc, enlarged */}
      <path d="M120 40 C 210 230, 360 380, 590 470" stroke={`url(#${id}-a)`} strokeWidth="26" strokeLinecap="round" />
      <path d="M150 28 C 240 210, 380 350, 600 430" stroke="#FFB57A" strokeOpacity="0.5" strokeWidth="1.5" />
      {/* counter wing in forest */}
      <path d="M560 20 C 470 210, 330 330, 40 420" stroke={`url(#${id}-b)`} strokeWidth="2" />
      <path d="M590 70 C 500 250, 360 380, 60 500" stroke="#8EE3F2" strokeOpacity="0.25" strokeWidth="1" />
      {/* spokes and nodes from the mark */}
      <g stroke="#FFFFFF" strokeOpacity="0.14" strokeWidth="1">
        <line x1="300" y1="80" x2="300" y2="520" /><line x1="80" y1="380" x2="560" y2="380" /><line x1="420" y1="200" x2="320" y2="540" />
      </g>
      {[[120, 40, 'c'], [300, 80, 'f'], [560, 380, 'f'], [80, 380, 'f'], [300, 520, 'f'], [440, 300, 'c']].map(([x, y, t]) => (
        <g key={`${x}-${y}`}>
          <circle cx={x as number} cy={y as number} r="16" fill={t === 'c' ? '#F47B2A' : '#1EB4D4'} stroke={t === 'c' ? '#FFE3CC' : '#8EE3F2'} strokeOpacity="0.7" strokeWidth="3" />
          <circle cx={(x as number) - 1} cy={(y as number) - 2} r="6" fill="#FFFFFF" opacity="0.25" />
        </g>
      ))}
    </svg>
  )
}

/** Fine concentric arcs taken from the mark, for quiet corners of dark bands. */
export function ArjavaRings({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 400 400" fill="none" aria-hidden="true" className={`pointer-events-none ${className}`}>
      {[180, 140, 100].map((r, i) => <circle key={r} cx="200" cy="200" r={r} stroke={i === 1 ? '#FF9A4D' : '#FFFFFF'} strokeOpacity={i === 1 ? 0.35 : 0.1} strokeWidth="1" />)}
      <path d="M90 60 C 140 170, 230 250, 380 300" stroke="#FF9A4D" strokeOpacity="0.6" strokeWidth="2" />
      <circle cx="90" cy="60" r="7" fill="#F47B2A" /><circle cx="380" cy="300" r="6" fill="#1EB4D4" /><circle cx="200" cy="20" r="5" fill="#1EB4D4" />
    </svg>
  )
}

/** Glossy 3D sphere in the logo's navy, cyan and orange; inner light slowly rotates and morphs. */
export function Orb({ size = 320, className = '', label, children }: { size?: number; className?: string; label?: string; children?: React.ReactNode }) {
  return (
    <div aria-hidden={label ? undefined : true} className={`aj-orb ${className}`} style={{ width: size, height: size }}>
      <div className="aj-orb-field">
        <i style={{ left: '8%', top: '30%', width: '55%', height: '55%', background: '#F47B2A' }} />
        <i style={{ right: '6%', top: '10%', width: '50%', height: '50%', background: '#1EB4D4', animationDelay: '-3s' }} />
        <i style={{ left: '30%', bottom: '4%', width: '48%', height: '45%', background: '#1E5BD8', animationDelay: '-6s' }} />
        <i style={{ left: '40%', top: '40%', width: '22%', height: '22%', background: '#FFB57A', animationDelay: '-2s' }} />
      </div>
      {children && <div className="absolute inset-0 z-[3] flex flex-col items-center justify-center text-center text-white">{children}</div>}
      {label && <span className="absolute inset-0 z-[3] flex items-center justify-center font-display text-[13px] font-semibold uppercase tracking-[0.32em] text-white/90">{label}</span>}
    </div>
  )
}

/** Small floating spheres scattered over dark sections, like light caught in glass. */
export function Beads({ set = 'hero' }: { set?: 'hero' | 'band' }) {
  const beads = set === 'hero'
    ? [{ l: '6%', t: '72%', s: 60, c: '#1E5BD8', d: '0s' }, { l: '46%', t: '12%', s: 34, c: '#3A4766', d: '-2s' }, { l: '88%', t: '82%', s: 70, c: '#F47B2A', d: '-4s' }, { l: '58%', t: '86%', s: 26, c: '#1EB4D4', d: '-1s' }]
    : [{ l: '4%', t: '20%', s: 44, c: '#1E5BD8', d: '0s' }, { l: '92%', t: '68%', s: 56, c: '#F47B2A', d: '-3s' }]
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
      {beads.map((b) => <span key={b.l} className="aj-bead absolute" style={{ left: b.l, top: b.t, width: b.s, height: b.s, animationDelay: b.d, background: `radial-gradient(circle at 35% 30%, rgba(255,255,255,.55), ${b.c} 38%, #050A1C 100%)`, opacity: 0.75 }} />)}
    </div>
  )
}

export const SCREENS = {
  dashboard: { path: 'tender/command-dashboard', src: '/erp/command-dashboard.png', alt: 'Arjava ERP command dashboard with revenue, receivables, tender pipeline and pending actions' },
  project: { path: 'projects/PRJ-8Q62B3-034/overview', src: '/erp/project-overview.png', alt: 'Project overview with progress against plan, approved budget and milestone tracker' },
  quantity: { path: 'projects/PRJ-8Q62B3-034/quantity-progress', src: '/erp/quantity-progress.png', alt: 'Quantity progress measured in metres and joints with weekly planning versus achieved' },
  procurement: { path: 'projects/PRJ-8Q62B3-033/procurement-plan', src: '/erp/procurement-plan.png', alt: 'Procurement plan listing items, budgets, priorities and vendor quotations' },
  assistant: { path: 'projects/PRJ-8Q62B3-034/site-progress', src: '/erp/site-assistant.png', alt: 'Site assistant answering a question about project progress from project data' },
  inventory: { path: 'inventory/stock-ledger', src: '/erp/inventory.png', alt: 'Inventory stock ledger across sites and stores' },
  extractStart: { path: 'tender/discover/new', src: '/erp/tender-extract-start.png', alt: 'Tender PDF upload: the system starts reading the document' },
  extractDone: { path: 'tender/discover/new', src: '/erp/tender-extract-done.png', alt: 'Tender extraction: dates, eligibility criteria and required documents identified' },
  equipment: { path: 'projects/equipment', src: '/erp/equipment.png', alt: 'Equipment register listing cranes, loaders and tractors by site' },
  costLeaks: { path: 'projects/PRJ-8Q62B3-031/cost-leaks', src: '/erp/cost-leaks.png', alt: 'Cost leak report: over-budget lines ranked with root cause' },
  routeMap: { path: 'projects/PRJ-8Q62B3-032/route-map', src: '/erp/route-map.png', alt: 'Pipeline route map with chainage progress on satellite view' },
  schedule: { path: 'projects/PRJ-8Q62B3-031/schedule', src: '/erp/master-schedule.png', alt: 'Master schedule Gantt with planned, actual and overrun bars' },
} as const
export type ScreenKey = keyof typeof SCREENS

/** A real ERP screen in a thin browser frame. */
export function ScreenFrame({ screen, className = '', url }: { screen: ScreenKey; className?: string; url?: string }) {
  const s = SCREENS[screen]
  return (
    <div className={`overflow-hidden rounded-xl border border-white/15 bg-white shadow-[0_40px_90px_-30px_rgba(5,10,28,0.75)] ${className}`}>
      <div className="flex items-center gap-2 border-b border-[#E2E7EF] bg-[#F7F9FC] px-3 py-2">
        <span className="h-2.5 w-2.5 rounded-full bg-[#E2E7EF]" /><span className="h-2.5 w-2.5 rounded-full bg-[#E2E7EF]" /><span className="h-2.5 w-2.5 rounded-full bg-[#E2E7EF]" />
        <span className="ml-2 truncate rounded bg-white px-2 py-0.5 text-[10.5px] text-[#5B6B82] ring-1 ring-[#E2E7EF]">{url ?? `erp.arjavahub.com/${s.path}`}</span>
      </div>
      <img src={s.src} alt={s.alt} loading="lazy" className="block w-full" />
    </div>
  )
}

/** Hero visual: two product screens in perspective. The orb is a live gauge of the
    project shown on screen (Sitapur-Lucknow, 37% complete), linking to project tracking. */
export function HeroCards() {
  return (
    <div className="relative mx-auto w-full max-w-[620px] py-6">
      <div className="aj-tilt relative">
        <ScreenFrame screen="dashboard" />
        <ScreenFrame screen="project" className="aj-float absolute -bottom-10 -left-8 w-[58%] max-sm:hidden" />
      </div>
      <a href="/modules/projects-tasks/" aria-label="Project progress: 37% complete, view project tracking" className="group absolute -top-8 right-2 z-[2] max-sm:hidden">
        <Orb size={150} className="transition-transform duration-500 group-hover:scale-105">
          <svg viewBox="0 0 100 100" className="absolute inset-3 -rotate-90" aria-hidden="true"><circle cx="50" cy="50" r="46" fill="none" stroke="rgba(255,255,255,.18)" strokeWidth="3" /><circle cx="50" cy="50" r="46" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeDasharray="289" strokeDashoffset={289 * 0.63} /></svg>
          <span className="font-display text-[30px] font-extrabold leading-none drop-shadow">37%</span>
          <span className="mt-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-white/85">Site progress</span>
          <span className="text-[10px] text-white/70">tracked daily</span>
        </Orb>
        <span className="aj-glass mt-2 block rounded-full px-3 py-1 text-center text-[11px] font-medium text-white">Actual vs plan, from site entries</span>
      </a>
    </div>
  )
}

/** Dark band with a real product screen tilted in perspective, plus an optional second screen. */
export function ScreenBand({ screen, second, title, body, eyebrow = 'Screens from a live deployment' }: { screen: ScreenKey; second?: ScreenKey; title: string; body?: string; eyebrow?: string }) {
  return (
    <section className="aj-dark relative overflow-hidden py-20 text-white">
      <Beads set="band" />
      <div className="relative mx-auto max-w-[1280px] px-6">
        <p className="text-[13.5px] font-semibold text-[#FFB57A]">{eyebrow}</p>
        <h2 className="mt-3 max-w-[680px] text-[clamp(1.7rem,3vw,2.4rem)] font-extrabold leading-[1.1]">{title}</h2>
        {body && <p className="mt-4 max-w-[620px] text-[15.5px] leading-[1.7] text-white/70">{body}</p>}
        <div className="relative mt-10 max-w-[1080px]">
          <div className="aj-tilt"><ScreenFrame screen={screen} /></div>
          {second && <ScreenFrame screen={second} className="aj-float absolute -bottom-10 right-0 w-[42%] max-md:hidden" />}
        </div>
        <p className={`${second ? 'mt-16' : 'mt-6'} text-[12px] text-white/50`}>Screens from a working project; some values are sample data.</p>
      </div>
    </section>
  )
}

/** Orbit diagram: an orb at the centre with labelled chips riding concentric rings. */
export function OrbOrbit({ label, chips }: { label: string; chips: string[] }) {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[460px]">
      {[100, 74, 50].map((r) => <span key={r} aria-hidden="true" className="absolute rounded-full border border-white/12 bg-white/[0.02]" style={{ inset: `${(100 - r) / 2}%` }} />)}
      <div className="absolute inset-[27%]"><Orb size={0} className="!h-full !w-full" label={label} /></div>
      <ul className="aj-orbit absolute inset-0">
        {chips.map((c, i) => {
          const a = (i / chips.length) * Math.PI * 2 - Math.PI / 2
          return <li key={c} className="absolute" style={{ left: `${50 + 44 * Math.cos(a)}%`, top: `${50 + 44 * Math.sin(a)}%` }}><span className="aj-glass block -translate-x-1/2 -translate-y-1/2 whitespace-nowrap rounded-full px-3.5 py-1.5 text-[12.5px] font-medium text-white">{c}</span></li>
        })}
      </ul>
    </div>
  )
}
