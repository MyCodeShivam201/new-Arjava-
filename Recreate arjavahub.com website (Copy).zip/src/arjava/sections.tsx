import { useEffect, useState, type ReactNode } from 'react'
import type { IconName } from './data'
import { Stages } from './diagrams'
import { ScreenFrame, type ScreenKey } from './brandArt'
import { Icon, Reveal, SectionHead, card } from './ui'

const wrap = 'mx-auto max-w-[1280px] px-6'

/* ------------------------------ Business challenges ------------------------------ */

const challenges: { icon: IconName; title: string; body: string }[] = [
  { icon: 'plug', title: 'Disconnected business tools', body: 'Purchase, stores, accounts and sites each keep their own spreadsheet, so the same figure exists in four versions.' },
  { icon: 'file', title: 'Manual document processing', body: 'Tenders, quotations and invoices arrive as PDFs and scans, and someone reads every page to find the few fields that matter.' },
  { icon: 'refresh', title: 'Repetitive data entry', body: 'An order typed once on site is typed again in accounts and again in the stock register.' },
  { icon: 'kanban', title: 'Hard-to-track workflows', body: 'Requests and approvals move over calls, email and WhatsApp, with no record of where each one stands.' },
  { icon: 'chart', title: 'Limited visibility into progress', body: 'Management learns about delays and overruns at month-end, when it is too late to act on them.' },
  { icon: 'layers', title: 'Software that does not fit', body: 'Generic platforms ask your team to change how it works to match their configuration screens.' },
]

export function Challenges() {
  return (
    <section className="border-b border-border bg-bg py-20" aria-labelledby="challenges-h">
      <div className={`${wrap} grid gap-12 lg:grid-cols-[0.8fr_1.2fr]`}>
        <div className="lg:sticky lg:top-24 lg:self-start">
          <p className="mb-2 text-[13.5px] font-bold text-orange">Recognise any of these?</p>
          <h2 id="challenges-h" className="text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold leading-[1.15] tracking-[-0.02em] text-navy">Where growing businesses start to slip</h2>
          <p className="mt-3 text-[15.5px] leading-[1.7] text-muted">Not every business faces all of them. Most of the organisations we work with recognise two or three, and that is usually where we begin.</p>
          <a href="/blog/real-business-problems-in-growing-businesses/" className="mt-5 inline-flex items-center gap-1.5 text-[14px] font-semibold text-blue hover:underline">Read: the six problems we keep finding <Icon name="arrow" className="h-3.5 w-3.5" /></a>
        </div>
        <ol className="grid gap-3 sm:grid-cols-2">
          {challenges.map((c, i) => (
            <Reveal key={c.title} delay={(i % 2) * 80} className={`${card} flex gap-4 p-5`}>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#F47B2A]/10 text-orange"><Icon name={c.icon} className="h-5 w-5" /></span>
              <div>
                <h3 className="text-[15px] font-bold text-navy">{c.title}</h3>
                <p className="mt-1 text-[13.5px] leading-[1.6] text-muted">{c.body}</p>
              </div>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  )
}

/* ------------------------------ Connected capabilities (architecture stack) ------------------------------ */

const layers: { name: string; role: string; accent: string; strong?: boolean; items: [string, string][] }[] = [
  { name: 'Understand', role: 'Strategy & process', accent: '#1E5BD8', items: [['Business & process consulting', '/services/consulting-strategy/'], ['Workflow mapping & roadmap', '/services/business-process-consulting/']] },
  { name: 'Core ERP', role: 'One shared database', accent: '#F47B2A', strong: true, items: [['ERP implementation & modernization', '/services/enterprise-solutions/'], ['Finance, receivables & bank reconciliation', '/modules/finance-cash-flow/'], ['Procurement & vendor management', '/modules/purchase-vendors/'], ['Inventory & stock', '/modules/inventory-stock/'], ['Projects & approvals', '/modules/projects-tasks/']] },
  { name: 'Extend', role: 'Custom & digital', accent: '#6A5BD8', items: [['Custom business software', '/services/custom-software-apps/'], ['Digital platforms & e-commerce', '/services/digital-technology/'], ['Data migration & upgrades', '/services/enterprise-solutions/']] },
  { name: 'Decide', role: 'AI & reporting', accent: '#1EB4D4', items: [['AI-assisted document workflows', '/modules/ai-document-intelligence/'], ['Dashboards, MIS & reporting', '/modules/dashboards-mis/']] },
]

export function ConnectedCapabilities() {
  return (
    <section className="py-20" aria-labelledby="cap-h">
      <div className={wrap}>
        <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-[680px]">
            <p className="mb-2 text-[13.5px] font-bold text-blue">Connected business systems</p>
            <h2 id="cap-h" className="text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold leading-[1.15] tracking-[-0.02em] text-navy">Everything Arjava builds sits on one core</h2>
            <p className="mt-3 text-[15.5px] leading-[1.7] text-muted">Strategy shapes the core. Custom software and digital platforms extend it. AI and reporting turn what it records into decisions.</p>
          </div>
          <a href="/services/" className="inline-flex items-center gap-1.5 rounded-[10px] border border-border bg-card px-4 py-2 text-[13.5px] font-semibold text-navy hover:border-navy/30">All services <Icon name="arrow" className="h-3.5 w-3.5" /></a>
        </div>
        <div className="space-y-3">
          {layers.map((l, i) => (
            <Reveal key={l.name} delay={i * 90}>
              <div className={`grid items-center gap-4 rounded-2xl border p-4 md:grid-cols-[200px_1fr] md:p-5 ${l.strong ? 'border-navy bg-navy text-white shadow-[0_14px_40px_rgba(23,43,77,0.22)]' : 'border-border bg-card'}`}>
                <div className="flex items-center gap-3">
                  <span className="h-10 w-1 rounded-full" style={{ backgroundColor: l.accent }} />
                  <div>
                    <p className="text-[16px] font-extrabold" style={{ color: l.strong ? '#fff' : '#172B4D' }}>{l.name}</p>
                    <p className={`text-[12px] ${l.strong ? 'text-white/60' : 'text-muted'}`}>{l.role}</p>
                  </div>
                </div>
                <ul className="flex flex-wrap gap-2">
                  {l.items.map(([t, h]) => (
                    <li key={t}>
                      <a href={h} className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-[13px] font-semibold transition-colors ${l.strong ? 'bg-white/[0.08] text-white hover:bg-white/[0.14]' : 'bg-bg-alt text-navy hover:bg-[#E2E7EF]'}`}>
                        {t}<Icon name="arrow" className="h-3 w-3 opacity-50" />
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ------------------------------ The paperwork reads itself ------------------------------ */

const fields: [string, string][] = [
  ['Tender no.', 'A-114, Campus block'],
  ['Estimated value', '₹1.4 Cr'],
  ['Turnover required', '₹8 Cr'],
  ['Experience required', '3 similar works'],
  ['EMD', '₹2,80,000'],
  ['Closes', '30 Sep'],
]
const aiSteps = [
  { n: '01', title: 'Document input', body: 'A tender notice (NIT or portal PDF) is uploaded to the tender record.', screen: 'extractStart' as ScreenKey },
  { n: '02', title: 'Reading the document', body: 'Dates, fees, eligibility criteria and required documents are picked out.', screen: 'extractDone' as ScreenKey },
  { n: '03', title: 'Into the pipeline', body: 'The tender joins the pipeline, with value and stage next to every other bid.', screen: 'dashboard' as ScreenKey },
  { n: '04', title: 'Review & ask', body: 'Your team checks the result and can query project records directly.', screen: 'assistant' as ScreenKey },
]

export function PaperworkReadsItself() {
  const [step, setStep] = useState(0)
  const [paused, setPaused] = useState(false)
  useEffect(() => {
    if (paused) return
    const t = setInterval(() => setStep((s) => (s + 1) % aiSteps.length), 3200)
    return () => clearInterval(t)
  }, [paused])
  const on = (i: number) => step === i
  return (
    <section id="ai" className="border-y border-border bg-bg py-20" aria-labelledby="ai-h" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className={wrap}>
        <SectionHead eyebrow="AI-assisted document processing" title={<span id="ai-h">The Paperwork Reads Itself</span>} body="Turn document-heavy workflows into structured information with AI-assisted extraction, organization, and comparison." />
        <ol className="mb-4 hidden gap-2 md:grid md:grid-cols-4" role="tablist" aria-label="Document processing steps">
          {aiSteps.map((s, i) => (
            <li key={s.n}>
              <button type="button" role="tab" aria-selected={on(i)} onClick={() => (setStep(i), setPaused(true))} className={`w-full cursor-pointer rounded-xl border px-4 py-3 text-left transition-colors ${on(i) ? 'border-teal bg-[#1EB4D4]/10' : 'border-border bg-card hover:border-navy/20'}`}>
                <span className="text-[11px] font-black tabular-nums text-teal">{s.n}</span>
                <span className="ml-2 text-[14px] font-bold text-navy">{s.title}</span>
                <span className="mt-1 block text-[12.5px] leading-snug text-muted">{s.body}</span>
              </button>
            </li>
          ))}
        </ol>
        <ol className="mb-4 grid gap-2 md:hidden">
          {aiSteps.map((x, i) => <li key={x.n}><button type="button" onClick={() => (setStep(i), setPaused(true))} className={`w-full rounded-lg border px-3 py-2 text-left text-[13px] font-semibold ${on(i) ? 'border-teal bg-[#1EB4D4]/10 text-navy' : 'border-border text-muted'}`}>{x.n} · {x.title}</button></li>)}
        </ol>
        <div key={step} className="aj-screen-in mx-auto max-w-[1040px]"><ScreenFrame screen={aiSteps[step].screen} className="!border-border" /></div>
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
          <p className="text-[12px] text-muted">Screens from Arjava ERP. Extraction supports human review; your team checks and decides.</p>
          <a href="/modules/ai-document-intelligence/" className="inline-flex items-center gap-1.5 text-[14px] font-semibold text-teal hover:underline">Explore AI Document Intelligence <Icon name="arrow" className="h-3.5 w-3.5" /></a>
        </div>
      </div>
    </section>
  )
}

/* ------------------------------ Core principles ------------------------------ */

function MiniStatus() {
  return (
    <div className="space-y-1.5">
      {[['Discovery', 'Done', '#27AE60', 100], ['Process map', 'Done', '#27AE60', 100], ['Build: Purchase', 'In progress', '#F47B2A', 60], ['Testing', 'Next', '#5B6B82', 0]].map(([t, s, c, w]) => (
        <div key={t as string} className="grid grid-cols-[1fr_auto] items-center gap-2 text-[11px]">
          <div>
            <p className="font-semibold text-navy">{t as string}</p>
            <div className="mt-1 h-1 rounded-full bg-bg-alt"><div className="aj-hbar h-1 rounded-full" style={{ width: `${w}%`, backgroundColor: c as string }} /></div>
          </div>
          <span className="rounded-full px-2 py-0.5 text-[10px] font-bold" style={{ backgroundColor: `${c}1F`, color: c as string }}>{s as string}</span>
        </div>
      ))}
    </div>
  )
}

function MiniScale() {
  return (
    <svg viewBox="0 0 220 110" className="h-full w-full" aria-hidden="true">
      {[[40, 25], [110, 14], [180, 25], [40, 85], [180, 85]].map(([x, y], i) => (
        <g key={i}>
          <line x1="110" y1="55" x2={x} y2={y} stroke="#E2E7EF" strokeWidth="1.5" />
          <rect x={x - 26} y={y - 10} width="52" height="20" rx="6" fill={i < 3 ? '#fff' : 'none'} stroke={i < 3 ? '#F47B2A' : '#C7D0DD'} strokeDasharray={i < 3 ? undefined : '3 3'} />
          <text x={x} y={y + 3.5} textAnchor="middle" fontSize="8.5" fontWeight="600" fill={i < 3 ? '#172B4D' : '#5B6B82'}>{['Purchase', 'Stock', 'Finance', '+ Projects', '+ CRM'][i]}</text>
        </g>
      ))}
      <rect x="80" y="43" width="60" height="24" rx="8" fill="#172B4D" />
      <text x="110" y="58.5" textAnchor="middle" fontSize="9" fontWeight="800" fill="#fff">Core</text>
    </svg>
  )
}

function MiniLifecycle() {
  const s = ['Implement', 'Launch', 'Support', 'Improve']
  return (
    <svg viewBox="0 0 220 110" className="h-full w-full" aria-hidden="true">
      <ellipse cx="110" cy="55" rx="78" ry="38" fill="none" stroke="#F47B2A" strokeWidth="1.5" className="aj-flow" />
      {s.map((t, i) => {
        const [x, y] = [[110, 17], [188, 55], [110, 93], [32, 55]][i]
        return (
          <g key={t}>
            <rect x={x - 30} y={y - 10} width="60" height="20" rx="10" fill={i === 2 ? '#172B4D' : '#fff'} stroke={i === 2 ? '#172B4D' : '#E2E7EF'} />
            <text x={x} y={y + 3.5} textAnchor="middle" fontSize="8.5" fontWeight="700" fill={i === 2 ? '#fff' : '#172B4D'}>{t}</text>
          </g>
        )
      })}
    </svg>
  )
}

function MiniFocus() {
  return (
    <svg viewBox="0 0 220 110" className="h-full w-full" aria-hidden="true">
      <rect x="8" y="42" width="66" height="26" rx="8" fill="#F47B2A" />
      <text x="41" y="58" textAnchor="middle" fontSize="8.5" fontWeight="800" fill="#fff">Objective</text>
      {['Control purchase cost', 'Faster approvals', 'Live stock'].map((t, i) => (
        <g key={t}>
          <path d={`M74 55 C100 55 100 ${20 + i * 35} 126 ${20 + i * 35}`} fill="none" stroke="#E2E7EF" strokeWidth="1.5" />
          <path d={`M74 55 C100 55 100 ${20 + i * 35} 126 ${20 + i * 35}`} fill="none" stroke="#F47B2A" strokeWidth="1.5" className="aj-flow" opacity="0.6" />
          <rect x="126" y={10 + i * 35} width="88" height="20" rx="6" fill="#fff" stroke="#E2E7EF" />
          <text x="170" y={23.5 + i * 35} textAnchor="middle" fontSize="8" fontWeight="600" fill="#172B4D">{t}</text>
        </g>
      ))}
    </svg>
  )
}

function MiniRepo() {
  return (
    <svg viewBox="0 0 220 110" className="h-full w-full" aria-hidden="true">
      <rect x="8" y="35" width="70" height="40" rx="8" fill="#fff" stroke="#E2E7EF" />
      <text x="43" y="52" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#172B4D">Arjava team</text>
      <text x="43" y="65" textAnchor="middle" fontSize="7.5" fill="#5B6B82">builds & commits</text>
      {[0, 1, 2].map((i) => <circle key={i} cx={98 + i * 14} cy="55" r="4" fill="#F47B2A" className="aj-pulse" style={{ animationDelay: `${i * 300}ms` }} />)}
      <line x1="78" y1="55" x2="142" y2="55" stroke="#F47B2A" strokeWidth="1.5" className="aj-flow" />
      <rect x="142" y="30" width="70" height="50" rx="8" fill="#172B4D" />
      <text x="177" y="50" textAnchor="middle" fontSize="8.5" fontWeight="800" fill="#fff">Your</text>
      <text x="177" y="62" textAnchor="middle" fontSize="8.5" fontWeight="800" fill="#fff">repository</text>
    </svg>
  )
}

function MiniTeam() {
  const nodes = [[40, 30], [110, 18], [180, 30], [60, 88], [160, 88]]
  return (
    <svg viewBox="0 0 220 110" className="h-full w-full" aria-hidden="true">
      {nodes.map(([x, y], i) => nodes.slice(i + 1).map(([x2, y2], j) => <line key={`${i}-${j}`} x1={x} y1={y} x2={x2} y2={y2} stroke="#E2E7EF" strokeWidth="1.2" />))}
      <rect x="70" y="46" width="80" height="20" rx="6" fill="#1EB4D4" />
      <text x="110" y="59.5" textAnchor="middle" fontSize="8" fontWeight="800" fill="#fff">Shared knowledge</text>
      {nodes.map(([x, y], i) => (
        <g key={i}>
          <line x1={x} y1={y} x2="110" y2="56" stroke="#1EB4D4" strokeWidth="1" opacity="0.4" />
          <circle cx={x} cy={y} r="11" fill="#fff" stroke="#1EB4D4" strokeWidth="1.5" />
          <text x={x} y={y + 3} textAnchor="middle" fontSize="7.5" fontWeight="700" fill="#172B4D">{['PM', 'BA', 'Dev', 'QA', 'Ops'][i]}</text>
        </g>
      ))}
    </svg>
  )
}

const principles: { title: string; body: string; visual: ReactNode; accent: string }[] = [
  { title: 'Live Visibility', accent: '#F47B2A', visual: <MiniStatus />, body: 'You see where delivery stands: what is done, what is in progress and what comes next, so you are never waiting for a status update.' },
  { title: 'Built to Scale', accent: '#1E5BD8', visual: <MiniScale />, body: 'Solutions are structured around a stable core, so new modules and requirements can be added as the business grows.' },
  { title: 'Support Beyond Launch', accent: '#27AE60', visual: <MiniLifecycle />, body: 'Go-live is a milestone, not the end. We stay on for monitoring, fixes and improvements as your requirements evolve.' },
  { title: 'Focus on Core Competence', accent: '#F47B2A', visual: <MiniFocus />, body: 'Technology starts from the business objective, and we focus on the areas where we can meaningfully contribute.' },
  { title: 'Ship to Your Own Repository', accent: '#172B4D', visual: <MiniRepo />, body: 'Our stated principle: code is delivered to your own repository, so the work lives with your business.' },
  { title: 'Dedicated Team, No Single Point of Failure', accent: '#1EB4D4', visual: <MiniTeam />, body: 'A specialised team shares knowledge of your system, so continuity does not depend on any one person.' },
]

export function Principles({ id = 'principles' }: { id?: string }) {
  return (
    <section id={id} className="border-y border-border bg-bg-alt py-20" aria-labelledby={`${id}-h`}>
      <div className={wrap}>
        <SectionHead eyebrow="How we work" title={<span id={`${id}-h`}>Principles we build by</span>} body="What differentiates Arjava is less what we build than how: openly, around a stable core, and with the code in your hands." />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {principles.map((p, i) => (
            <Reveal key={p.title} delay={(i % 3) * 80} className={`${card} flex flex-col overflow-hidden`}>
              <div className="h-[150px] border-b border-border bg-bg p-4">{p.visual}</div>
              <div className="p-5">
                <p className="text-[11px] font-black tabular-nums" style={{ color: p.accent === '#172B4D' ? '#F47B2A' : p.accent }}>{String(i + 1).padStart(2, '0')}</p>
                <h3 className="mt-1 text-[16.5px] font-bold text-navy">{p.title}</h3>
                <p className="mt-1.5 text-[13.5px] leading-[1.65] text-muted">{p.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ------------------------------ Operational visibility dashboard ------------------------------ */

const weekly = [['Excavation', 120, 112], ['RCC columns', 48, 48], ['Slab casting', 6, 4], ['Brickwork', 900, 610]] as const

export function VisibilityDashboard({ id = 'visibility' }: { id?: string }) {
  return (
    <section id={id} className="py-20" aria-labelledby={`${id}-h`}>
      <div className={wrap}>
        <SectionHead eyebrow="Operational visibility & reporting" title={<span id={`${id}-h`}>From site activity to management review</span>} body="Daily updates are recorded once, organised into structured progress reports, and reviewed by management with approvals in the same place." />
        <ol className="mb-6 grid gap-2 sm:grid-cols-4">
          {['Operational activity', 'Recorded information', 'Structured progress report', 'Management review'].map((t, i) => (
            <li key={t} className="flex items-center gap-2">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-navy text-[11px] font-extrabold text-white">{i + 1}</span>
              <span className="text-[13px] font-semibold text-navy">{t}</span>
              {i < 3 && <span className="hidden flex-1 border-t border-dashed border-[#C7D0DD] sm:block" />}
            </li>
          ))}
        </ol>
        <Reveal className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
          <figure><ScreenFrame screen="schedule" className="!border-border" /><figcaption className="mt-2 text-[12.5px] text-muted"><b className="text-navy">Master schedule.</b> Planned, actual and overrun on every activity, so a late weld shows up as "+18d and counting".</figcaption></figure>
          <div className="grid gap-5">
            <figure><ScreenFrame screen="costLeaks" className="!border-border" /><figcaption className="mt-2 text-[12.5px] text-muted"><b className="text-navy">Cost leaks.</b> Four lines account for 85% of the overage, ranked with the reason.</figcaption></figure>
            <figure><ScreenFrame screen="quantity" className="!border-border" /><figcaption className="mt-2 text-[12.5px] text-muted"><b className="text-navy">Quantity progress.</b> Metres and joints against the weekly plan.</figcaption></figure>
          </div>
        </Reveal>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-[12px] text-muted">Screens from a live pipeline project; some values are sample data.</p>
          <a href="/modules/dashboards-mis/" className="inline-flex items-center gap-1.5 text-[14px] font-semibold text-blue hover:underline">Explore Dashboards & MIS <Icon name="arrow" className="h-3.5 w-3.5" /></a>
        </div>
      </div>
    </section>
  )
}

/* ------------------------------ Industries ------------------------------ */

const industries = [
  { name: 'Construction & Infrastructure', href: '/industries/construction/', accent: '#F47B2A', points: ['Site procurement & material requests', 'Inventory across sites', 'Daily progress reporting', 'Approvals & billing'] },
  { name: 'Engineering & EPC', href: '/industries/engineering-epc/', accent: '#1E5BD8', points: ['Tender & technical documents', 'Project procurement', 'Progress reporting', 'Commercial coordination'] },
  { name: 'Manufacturing', href: '/industries/manufacturing/', accent: '#27AE60', points: ['Raw material & stores', 'Vendor purchasing', 'Finance & costing', 'Connected operations'] },
]

export function Industries() {
  return (
    <section className="border-y border-border bg-bg-alt py-20" aria-labelledby="ind-h">
      <div className={wrap}>
        <SectionHead eyebrow="Industries" title={<span id="ind-h">Built for businesses with sites, teams and approval chains</span>} />
        <div className="grid gap-4 md:grid-cols-3">
          {industries.map((d, i) => (
            <Reveal key={d.name} delay={i * 80}>
              <a href={d.href} className={`${card} group flex h-full flex-col p-6 transition-all hover:-translate-y-0.5 hover:shadow-[0_10px_30px_rgba(23,43,77,0.08)]`} style={{ borderTop: `3px solid ${d.accent}` }}>
                <h3 className="text-[17px] font-bold text-navy">{d.name}</h3>
                <ul className="mt-4 flex-1 space-y-2">
                  {d.points.map((p) => <li key={p} className="flex items-center gap-2 text-[13.5px] text-muted"><span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: d.accent }} />{p}</li>)}
                </ul>
                <span className="mt-5 inline-flex items-center gap-1.5 text-[13.5px] font-semibold text-navy">Explore industry <Icon name="arrow" className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" /></span>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ------------------------------ FAQ (content from the original site) ------------------------------ */

const faq: [string, string][] = [
  ['What is custom business software?', "It just means the software is built around how your business actually works, instead of you adjusting your processes to fit some generic template. We map out your real workflows, approvals, and terminology first, then build the system around that, whether that's a full ERP, a standalone tool for one process, or a platform connecting several."],
  ['How is Arjava different from off-the-shelf software?', "Off-the-shelf platforms are built for everyone, which usually means you end up bending your processes to fit their configuration screens. We build around how your team already operates, and you're not locked into our servers either, it can run on your own domain and infrastructure if that's what you'd prefer."],
  ['Can I host the software on my own server?', "Yes. You're not tied to our infrastructure, so whether you want it on your own server and domain, in the cloud, or on-premise, all of that works. Our deployment stage covers the setup either way, along with data migration and training your team."],
  ['Does Arjava only build ERP systems?', "No. ERP is one thing we build, covering Procurement, Inventory, Finance, Projects, HRMS & Payroll, Tender Management, and CRM & Sales. We also build standalone tools, internal platforms, and web and mobile applications for a single workflow that doesn't need a full ERP around it."],
  ['What industries does Arjava build software for?', 'Mostly construction & infrastructure, manufacturing, engineering & EPC, government, and retail chains, basically businesses juggling multiple sites, teams, or approval chains where things start slipping without one system tying it all together.'],
  ['Does Arjava provide support after launch?', "Yes, and it doesn't end at launch. Once you're live, we stay on for monitoring, fixes, and adding new features as your business grows, we're not going to hand it over and disappear."],
  ['How does the implementation process work?', "It runs through six stages: Discover, Plan, Build & Configure, Test & Validate, Deploy, and Support & Improve. You'll know exactly where things stand at each point instead of waiting around for a status update."],
]

export function Faq() {
  const [open, setOpen] = useState(0)
  return (
    <section id="faq" className="py-20" aria-labelledby="faq-h">
      <div className="mx-auto max-w-[820px] px-6">
        <SectionHead center title={<span id="faq-h">Common questions about custom business software</span>} body="Straight answers about how Arjava builds software around your business, what it costs to own, and what to expect during implementation." />
        <div className="space-y-2.5">
          {faq.map(([q, a], i) => (
            <div key={q} className={`${card} overflow-hidden`}>
              <h3>
                <button type="button" aria-expanded={open === i} aria-controls={`faq-${i}`} onClick={() => setOpen(open === i ? -1 : i)} className="flex w-full cursor-pointer items-center justify-between gap-4 px-5 py-4 text-left text-[15px] font-semibold text-navy">
                  {q}
                  <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-blue/10 text-blue transition-transform ${open === i ? 'rotate-45' : ''}`}>+</span>
                </button>
              </h3>
              <div id={`faq-${i}`} hidden={open !== i} className="px-5 pb-5 text-[14px] leading-[1.7] text-muted">{a}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ------------------------------ Delivery (homepage) ------------------------------ */


export function Delivery() {
  return (
    <section id="process" className="border-y border-border bg-bg-alt py-20" aria-labelledby="process-h">
      <div className={wrap}>
        <div className="mb-10 flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-[680px]">
            <p className="mb-2 text-[13.5px] font-bold text-blue">Delivery approach</p>
            <h2 id="process-h" className="text-[clamp(1.6rem,3vw,2.25rem)] font-extrabold leading-[1.15] tracking-[-0.02em] text-navy">From first call to full rollout</h2>
            <p className="mt-3 text-[15.5px] leading-[1.7] text-muted">A transparent, structured route. Every step is a milestone you can see and track.</p>
          </div>
          <a href="/how-it-works/" className="inline-flex items-center gap-1.5 rounded-[10px] border border-border bg-card px-4 py-2 text-[13.5px] font-semibold text-navy hover:border-navy/30">How it works <Icon name="arrow" className="h-3.5 w-3.5" /></a>
        </div>
        <Stages />
      </div>
    </section>
  )
}

/* ------------------------------ Industry pages: related capabilities ------------------------------ */

const industryLinks: Record<string, { title: string; body: string; links: [string, string][] }> = {
  construction: {
    title: 'How Arjava supports construction teams',
    body: 'Procurement, site inventory, project reporting, documents and approvals connected on one core.',
    links: [['Purchase & Vendors', '/modules/purchase-vendors/'], ['Inventory & Stock', '/modules/inventory-stock/'], ['Projects & Tasks', '/modules/projects-tasks/'], ['AI Document Intelligence', '/modules/ai-document-intelligence/'], ['Approvals & Audit', '/modules/approvals-audit/'], ['Finance & Cash Flow', '/modules/finance-cash-flow/']],
  },
  'engineering-epc': {
    title: 'How Arjava supports engineering & EPC teams',
    body: 'Project workflows, technical and commercial documents, procurement and progress reporting, coordinated in one system.',
    links: [['Projects & Tasks', '/modules/projects-tasks/'], ['AI Document Intelligence', '/modules/ai-document-intelligence/'], ['Purchase & Vendors', '/modules/purchase-vendors/'], ['Dashboards & MIS', '/modules/dashboards-mis/'], ['Enterprise Solutions', '/services/enterprise-solutions/']],
  },
  manufacturing: {
    title: 'How Arjava supports manufacturers',
    body: 'Inventory, procurement, finance and operational information on connected business systems.',
    links: [['Inventory & Stock', '/modules/inventory-stock/'], ['Purchase & Vendors', '/modules/purchase-vendors/'], ['Finance & Cash Flow', '/modules/finance-cash-flow/'], ['Dashboards & MIS', '/modules/dashboards-mis/'], ['Store-to-ERP Sync', '/modules/store-erp-sync/']],
  },
}

export function IndustryCapabilities({ slug }: { slug: string }) {
  const d = industryLinks[slug]
  if (!d) return null
  return (
    <section className="border-t border-border bg-bg-alt py-16" aria-labelledby="ind-cap-h">
      <div className={`${wrap} grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center`}>
        <div>
          <p className="mb-2 text-[13.5px] font-bold text-blue">Related Arjava capabilities</p>
          <h2 id="ind-cap-h" className="text-[clamp(1.4rem,2.6vw,1.9rem)] font-extrabold leading-tight tracking-[-0.02em] text-navy">{d.title}</h2>
          <p className="mt-2 text-[15px] leading-[1.7] text-muted">{d.body}</p>
        </div>
        <ul className="flex flex-wrap gap-2">
          {d.links.map(([t, h]) => (
            <li key={h}><a href={h} className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3.5 py-2.5 text-[13.5px] font-semibold text-navy hover:border-navy/30">{t}<Icon name="arrow" className="h-3 w-3 opacity-50" /></a></li>
          ))}
        </ul>
      </div>
    </section>
  )
}
