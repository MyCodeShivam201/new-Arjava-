import { useState } from 'react'
import { ArjavaSweep, Glow, HeroCards, OrbOrbit, ScreenFrame, type ScreenKey } from './brandArt'

/* Homepage opening: editorial hero, client proof and the three core workflows. */

const LOGO_SHANTI = '/_next/static/media/shanti-constructions-logo.15r7woa-5hj3f.png'
const LOGO_SS = '/_next/static/media/ss-engineering-logo.19eoaxks3sp32.png'
const wrap = 'mx-auto max-w-[1280px] px-6'

function Arrow({ className = 'h-4 w-4' }: { className?: string }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6" /></svg>
}

export function HomeHero() {
  return (
    <section className="relative overflow-hidden pt-16 text-white">
      <Glow tone="hero" />
      <ArjavaSweep className="absolute -left-40 top-24 hidden h-[720px] w-[720px] opacity-[0.18] lg:block" />
      <div className={`${wrap} relative grid items-center gap-12 py-10 lg:grid-cols-[1fr_1.05fr] lg:py-14`}>
        <div>
          <p className="flex items-center gap-3 text-[13.5px] font-semibold text-[#FFB57A]">Business transformation · Consulting · ERP · AI</p>
          <h1 className="mt-5 text-[clamp(2.2rem,4.3vw,3.6rem)] font-extrabold leading-[1.06] text-white">From scattered spreadsheets to <span className="bg-gradient-to-r from-[#FFB57A] to-[#FF9A4D] bg-clip-text text-transparent">one connected business.</span></h1>
          <p className="mt-5 max-w-[540px] text-[17px] leading-[1.65] text-white/75">Arjava designs and delivers the consulting, digital presence, custom ERP and AI your business needs, as one partner from process mapping to go-live.</p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <a href="/contact/" className="aj-pill-copper inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-[15px] font-semibold text-white">Book Consultation <Arrow /></a>
            <a href="/modules/" className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/5 px-7 py-3.5 text-[15px] font-semibold text-white backdrop-blur-sm transition-colors hover:bg-white/10">See the ERP modules</a>
          </div>
          <ul className="mt-8 grid max-w-[520px] grid-cols-2 gap-x-6 gap-y-2 border-t border-white/15 pt-5 text-[13.5px] text-white/70">{['Tender to project tracking', 'Procurement with vendor rate history', 'Multi-site inventory', 'Cost leaks and cash flow', 'Tender document reading', 'Approvals with audit trail'].map((f) => <li key={f} className="flex items-center gap-2"><span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[#1EB4D4]" />{f}</li>)}</ul>
        </div>
        <HeroCards />
      </div>
    </section>
  )
}

const clients = [
  { logo: LOGO_SHANTI, name: 'Shanti Infraconstruct', sector: 'Oil & gas pipeline EPC · 32+ projects across 10+ states', result: '₹3,30,000 saved on a single purchase order', how: 'Vendor rate history flagged a cheaper vendor already in the records; a landed-cost check confirmed it was still the better deal.', href: '/blog/one-purchase-order-3-3-lakh-saved-in-a-day/' },
  { logo: LOGO_SS, name: 'S.S. Engineering Works', sector: 'Water, wastewater & environmental engineering · 400+ projects', result: 'Purchase approvals from 3 days to same-day', how: 'Tender-to-billing mapped end to end and rolled out module by module; a bank guarantee alert caught a tender before it went out invalid.', href: '/blog/how-ss-engineering-found-1-crore-in-hidden-costs/' },
]

export function ClientProof() {
  return (
    <section className="border-y border-border bg-white">
      <div className={`${wrap} grid gap-10 py-16 lg:grid-cols-[220px_1fr]`}>
        <div>
          <p className="text-[13.5px] font-semibold text-muted">In daily use at</p>
          <p className="mt-3 text-[14px] leading-[1.6] text-muted">Two engagements, walked through end to end in our case studies.</p>
        </div>
        <ul className="grid divide-y divide-border md:grid-cols-2 md:divide-x md:divide-y-0">
          {clients.map((c, i) => (
            <li key={c.name} className={i ? 'pt-8 md:pl-10 md:pt-0' : 'pb-8 md:pb-0 md:pr-10'}>
              <div className="flex items-center gap-3">
                <img src={c.logo} alt={`${c.name} logo`} width={40} height={40} loading="lazy" className="h-10 w-10 object-contain" />
                <div><p className="font-display text-[16px] font-bold text-navy">{c.name}</p><p className="text-[12.5px] text-muted">{c.sector}</p></div>
              </div>
              <p className="mt-6 font-display text-[clamp(1.3rem,2.2vw,1.65rem)] font-bold leading-snug text-navy">{c.result}</p>
              <p className="mt-2 text-[14.5px] leading-[1.65] text-muted">{c.how}</p>
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <a href={c.href} className="inline-flex items-center gap-1.5 text-[14px] font-semibold text-forest hover:text-copper">Read the case study <Arrow className="h-3.5 w-3.5" /></a>
                <span className="text-[11.5px] text-muted">Client-reported, not independently audited.</span>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}

const flows = [
  { code: '01', title: 'Tender to project', body: 'Tender notices are read, eligibility is checked against your company profile, and an awarded bid becomes a project with its budget in place.', steps: ['Tender discovery', 'Eligibility review', 'BOQ & costing', 'Submission', 'Award', 'Project execution'], href: '/services/ai-business-intelligence/', link: 'AI & Business Intelligence' },
  { code: '02', title: 'Request to stock', body: 'A request raised on site is checked against stock and rate history, approved by the right person, and lands in inventory and the ledger without re-entry.', steps: ['Purchase request', 'Review', 'Approval', 'Purchase order', 'Goods receipt', 'Inventory update'], href: '/modules/purchase-vendors/', link: 'Purchase & Vendors module' },
  { code: '03', title: 'Plan to report', body: 'Site progress is recorded against the plan, so variance shows up while it can still be acted on, not at year-end reconciliation.', steps: ['Planned work', 'Site progress', 'Actual quantities', 'Variance analysis', 'Management reporting'], href: '/modules/projects-tasks/', link: 'Projects & Tasks module' },
]

export function CoreWorkflows() {
  return (
    <section className="bg-ivory py-24">
      <div className={wrap}>
        <div className="grid gap-6 lg:grid-cols-2 lg:items-end">
          <div>
            <p className="flex items-center gap-3 text-[13.5px] font-semibold text-forest">The product in action</p>
            <h2 className="mt-4 text-[clamp(2rem,3.6vw,3rem)] font-extrabold leading-[1.08] text-navy">Three workflows, end to end.</h2>
          </div>
          <p className="max-w-[520px] text-[16px] leading-[1.7] text-muted lg:justify-self-end">Every engagement starts from how work actually moves between your teams. These are the three journeys we connect most often.</p>
        </div>
        <div className="mt-12 grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
          <div className="border-l-2 border-copper pl-6">
            <p className="font-display text-[22px] font-bold leading-snug text-navy">A decision, inside the system.</p>
            <p className="mt-3 text-[15px] leading-[1.65] text-muted">A site request arrives with two quotes. Rate history flags the higher one, a landed-cost check confirms the alternative, and the director approves with the reason on record.</p>
          </div>
          <div className="aj-tilt"><ScreenFrame screen="procurement" /><p className="mt-3 text-[12px] text-muted">Procurement plan from a live project · 53 items, each with three quotations</p></div>
        </div>
        <ol className="mt-14 border-t border-navy/15">
          {flows.map((f) => (
            <li key={f.code} className="grid gap-8 border-b border-navy/15 py-10 lg:grid-cols-[320px_1fr] lg:gap-14">
              <div>
                <p className="font-display text-[13px] font-bold text-copper">{f.code}</p>
                <h3 className="mt-2 text-[24px] font-bold leading-tight text-navy">{f.title}</h3>
                <p className="mt-3 text-[15px] leading-[1.65] text-muted">{f.body}</p>
                <a href={f.href} className="mt-4 inline-flex items-center gap-1.5 text-[14px] font-semibold text-forest hover:text-copper">{f.link} <Arrow className="h-3.5 w-3.5" /></a>
              </div>
              <ol className="relative grid content-center gap-y-6 sm:grid-cols-3 lg:flex lg:items-start" aria-label={`${f.title} steps`}>
                <span aria-hidden="true" className="absolute left-0 right-0 top-[7px] hidden h-px bg-navy/20 lg:block" />
                {f.steps.map((s, i) => {
                  const last = i === f.steps.length - 1
                  return (
                    <li key={s} className="relative flex items-center gap-3 lg:flex-1 lg:flex-col lg:items-start lg:gap-4">
                      <span className={`relative z-[1] h-[15px] w-[15px] shrink-0 rounded-full border-2 ${last ? 'border-copper bg-copper' : 'border-forest bg-ivory'}`} />
                      <span><span className="block text-[11px] font-semibold tabular-nums text-muted">{String(i + 1).padStart(2, '0')}</span><span className={`block text-[14.5px] font-semibold leading-snug ${last ? 'text-copper' : 'text-navy'}`}>{s}</span></span>
                    </li>
                  )
                })}
              </ol>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}

const industryBands: Record<string, { screen: ScreenKey; second: ScreenKey; title: string; points: string[] }> = {
  construction: { screen: 'equipment' as ScreenKey, second: 'project' as ScreenKey, title: 'Where site, stores and head office have to agree', points: ['Project planning and budgets', 'Procurement against the project budget', 'Site inventory and material transfers', 'Contractor coordination and billing', 'Project and financial reporting'] },
  'engineering-epc': { screen: 'routeMap' as ScreenKey, second: 'schedule' as ScreenKey, title: 'From tender notice to site execution', points: ['Tender management and eligibility review', 'Technical documentation and document control', 'BOQ and rate analysis', 'Project scheduling and resource coordination', 'Site execution reporting'] },
  manufacturing: { screen: 'inventory' as ScreenKey, second: 'procurement' as ScreenKey, title: 'Material, vendors and reporting on one record', points: ['Inventory and material movements', 'Procurement and vendor coordination', 'Production-related workflows where required', 'Operational reporting', 'Connected business systems'] },
}

export function IndustryBand({ slug }: { slug: string }) {
  const b = industryBands[slug]
  if (!b) return null
  return (
    <section className="aj-dark text-white">
      <div className="grid lg:grid-cols-[1.1fr_1fr]">
        <div className="relative flex items-center px-6 py-14 lg:py-20 lg:pl-12">
          <div className="relative w-full"><div className="aj-tilt"><ScreenFrame screen={b.screen} /></div><ScreenFrame screen={b.second} className="aj-float absolute -bottom-8 -right-2 w-[48%] max-md:hidden" /></div>
        </div>
        <div className="px-6 py-16 lg:px-16 lg:py-20">
          <p className="flex items-center gap-3 text-[13.5px] font-semibold text-[#FFB57A]">In the field</p>
          <h2 className="mt-4 max-w-[520px] text-[clamp(1.8rem,3vw,2.6rem)] font-extrabold leading-[1.1]">{b.title}</h2>
          <ul className="mt-8 max-w-[520px] border-t border-white/15">
            {b.points.map((p, i) => <li key={p} className="flex gap-4 border-b border-white/15 py-3.5 text-[15.5px]"><span className="w-6 font-display text-[12px] font-bold text-[#FFB57A]">{String(i + 1).padStart(2, '0')}</span>{p}</li>)}
          </ul>
          <a href="/contact/" className="mt-8 inline-flex items-center gap-2 rounded-md bg-copper px-5 py-3 text-[14.5px] font-semibold text-white hover:bg-[#D9621A]">Discuss your workflows <Arrow /></a>
        </div>
      </div>
    </section>
  )
}

const tour: { key: string; tab: string; title: string; body: string; screen: ScreenKey; chips: string[]; stat: [string, string]; href: string }[] = [
  { key: 'tender', tab: 'Tender & bids', title: 'One dashboard from tender notice to cash position', body: 'Revenue against target, receivables, payables and the live tender pipeline, with the approvals that need you today sitting on the right.', screen: 'dashboard', chips: ['Tender discovery', 'Bid results', 'Competitor intel', 'JV partners'], stat: ['5', 'stages tracked from identified to awarded'], href: '/services/ai-business-intelligence/' },
  { key: 'project', tab: 'Projects & site', title: 'Progress measured in metres and joints, not days', body: 'Milestones, quantity progress and RA bills recorded against the plan, so a 103-day slip shows up while there is still time to act on it.', screen: 'quantity', chips: ['Milestones', 'Quantity progress', 'RA bills', 'Site expenses'], stat: ['103', 'days of slip flagged from site data'], href: '/modules/projects-tasks/' },
  { key: 'procure', tab: 'Procurement', title: 'Every item budgeted, quoted three times, then ordered', body: 'The procurement plan locks quantities and budgets once approved. Quotations and vendor selection continue against it, and variance is visible per line.', screen: 'procurement', chips: ['Budget lines', 'Vendor quotes', 'Approvals', 'Purchase orders'], stat: ['53', 'items planned on one pumping station'], href: '/modules/purchase-vendors/' },
  { key: 'stock', tab: 'Inventory', title: 'Stock across 24 sites and 4 stores, on one ledger', body: 'Item master, site stores and movements in one place. Transfers between sites are recorded once and valued at standard rate.', screen: 'inventory', chips: ['Item master', 'Stock ledger', 'Transfers', 'Site stores'], stat: ['24', 'sites on a single stock ledger'], href: '/modules/inventory-stock/' },
  { key: 'ai', tab: 'Site assistant', title: 'Ask the project a question, get an answer from its own data', body: 'The assistant reads only project records and cites what it checked. It is there to save a search, not to replace judgement, and says so on screen.', screen: 'assistant', chips: ['Daily brief', 'Risks', 'Missing data', 'Documents'], stat: ['4', 'sources checked before it answers'], href: '/modules/ai-document-intelligence/' },
]

/** Newgen-style tabbed tour: orbit diagram on the left, the real screen on the right. */
export function ProductTour() {
  const [k, setK] = useState(tour[0].key)
  const t = tour.find((x) => x.key === k)!
  return (
    <section className="aj-dark relative overflow-hidden py-24 text-white">
      <div className={`${wrap} relative`}>
        <div className="text-center">
          <p className="text-[13.5px] font-semibold text-[#FFB57A]">Inside Arjava ERP</p>
          <h2 className="mx-auto mt-3 max-w-[760px] text-[clamp(2rem,3.8vw,3rem)] font-extrabold leading-[1.08]">The screens your teams will open every morning.</h2>
        </div>
        <div role="tablist" aria-label="Product areas" className="aj-glass mx-auto mt-10 flex w-fit max-w-full gap-1 overflow-x-auto rounded-full p-1.5">
          {tour.map((x) => <button key={x.key} role="tab" aria-selected={x.key === k} onClick={() => setK(x.key)} className={`shrink-0 rounded-full px-4 py-2 text-[13.5px] font-semibold transition-colors ${x.key === k ? 'bg-white text-navy' : 'text-white/75 hover:text-white'}`}>{x.tab}</button>)}
        </div>
        <div key={t.key} className="aj-screen-in aj-glass mt-10 grid gap-10 rounded-3xl p-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-center lg:p-10">
          <div>
            <h3 className="text-[clamp(1.5rem,2.4vw,2rem)] font-bold leading-tight">{t.title}</h3>
            <p className="mt-4 text-[15.5px] leading-[1.7] text-white/70">{t.body}</p>
            <div className="mt-6 flex items-end gap-4 border-l-2 border-[#F47B2A] pl-4"><span className="font-display text-[44px] font-extrabold leading-none">{t.stat[0]}</span><span className="pb-1 text-[13.5px] text-white/65">{t.stat[1]}</span></div>
            <a href={t.href} className="mt-7 inline-flex items-center gap-2 text-[14.5px] font-semibold text-[#FFB57A] hover:text-white">Explore this area <Arrow /></a>
            <div className="mt-8 max-w-[320px] max-lg:hidden"><OrbOrbit label="Arjava" chips={t.chips} /></div>
          </div>
          <div className="aj-tilt"><ScreenFrame screen={t.screen} /></div>
        </div>
      </div>
    </section>
  )
}
